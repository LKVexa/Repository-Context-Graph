> Status: this is a specification inventory, not evidence of implemented or deployed capabilities. Current physical paths and aliases are listed in [the 66-suite map](audit/SUITE_INVENTORY.md). Original inventory text is retained in `audit/history/root-metadata/`.


# Complete Suite Repository Inventory

### 01. Observer

prompts
uploads
runtime events
decisions
errors
evidence

### 02. Anthology

chronology
immutable provenance
prior artifacts
ordered experience records

### 03. Atlas

entities
domains
files
feature spaces
project structure
coordinates.

### 04. Compass

direction
priorities
policies
feasibility paths
routing objectives.

### 05. Pencil

Authors
rewrites
transforms
source artifacts
logic

### 06. Pencil Sharpener

correctness
clarity
compactness
compile-readiness
consistency

### 07. Grinder

optimization
reduction
repeated evaluation
stress analysis
candidate improvement

### 08. Tables

records
metrics
schemas
test matrices
ledgers
deterministic tabular outputs

### 09. Funnel

Compresses broad repositories
recall results into deduplicated, relevant working sets.

### 10. Illuminator

findings
exposes assumptions
renders diagnostics
produces human-readable reports.

### 11. Cypher

Hashes
signs
fingerprints
verifies
audit artifacts and provenance records.

### 12. Filing Cabinet

Stores canonical artifacts
	manifests
	ledgers
	models
	rollback records
	retrieval pointers

### 13. Chair

deterministic safety
authorization
validation
no-autorun
policy gates

### 14. Plug

interfaces
runtimes
data adapters
UI layers
execution endpoints

### 15. Orchestrator

suite fan-out
deterministic fan-in
load order
conflict resolution
synthesis.

### 16. Perceiver

Maintains short-, medium-, and long-term memory
continuous scanning
recall
memory promotion.

### 17. Asset Observer

Inspects images
	video
	archives
	UI assets
	code
	metadata before reconstruction begins.

### 18. Feature Graph

graph of regions
contours
landmarks
layers
materials
relations

### 19. Mesh Geometry

geometric proxies
depth hypotheses
topology
camera coordinates
deformable meshes

### 20. Equation Operator Bank

Maps visual structure to reusable mathematical, MSSL, MSSLB, MCRT, and rendering operators.

### 21. Scene Reconstruction

Reconstructs deterministic layered scenes from source imagery and inferred geometry.

### 22. Motion Planner

Produces motion plans with transforms
			constraints
			timing
			camera motion
			continuity

### 23. Temporal Animator

Evaluates motion plans across frames
preserves continuity
emits deterministic frame states

### 24. CSharp Renderer

Renders scenes and frame states through the native C# rendering layer.

### 25. Media Export

Encodes frame sequences and audio into validated delivery formats.

### 26. Full Stack UI

interfaces
uploads
dashboards
endpoints
job controls

### 27. DeepML Worker

sandboxed inference
feature extraction
reconstruction proposals
model routing

### 28. Safety Gate

AST
lint
archive
path
execution
network
output validation

### 29. Archive Ledger

feature graphs
motion plans
training ledgers
manifests
provenance
hashes

### 30. JA Adapter

Parses and emits JA records for deterministic reconstruction, rendering, and storage workflows.

### 31. Vexxa

Connects reconstruction to shared native services and operator infrastructure.

### 32. Orchestrator II

reconstruction
rendering
validation
learning records
release packaging

### 33. Visual Feedback Loop

Compares generated visual output against targets and produces evidence-backed correction proposals.

### 34. Animation VFX Workspace

animation
effects
compositing
inspection
iteration

### 35. App Designer

composition
layout
interaction design
preview
handoff

### 36. Visual Correction System

Detects visual defects and coordinates bounded corrective render or interaction passes.

### 37. Training Suite

visual training examples
evaluation fixtures
feedback records
learning promotion

### 38. Preview Designer

reviewable application
scene
animation
release previews

### 39. Core Studio

files
editors
tabs
sessions
builds
tests
controlled integration
Repository UI
Code Editor
Integrated Terminal
Visual App Designer
Model
Resource Dashboard
Local Server

### 40. Repository Context Engine

context
symbols
dependencies
freshness
worktrees
provenance

### 41. Knowledge Repository

documentation
architecture
commands
workflows
suite references
Suite documentation
HERMIT commands
Language anthology
Architecture
Operational workflows

### 42. Translation Plane

language detection
parsing
intermediate representations
validation
testing
provenance

### 43. Release Plane

build gates
patch application
packaging
signing preparation
rollback
release evidence
Build jobs
Patch application
Test gates
MSIX packaging
Installer packaging
Signing preparation
Rollback

### 44. Capability and Security Plane

capability manifests
permissions
trust boundaries
approvals
policy enforcement
Capability Plane
Security
Trust Plane
Evaluation Suite

### 45. Localization and Large File Plane

multilingual presentation
accessibility
bounded large-file windows
repository-scale navigation.
Localization System
Large File System
Accessibility

### 46. Air Gap Certification and Installer Plane

offline runtime policy
certification records
one-click setup
licensing
installer integration
Air-Gap Runtime
Certification Fabric
One-Click Setup
Multilingual Setup
Installer
License System

### 47. Chatbot

explaining
planning
debugging
reviewing
refactoring
documenting projects

### 48. Answer Modes and Specialized Roles

auto
concise
detailed
tutorial
code
debug
architect
review
Auto Coordinator
Technical Coordinator
Repository Analyst
Software Engineer
Debugger
Software Architect
Security Reviewer
Test Engineer
Code Reviewer
Operations Engineer
Release Engineer
Roles
Documentation Instructor
AI and Model Engineer
Language Toolchain Engineer

### 49. Action Cards

risk
evidence
parameters
impact
rollback
hashes
Capability contract
Parameters
Preconditions
Expected effects
Impact
Rollback
Unified diff
Review history

### 50. Diff Patch and Review

Produces and reviews bounded diffs and patches while preserving human approval and repository confinement.

### 51. Repository Retrieval and Memory

Retrieves exact local evidence and governed memory while keeping repository evidence authoritative.

### 52. Evaluation and Content Defense

Evaluates answer quality and defends against prompt injection
malicious repository content
fabricated evidence
Permanent evaluation
Prompt-injection defense
Repository-content defense

### 53. Operations Plane

Operational control plane behind AI services.

### 54. Local Model Provider and Health

approved local providers
provider routing
lifecycle
readiness
health
Local model-provider contract
Model provider dashboard
Model lifecycle and health

### 55. Capability Manifests and Permissions

capabilities
command permissions
action scope
policy-bound execution rights

### 56. Job Queue Workers and Sandboxes

deterministic queues
worker management
isolated sandboxes
status tracking
recovery
Job queue
Worker manager
Sandboxes
Failures and retries

### 57. Translation Build Test and Evaluation Jobs

governed job families and their artifacts, results, and provenance.
Translation jobs
Build jobs
Test jobs
Evaluation jobs

### 58. Indexing Storage Resources Logs and Recovery

repository indexing
storage
resource monitoring
diagnostics
logs
retries
failure handling
Repository indexing
Storage manager
Resource dashboard
Resource usage monitor
Logs
Learning-event recording

### 59. Shell

Approved commands
Command policy
Output streaming

### 60. Worker

approved repository jobs and reports stdout, stderr, exit codes, and artifacts
Build worker
Test worker
Translation worker
Rendering worker
Packaging worker

### 61. Popup Runner

Provides a focused launch surface for approved jobs without exposing unrestricted execution.

### 62. LANDON Integration and Run All

Connects approved execution and coordinates governed multi-job runs
Run 
Run All
result reporting

### 63. Sandbox and Offline Runtime

tools
builds
tests
translation
rendering
packaging

### 64. Training Desktop and Android Workers

Training Worker
Desktop Module
Android Module
Knowledge Repository


END REPOSITORY


### 65. Sandbox Engine

36 specification scripts. See [Sandbox Engine](Sandbox%20Engine/README.md) for responsibilities and internal profiles.

- Run Contract Intake
- Asset Intake and Inspection
- Repository Context Snapshot
- Workspace Staging
- Suite Registry and Dependency Graph
- Capability Manifest
- Authorization and Approval Gate
- Static Safety and Content Defense
- Network and Air Gap Policy
- Resource Budget and Quota
- Job Queue and Scheduler
- Worker Provisioning and Health
- HERMIT Execution Cell
- Job Family Router
- JA Record and Artifact Adapter
- Translation and Build Pipeline
- Test Evaluation and Certification Pipeline
- Reconstruction Pipeline
- Motion and Animation Pipeline
- Rendering and VFX Pipeline
- Media Export Pipeline
- UI Preview and Popup Pipeline
- Model Provider and DeepML Pipeline
- Visual Feedback and Bounded Correction
- Runtime Events Logs and Diagnostics
- Checkpoint Retry and Recovery
- Archive Provenance and Filing
- Diff Patch and Review
- Release Installer and Air Gap Certification
- LANDON Run and Run All Control
- Professor Proposal and Action Cards
- Podium Authorization and Dispatch
- SOPHIA Evaluation and Accepted Learning
- CHARLOTTE Construction and Inspection
- Localization Accessibility and Large File Windows
- Final Validation and Compatibility Report


### 66. Terminal

30 specification scripts. See [Terminal](Terminal/README.md) for responsibilities and internal profiles.

- Terminal Contract Intake
- Session Identity and Provenance
- Repository Context Binding
- Working Directory and Path Confinement
- Terminal Profile and Environment
- Capability Manifest and Command Policy
- Professor Proposal and Action Card
- Podium Authorization and Dispatch
- HERMIT Terminal Execution Cell
- Shell Adapter and Command Invocation
- Input Editor and Parser
- Completion and Command Discovery
- PTY Process and Job Control
- Standard Streams Multiplexer
- Structured Diagnostics and Illuminator View
- Exit Status and Result Capture
- History Recall and Reproducible Replay
- Tabs Panes and Session Layout
- Search Filter Copy and Export
- Artifact Links Diffs and Preview Handoff
- Secrets Redaction and Injection Defense
- Network and Air Gap Indicator
- Resource Budget Timeout and Cancellation
- Checkpoint Reconnect and Recovery
- Localization Accessibility and Large Output Windows
- LANDON Run Run All and Review Control
- SOPHIA Evaluation and Accepted Learning
- CHARLOTTE Construction and Terminal Inspection
- Evidence Archive and Filing
- Final Validation and Compatibility Report
