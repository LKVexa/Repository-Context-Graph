# 13. Chair — JA Security Policy Language

This package contains five independent `.jasec` policy scripts:

1. **Authorization** — governs evaluation of an authorization request and issue of the resulting capability.
2. **Policy gates** — governs admission through a policy gate and the decision that opens it.
3. **No autorun** — denies an autorun effect outright and requires approval before any process start.
4. **Deterministic safety** — governs safety evaluation and replay verification before execution.
5. **Validation** — governs artifact validation and provenance reading before admission.

## Suite roles

| Layer | Chair responsibility |
|---|---|
| SOPHIA | Evaluates the requested action against declared semantics and safety judgments |
| CHARLOTTE | Constructs and inspects the decision record and its comparison boundaries |
| LANDON | Requests the approved effect and integrates the authorized outcome |
| Professor | Audits evidence, provenance, and privileged effects |
| Podium | Applies the final authorization, gate, or admission decision |

## Corpus alignment

Every script follows the attached corpus pattern: `ja source 0.3`, `use Security`, `policy no_network`, a named principal, a capability-bearing role, a restricted resource, default network denial, a scoped rule, human approval for the privileged step, privileged-effect auditing, secret redaction, explicit-deny precedence, a positive corpus-style secret-leak assertion, and MCRT decision emission.

`13_chair_no_autorun.jasec` is the one script whose scoped rule is a `deny` rather than an `allow`: the autorun effect has no authorized form, so the role that can inspect a process is still refused the effect itself.

## Execution boundary

JA Security Policy Language is a policy-decision language. These scripts decide and record; they do not start processes, admit artifacts, open gates, issue capabilities, or run replays. An approved worker performs the effect only after a successful decision, and returns the decision reference, the effect's stable artifact ID, its provenance chain, and the MCRT decision reference.

Unknown code, undeclared network access, missing human approval, missing provenance, and rule conflicts must fail closed. Chair authorizes; it never executes.

## Suggested review order

Read the scripts in this order: no autorun, policy gates, authorization, deterministic safety, validation — refusal first, then admission, then what admission is allowed to authorize.
