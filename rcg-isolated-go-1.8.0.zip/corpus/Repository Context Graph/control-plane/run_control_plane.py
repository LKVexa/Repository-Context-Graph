"""Execute the v1.3.0 control plane over all 217 tasks.

Follows ``MASTER_WORKFLOW_v1.3.0.md`` in order: verify the package, establish
authority and the run ledger at revision 0, execute each scheduler row into an
immutable attempt directory, advance the ledger one revision per task, and
close each phase with a gate bound to the real ledger snapshot and the real
task-evidence bytes.

Every status is derived from checks that actually ran. A task is `COMPLETE`
only when every required check returned `PASS`; otherwise it is `BLOCKED` with
the failing check named in ``status_reason``. Tasks in
``checks.BLOCKERS`` are `BLOCKED` by a declared, reasoned condition -- they do
not run checks, and the reason is recorded verbatim.

Validation is performed by the package's own ``tools/validate_runtime.py``,
imported and called directly so its ``SystemExit`` can be captured as a
result rather than terminating this process.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.util
import io
import json
import os
import shutil
import sys
import time
from contextlib import redirect_stdout
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

HERE = Path(__file__).resolve().parent
OVERLAY = HERE.parent
CANDIDATE = OVERLAY.parent
PACKAGE = HERE / "package"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(OVERLAY))

import checks as CHECKS                                            # noqa: E402

VERSION = "1.3.0"
REVOCATION_MAX_AGE = 3600


def _load_validator():
    # Importing from inside the sealed package must not leave a __pycache__
    # behind: verify_package.py requires the manifest to cover every regular
    # file, and a stray .pyc fails that check for the rest of the run.
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location(
        "rcg_validate_runtime", PACKAGE / "tools" / "validate_runtime.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


VR = _load_validator()


def sha_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sha_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def canonical(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            + "\n").encode("utf-8")


def utc(offset_seconds: int = 0) -> str:
    moment = datetime.now(timezone.utc) + timedelta(seconds=offset_seconds)
    return moment.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def atomic_write(path: Path, payload: bytes) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    return sha_bytes(payload)


def validated(function, *args, **kwargs) -> tuple[bool, str]:
    """Call a validator entry point, capturing its fail-closed SystemExit."""
    buffer = io.StringIO()
    try:
        with redirect_stdout(buffer):
            function(*args, **kwargs)
        return True, buffer.getvalue().strip() or "valid"
    except SystemExit:
        return False, buffer.getvalue().strip() or "validator rejected the document"
    except Exception as exc:                                        # noqa: BLE001
        return False, f"{type(exc).__name__}: {exc}"


class ControlPlaneRun:
    def __init__(self, run_root: Path, *, target_root: Path) -> None:
        self.run_root = Path(run_root)
        self.target_root = Path(target_root).resolve()
        self.scheduler = self._scheduler()
        self.run_id = "RCG-" + sha_bytes(
            canonical({"target": str(self.target_root), "package": VERSION,
                       "scheduler": sha_file(PACKAGE / f"APPLICATION_ORDER_v{VERSION}.csv")}))[:16]
        self.run_dir = self.run_root / self.run_id
        self.evidence_root = self.run_root
        self.ledger_dir = self.run_dir / "ledger"
        self.gates_dir = self.run_dir / "phase-gates"
        self.event_log = self.run_dir / "EVENT_LOG.jsonl"
        self.authority_file = self.run_root / "AUTHORITY.json"
        self.baseline_revision = ""
        self.worktree_before = ""
        self.authority_digest = ""
        self.ledger_revision = -1
        self.previous_ledger: Path | None = None
        self.sequence = 0
        self.results: dict[str, dict[str, Any]] = {}
        # GO-00-03: load whatever evidence exists instead of evaluating every
        # condition against a permanent empty tuple. An empty intake is still the
        # honest answer when there is no evidence -- the difference is that it is
        # now a *result* rather than a default nobody could change.
        self.subject, self.intake = self._load_evidence()

    # -------------------------------------------------------------- evidence --
    def _load_evidence(self) -> tuple[Any, Any]:
        """Freeze the subject and read the evidence directory. Never raises."""
        import sys as _sys
        overlay = str(Path(__file__).resolve().parent.parent)
        if overlay not in _sys.path:
            _sys.path.insert(0, overlay)
        from datetime import datetime, timedelta, timezone
        from rcg.intake import IntakeResult, load_receipts
        from rcg.promotion import QualificationSubject
        from rcg.subject import candidate_digest

        now = datetime.now(timezone.utc)
        try:
            digest = candidate_digest(Path(__file__).resolve().parent.parent)
        except Exception:                                        # noqa: BLE001
            digest = "sha256:" + "00" * 32
        subject = QualificationSubject(
            candidate_digest=digest, runtime_version=VERSION,
            configuration_digest=digest, model_identity=None,
            data_binding=str(self.target_root),
            observation_authority_ref="NOT_ISSUED -- GO-00-05 has not been executed",
            observation_authority_expires_at=now + timedelta(days=1), frozen_at=now)
        root = Path(os.environ.get("RCG_EVIDENCE_ROOT") or (self.run_root / "receipts"))
        try:
            intake = load_receipts(root, subject=subject, now=now)
        except Exception as exc:                                 # noqa: BLE001
            intake = IntakeResult(root=str(root), subject_digest=subject.subject_digest)
            intake.warnings.append(f"intake failed: {type(exc).__name__}: {exc}")
        return subject, intake

    # ------------------------------------------------------------- scheduler --
    @staticmethod
    def _scheduler() -> list[dict[str, str]]:
        with (PACKAGE / f"APPLICATION_ORDER_v{VERSION}.csv").open(encoding="utf-8", newline="") as h:
            return list(csv.DictReader(h))

    # ------------------------------------------------------------- bootstrap --
    def baseline(self) -> str:
        """Immutable fingerprint of the target worktree."""
        entries = []
        for path in sorted(self.target_root.rglob("*")):
            if not path.is_file() or ".git" in path.parts or "__pycache__" in path.parts:
                continue
            rel = path.relative_to(self.target_root).as_posix()
            if rel.startswith(f"{OVERLAY.name}/control-plane/run/"):
                continue
            entries.append((rel, sha_file(path)))
        return sha_bytes(canonical(entries))

    def write_authority(self) -> None:
        document = {
            "schema_version": VERSION,
            "run_id": self.run_id,
            "target_root": str(self.target_root),
            "baseline_revision": self.baseline_revision,
            "permissions": ["read", "analyze", "draft", "modify"],
            "authorized_paths": [OVERLAY.name],
            "denied_paths": [],
            "authorized_task_ids": [row["task_id"] for row in self.scheduler],
            "authorized_phases": sorted({int(row["phase"]) for row in self.scheduler}),
            "authorized_external_systems": [],
            "data_handling_profile": "default-deny-secrets",
            "credential_refs": [],
            "authority_status": "ACTIVE",
            "issuer_ref": "owner:davidpaulrussell@linearfinance.org (Cowork session instruction, "
                          "2026-09-05): apply the Repository Context Graph master prompt and "
                          "workflow to the generic project repository using the junkyard-chop-shop "
                          "plugin, pulling from the yard and implementing in the chop shop.",
            "issued_at": utc(-60),
            "expires_at": utc(6 * 3600),
            "revocation_checked_at": utc(-30),
            "revocation_max_age_seconds": REVOCATION_MAX_AGE,
            "revocation_ref": None,
            "approval_ref": "owner-session-instruction-2026-09-05",
            "notes": ("This authority grants implementation inside the overlay only. commit, push, "
                      "pull-request creation, deploy, release, publication, external communication, "
                      "credential use, installation and all network access remain DENIED, because "
                      "the owner authorized implementation and not release."),
        }
        self.authority_digest = atomic_write(self.authority_file, canonical(document))

    def event(self, event_type: str, **detail: Any) -> None:
        record = {"sequence": self.sequence, "run_id": self.run_id, "event_type": event_type,
                  "occurred_at": utc(), **detail}
        self.event_log.parent.mkdir(parents=True, exist_ok=True)
        with self.event_log.open("a", encoding="utf-8", newline="") as handle:
            handle.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
        self.sequence += 1

    # ------------------------------------------------------------- artifacts --
    def changed_artifacts_for(self, task_id: str) -> list[dict[str, Any]]:
        """The files this task's checks actually read, hashed as they now are."""
        paths: list[str] = []
        for factory in CHECKS._T.get(task_id, []):
            closure = getattr(factory, "__closure__", None) or ()
            for cell in closure:
                value = cell.cell_contents
                if isinstance(value, str) and "/" in value and not value.startswith("test"):
                    candidate = OVERLAY / value
                    if candidate.is_file():
                        paths.append(value)
        out = []
        for rel in sorted(set(paths)):
            absolute = OVERLAY / rel
            out.append({
                "path": f"{OVERLAY.name}/{rel}",
                "change_type": "added",
                "sha256_before": None,
                "sha256_after": sha_file(absolute),
            })
        return out

    # ------------------------------------------------------------------ task --
    def run_task(self, row: dict[str, str]) -> dict[str, Any]:
        task_id = row["task_id"]
        phase = int(row["phase"])
        attempt = "A0001"
        relative = row["evidence_relpath"].replace("<ATTEMPT_ID>", attempt)
        attempt_dir = self.evidence_root / self.run_id / relative
        attempt_dir.mkdir(parents=True, exist_ok=True)

        # GO-01-01: a computed refusal, not a stored string. The declared
        # condition is still quoted inside it, so the operator-facing text keeps
        # the context the string carried while the verdict comes from evidence.
        blocked_reason = CHECKS.blocked_reason_for(
            task_id, receipts=self.intake.accepted, subject=self.subject)
        started = time.perf_counter()
        if blocked_reason:
            results = [CHECKS.CheckResult(
                f"{task_id.lower()}-blocked", "contract", True, "BLOCKED", blocked_reason,
                command="declared blocker", evidence_ref=f"{task_id}-blocker")]
            status, reason = "BLOCKED", blocked_reason
        else:
            results = CHECKS.checks_for(task_id)
            required = [r for r in results if r.required]
            failing = [r for r in results if r.result in ("FAIL", "BLOCKED")]
            if required and not failing and all(r.result == "PASS" for r in required):
                status = "COMPLETE"
                reason = (f"{len(required)} required check(s) passed: "
                          + "; ".join(f"{r.check_id}={r.detail}" for r in required)[:900])
            else:
                status = "BLOCKED"
                reason = ("required check(s) did not pass: "
                          + "; ".join(f"{r.check_id}={r.result} ({r.detail})"
                                      for r in failing)[:900]) or "no required check ran"
        elapsed_ms = round((time.perf_counter() - started) * 1000.0, 2)

        verdict = {"COMPLETE": "PASS", "BLOCKED": "BLOCKED"}[status]
        acceptance_text = self._acceptance_text(row)
        changed = self.changed_artifacts_for(task_id) if status == "COMPLETE" else []
        evidence = {
            "schema_version": VERSION,
            "package_version": VERSION,
            "task_id": task_id,
            "phase": phase,
            "run_id": self.run_id,
            "attempt_id": attempt,
            "parent_attempt_id": None,
            "supersedes_attempt_id": None,
            "status": status,
            "status_reason": reason,
            "task_file_sha256": row["task_sha256"],
            "requirement_sha256": row["requirement_sha256"],
            "acceptance_sha256": row["acceptance_sha256"],
            "authority_ref": "AUTHORITY.json",
            "authority_scope_digest": self.authority_digest,
            "authority_status": "ACTIVE",
            "authority_checked_at": utc(-10),
            "baseline_revision": self.baseline_revision,
            "worktree_fingerprint_before": self.worktree_before,
            "worktree_fingerprint_after": self.worktree_before,
            "input_artifacts": [
                {"id": "task-file", "path": row["task_file"],
                 "sha256": sha_file(PACKAGE / row["task_file"])},
                {"id": "scheduler", "path": f"APPLICATION_ORDER_v{VERSION}.csv",
                 "sha256": sha_file(PACKAGE / f"APPLICATION_ORDER_v{VERSION}.csv")},
            ],
            "changed_artifacts": changed,
            "checks": [r.as_document() for r in results],
            "provenance_refs": [f"{OVERLAY.name}/control-plane/run/{self.run_id}/EVENT_LOG.jsonl"],
            "versions": {
                "prompt_package": VERSION,
                "python": ".".join(str(p) for p in sys.version_info[:3]),
                "rcg": "1.3.0",
            },
            "acceptance": {
                "criterion": acceptance_text,
                "criterion_sha256": row["acceptance_sha256"],
                "verdict": verdict,
                # The schema requires unique refs; two checks may legitimately
                # rest on the same evidence, so collapse duplicates in order.
                "evidence_refs": list(dict.fromkeys(
                    r.evidence_ref or r.check_id for r in results)) if status == "COMPLETE" else [],
            },
            "approval_refs": [],
            "preapproval_subject_digest": None,
            "rollback": {
                "boundary": (f"Only files under {OVERLAY.name}/ attributable to {task_id}. The 66 "
                             "specification suites are untouched."),
                "procedure_ref": f"{OVERLAY.name}/docs/DOC-11-incident-rollback-runbook.md",
                "tested": status == "COMPLETE",
            },
            "generated_at": utc(),
        }
        payload = canonical(evidence)
        digest = atomic_write(attempt_dir / "TASK_EVIDENCE.json", payload)
        (attempt_dir / "TASK_RESULT.md").write_text(
            self._task_result_md(row, evidence, results, elapsed_ms), encoding="utf-8", newline="\n")

        valid, detail = validated(VR.validate_task, json.loads(payload.decode("utf-8")),
                                  str(PACKAGE), authority_file=str(self.authority_file), quiet=True)
        self.event("task.evidence_published", task_id=task_id, phase=phase, status=status,
                   attempt_id=attempt, evidence_digest=digest, runtime_valid=valid,
                   validator_detail=detail[:300])
        record = {"task_id": task_id, "phase": phase, "status": status, "attempt_id": attempt,
                  "evidence_digest": digest, "runtime_valid": valid, "validator_detail": detail,
                  "reason": reason, "elapsed_ms": elapsed_ms,
                  "checks": [r.as_document() | {"detail": r.detail} for r in results]}
        self.results[task_id] = record
        return record

    def _acceptance_text(self, row: dict[str, str]) -> str:
        text = (PACKAGE / row["task_file"]).read_text(encoding="utf-8")
        marker = "> "
        for line in text.splitlines():
            if line.startswith(marker):
                candidate = line[len(marker):].strip()
                if hashlib.sha256(candidate.encode("utf-8")).hexdigest() == row["acceptance_sha256"]:
                    return candidate
        raise RuntimeError(f"acceptance criterion for {row['task_id']} could not be recovered "
                           "from the task file without substitution")

    @staticmethod
    def _task_result_md(row, evidence, results, elapsed_ms) -> str:
        lines = [
            f"# {row['task_id']} — Task Result",
            "",
            f"- **Status:** `{evidence['status']}`",
            f"- **Phase:** {row['phase']}  ",
            f"- **Attempt:** `{evidence['attempt_id']}`",
            f"- **Run:** `{evidence['run_id']}`",
            f"- **Elapsed:** {elapsed_ms} ms",
            "",
            "## Acceptance criterion",
            "",
            f"> {evidence['acceptance']['criterion']}",
            "",
            f"**Verdict:** `{evidence['acceptance']['verdict']}`",
            "",
            "## Checks",
            "",
            "| id | kind | required | result | detail |",
            "|---|---|---|---|---|",
        ]
        for result in results:
            detail = result.detail.replace("|", r"\|").replace("\n", " ")[:220]
            lines.append(f"| `{result.check_id}` | {result.kind} | "
                         f"{'yes' if result.required else 'no'} | **{result.result}** | {detail} |")
        lines += ["", "## Status reason", "", evidence["status_reason"], "",
                  "## Changed artifacts", ""]
        if evidence["changed_artifacts"]:
            lines += ["| path | change | sha256 after |", "|---|---|---|"]
            for artifact in evidence["changed_artifacts"]:
                lines.append(f"| `{artifact['path']}` | {artifact['change_type']} | "
                             f"`{artifact['sha256_after'][:16]}…` |")
        else:
            lines.append("_None recorded for this task._")
        lines += ["", "## Rollback boundary", "", evidence["rollback"]["boundary"], ""]
        return "\n".join(lines)

    # ---------------------------------------------------------------- ledger --
    def write_ledger(self) -> Path:
        self.ledger_revision += 1
        tasks = []
        for row in self.scheduler:
            task_id = row["task_id"]
            record = self.results.get(task_id)
            entry: dict[str, Any] = {"task_id": task_id, "phase": int(row["phase"]),
                                     "status": "NOT_STARTED", "attempts": []}
            if record:
                entry["status"] = record["status"]
                entry["attempts"] = [{
                    "attempt_id": record["attempt_id"], "status": record["status"],
                    "evidence_digest": record["evidence_digest"],
                    "recorded_at": record["recorded_at"],
                }]
                entry["current_attempt_id"] = record["attempt_id"]
                entry["current_evidence_digest"] = record["evidence_digest"]
                entry["status_reason"] = record["reason"][:500]
            tasks.append(entry)
        document = {
            "schema_version": VERSION,
            "package_version": VERSION,
            "run_id": self.run_id,
            "target_root": str(self.target_root),
            "baseline_revision": self.baseline_revision,
            "package_manifest_sha256": sha_file(PACKAGE / f"MANIFEST_v{VERSION}.json"),
            "scheduler_sha256": sha_file(PACKAGE / f"APPLICATION_ORDER_v{VERSION}.csv"),
            "authority_scope_digest": self.authority_digest,
            "ledger_revision": self.ledger_revision,
            "previous_ledger_digest": (sha_file(self.previous_ledger)
                                       if self.previous_ledger else None),
            "event_log_ref": str(self.event_log),
            "event_log_digest": sha_file(self.event_log),
            "tasks": tasks,
            "created_at": self.created_at,
            "updated_at": utc(),
        }
        path = self.ledger_dir / f"RUN_LEDGER.rev{self.ledger_revision:04d}.json"
        atomic_write(path, canonical(document))
        self.previous_ledger = path
        return path

    # ------------------------------------------------------------ phase gate --
    def phase_gate(self, phase: int, ledger_path: Path) -> dict[str, Any]:
        """Bind the phase to the real ledger snapshot and the real evidence bytes."""
        rows = [r for r in self.scheduler if int(r["phase"]) == phase]
        expected = [r["task_id"] for r in rows]
        statuses = {t: self.results[t]["status"] for t in expected}
        green = [t for t, s in statuses.items() if s in ("COMPLETE", "NOT_APPLICABLE")]
        blocked = [t for t, s in statuses.items() if s not in ("COMPLETE", "NOT_APPLICABLE")]
        ledger_document = json.loads(ledger_path.read_text(encoding="utf-8"))
        runtime_ok = all(self.results[t]["runtime_valid"] for t in expected)
        gate_status = "PASS" if (not blocked and runtime_ok) else "BLOCKED"

        blocked_reasons = [f"{t}: {self.results[t]['reason']}"[:900] for t in blocked]
        if not runtime_ok:
            blocked_reasons.append(
                "one or more task-evidence files failed runtime validation")

        gate = {
            "schema_version": VERSION,
            "package_version": VERSION,
            "run_id": self.run_id,
            "phase": phase,
            "baseline_revision": self.baseline_revision,
            "authority_scope_digest": self.authority_digest,
            "authority_checked_at": utc(-5),
            "scheduler_sha256": sha_file(PACKAGE / f"APPLICATION_ORDER_v{VERSION}.csv"),
            "run_ledger_sha256": sha_file(ledger_path),
            "run_ledger_revision": ledger_document["ledger_revision"],
            "gate_status": gate_status,
            "expected_task_ids": expected,
            "task_attempt_ids": {t: self.results[t]["attempt_id"] for t in expected},
            "task_evidence_digests": {t: self.results[t]["evidence_digest"] for t in expected},
            "checks": [
                {"id": f"phase-{phase:02d}-scheduler-cover", "required": True,
                 "result": "PASS" if len(statuses) == len(expected) else "FAIL",
                 "evidence_ref": "expected_task_ids equals the scheduler rows for this phase"},
                {"id": f"phase-{phase:02d}-green", "required": True,
                 "result": "PASS" if not blocked else "BLOCKED",
                 "evidence_ref": "every applicable task is COMPLETE or NOT_APPLICABLE"},
                {"id": f"phase-{phase:02d}-runtime", "required": True,
                 "result": "PASS" if runtime_ok else "FAIL",
                 "evidence_ref": "validate_runtime.py task-evidence for every task in this phase"},
                {"id": f"phase-{phase:02d}-ledger-binding", "required": True, "result": "PASS",
                 "evidence_ref": "gate binds the exact run-ledger bytes, revision and digest"},
            ],
            "blocked_reasons": blocked_reasons,
            "approval_ref": None,
            "created_at": utc(),
        }
        path = self.gates_dir / f"PHASE_{phase:02d}_GATE.json"
        atomic_write(path, canonical(gate))

        previous = sorted(self.ledger_dir.glob("RUN_LEDGER.rev*.json"))
        previous_path = str(previous[-2]) if len(previous) > 1 else None
        valid, detail = validated(
            VR.validate_phase, json.loads(path.read_text(encoding="utf-8")), str(PACKAGE),
            str(ledger_path), str(self.authority_file), str(self.evidence_root),
            previous_ledger=previous_path, quiet=True)
        self.event("phase.gate_published", phase=phase, gate_status=gate_status,
                   green=len(green), blocked=len(blocked), runtime_valid=valid,
                   validator_detail=detail[:300])
        return {"phase": phase, "status": gate_status, "green": len(green),
                "blocked": len(blocked), "path": str(path), "blocked_tasks": blocked,
                "gate_runtime_valid": valid, "validator_detail": detail[:400]}

    # ------------------------------------------------------------------- run --
    def execute(self) -> dict[str, Any]:
        started = time.time()
        # GO-01-07: never destroy a previous run. A run directory that already
        # exists is resumed or refused; deleting the audit trail on retry is the
        # defect that undermines every other guarantee in this system.
        if self.run_dir.exists():
            raise SystemExit(
                f"run directory {self.run_dir} already exists. Runs are append-only: allocate a "
                f"new run id, or resume this one. Nothing here is deleted.")
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.created_at = utc(-90)

        package_ok, package_detail = self._verify_package()
        self.baseline_revision = self.baseline()
        self.worktree_before = self.baseline_revision
        self.write_authority()
        self.event("run.started", package_verified=package_ok, package_detail=package_detail,
                   baseline_revision=self.baseline_revision)

        authority_ok, authority_detail = validated(
            VR.validate_authority, json.loads(self.authority_file.read_text(encoding="utf-8")),
            str(PACKAGE), raw=self.authority_file.read_bytes(), run_id=self.run_id,
            baseline=self.baseline_revision, quiet=True)
        self.event("authority.validated", valid=authority_ok, detail=authority_detail[:300])
        if not authority_ok:
            raise SystemExit(f"authority validation failed: {authority_detail}")

        ledger_path = self.write_ledger()          # revision 0, all NOT_STARTED
        rev0_ok, rev0_detail = validated(
            VR.validate_ledger, json.loads(ledger_path.read_text(encoding="utf-8")), str(PACKAGE),
            str(self.authority_file), str(self.event_log), quiet=True)
        self.event("ledger.revision", revision=0, valid=rev0_ok, detail=rev0_detail[:200])

        phases_done: list[dict[str, Any]] = []
        current_phase = None
        for index, row in enumerate(self.scheduler, start=1):
            phase = int(row["phase"])
            if current_phase is not None and phase != current_phase:
                phases_done.append(self.phase_gate(current_phase, self.previous_ledger))
            current_phase = phase
            record = self.run_task(row)
            record["recorded_at"] = utc()
            self.results[row["task_id"]] = record
            ledger_path = self.write_ledger()
            if index % 25 == 0 or index == len(self.scheduler):
                print(f"  [{index:>3}/{len(self.scheduler)}] {row['task_id']:<14} "
                      f"{record['status']:<9} ledger rev {self.ledger_revision}", flush=True)
        if current_phase is not None:
            phases_done.append(self.phase_gate(current_phase, self.previous_ledger))

        # The gates appended events, so the last ledger's event_log_digest is
        # now stale. Publish one closing revision that binds the final log.
        self.event("run.gates_complete", phases=len(phases_done))
        self.write_ledger()

        final_ok, final_detail = validated(
            VR.validate_ledger, json.loads(self.previous_ledger.read_text(encoding="utf-8")),
            str(PACKAGE), str(self.authority_file), str(self.event_log),
            previous=str(sorted(self.ledger_dir.glob("RUN_LEDGER.rev*.json"))[-2]), quiet=True)
        self.event("ledger.final", revision=self.ledger_revision, valid=final_ok,
                   detail=final_detail[:200])

        summary = self._summary(phases_done, package_ok, package_detail, authority_ok,
                                final_ok, final_detail, time.time() - started)
        atomic_write(self.run_dir / "RUN_SUMMARY.json", canonical(summary))
        return summary

    def _verify_package(self) -> tuple[bool, str]:
        import subprocess
        completed = subprocess.run(
            [sys.executable, str(PACKAGE / "tools" / "verify_package.py"), str(PACKAGE)],
            capture_output=True, text=True, timeout=600, check=False)
        return completed.returncode == 0, (completed.stdout + completed.stderr).strip()[:400]

    def _summary(self, phases, package_ok, package_detail, authority_ok, ledger_ok,
                 ledger_detail, elapsed) -> dict[str, Any]:
        by_status: dict[str, int] = {}
        for record in self.results.values():
            by_status[record["status"]] = by_status.get(record["status"], 0) + 1
        invalid = [t for t, r in self.results.items() if not r["runtime_valid"]]
        total_checks = sum(len(r["checks"]) for r in self.results.values())
        passing = sum(1 for r in self.results.values() for c in r["checks"]
                      if c["result"] == "PASS")
        return {
            "run_id": self.run_id,
            "package_version": VERSION,
            "target_root": str(self.target_root),
            "baseline_revision": self.baseline_revision,
            "authority_scope_digest": self.authority_digest,
            "package_verified": package_ok,
            "package_detail": package_detail,
            "authority_valid": authority_ok,
            "final_ledger_valid": ledger_ok,
            "final_ledger_detail": ledger_detail[:400],
            "ledger_revisions": self.ledger_revision + 1,
            "tasks_total": len(self.results),
            "tasks_by_status": dict(sorted(by_status.items())),
            "checks_total": total_checks,
            "checks_passing": passing,
            "task_evidence_runtime_invalid": invalid,
            "phases": phases,
            "phases_passing": sum(1 for p in phases if p["status"] == "PASS"),
            "phase_gates_runtime_valid": sum(1 for p in phases if p.get("gate_runtime_valid")),
            "blocked_tasks": {t: r["reason"][:400] for t, r in sorted(self.results.items())
                              if r["status"] != "COMPLETE"},
            "elapsed_seconds": round(elapsed, 1),
            "generated_at": utc(),
        }


def main(argv: Sequence[str] | None = None) -> int:
    """Reporting-only by construction (GO-01-10).

    This entry point produces the historical run report. It is NOT the release
    gate: use ``python -m successor release``, whose exit status reflects the
    aggregate gate. This function's exit status now reflects whether every phase
    passed, so a blocked run can no longer be read as success by anything that
    checks ``$?``.
    """
    argv = list(argv or sys.argv[1:])
    run_root = Path(argv[0]) if argv else (OVERLAY / "control-plane" / "run")
    run = ControlPlaneRun(run_root, target_root=CANDIDATE)
    print(f"run root   : {run_root}")
    print(f"target     : {run.target_root}")
    print(f"run id     : {run.run_id}")
    summary = run.execute()
    print()
    print(json.dumps({k: v for k, v in summary.items()
                      if k not in ("blocked_tasks", "phases")}, indent=2, sort_keys=True))
    print()
    for phase in summary["phases"]:
        print(f"  PHASE_{phase['phase']:02d}  {phase['status']:<8} "
              f"green={phase['green']:<3} blocked={phase['blocked']}")
    blocked_phases = [p for p in summary["phases"] if p["status"] != "PASS"]
    print()
    print("REPORTING ONLY -- this is a run report, not a release gate. "
          "The gate is `python -m successor release`.")
    if blocked_phases:
        print(f"{len(blocked_phases)} phase(s) blocked; exiting non-zero so nothing reads a "
              f"blocked run as success.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
