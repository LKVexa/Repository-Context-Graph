# Changelog v1.3.0

## Changed / hardened
- Bound green task evidence to SHA-256 of the exact authority-contract file bytes and required an authority reference.
- Added semantic authority/approval revocation chronology and maximum-freshness enforcement.
- Made `ACTIVE + APPROVE` mandatory for usable approvals; `REJECT` now fails closed as authorization.
- Added explicit required/optional check semantics and skip-reason requirements.
- Added authorized-path and actual after-state hash verification for green changed-artifact evidence.
- Bound run ledgers to the actual package manifest, scheduler, authority, event log, run/target/baseline, immutable attempt history, and previous-ledger chain.
- Bound phase gates to the actual run-ledger bytes/revision and actual current task-evidence bytes.
- Required a deterministic externally approved `RELEASE` subject for Phase 12 `PASS`.
- Pinned the immutable source SHA-256 in the package manifest and added source-record reconstruction/cross-checking to package verification.
- Added JSON Schema self-validation plus shipped-example schema validation to package verification.
- Added strict manifest control-metadata validation.
- Expanded task instructions and master control documents to require the same semantic bindings enforced by tooling.

## Added
- `tools/self_test_runtime.py` adversarial runtime regression suite.
- `templates/RUN_LEDGER.example.json` and `templates/EVENT_LOG.example.jsonl`.
- `requirements-validation.txt` for a pre-provisioned validation dependency.
- `HARDENING_TEST_MATRIX_v1.3.0.md` documenting reproduced false-greens and regression coverage.

## Fixed from v1.2.0
- Active `REJECT` approvals were accepted by the semantic validator.
- Pre-issuance/stale authority revocation checks could pass.
- Fabricated `COMPLETE` task evidence could pass with an invented authority digest.
- Fabricated phase `PASS` could pass without proving attempt/evidence references existed.
- Fabricated all-green run ledgers could point at nonexistent current attempts.
- Recomputed manifests could conceal immutable-source mutation, invalid shipped examples, and falsified manifest task/phase/source metadata.

## Compatibility
All 217 authoritative task IDs, titles, phases, source requirements, implementation actions, deliverables, acceptance criteria, and phase objectives remain unchanged. v1.3.0 is intentionally stricter for evidence/control records that v1.2.0 could falsely accept.
