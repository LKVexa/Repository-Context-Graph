# Package Self-Audit v1.3.0

**Audit target:** final v1.3.0 package tree prior to archive construction  
**Requirements baseline:** immutable v1.0.0 audited TODO  
**Source SHA-256:** `92a9632a75f2ae787394d38b1cee19df92d9613cd2cb2c87f8f52f633cf9674b`

## Inventory and preservation
- Source task count: **217**
- Dedicated task prompt/workflow files: **217**
- Consolidated phase series: **13**
- Unique scheduler task IDs: **217**
- Application-order rows: **217**
- RTM seed rows: **217**
- Machine-readable control schemas: **5**
- Shipped JSON/JSONL examples: **6 JSON + 1 JSONL event-log seed**
- Runtime/package tools: **4**
- Authoritative task-record preservation: **PASS — 0/217 record drifts**
- Immutable source baseline hash: **PASS**

## Validation status
- Primary package verifier: **PASS**
- Verifier adversarial/negative self-tests: **PASS**
- Runtime positive + adversarial/negative self-tests: **PASS**
- JSON Schema meta-validation: **PASS**
- Shipped JSON examples vs matching schemas: **PASS**
- Scheduler/RTM/task/source cross-binding: **PASS**
- Consolidated phase-series exact task embedding: **PASS**
- Archive/path/duplicate/special-member controls: **PASS in verifier regression suite**

`RUN_LEDGER.example.json` is intentionally a structural seed, not a claim that an example run has operationally completed; semantic run-ledger validation is exercised by `tools/self_test_runtime.py` using real package/scheduler/authority/event-log digests.

## Phase counts
- Phase 0: 18
- Phase 1: 15
- Phase 2: 25
- Phase 3: 7
- Phase 4: 5
- Phase 5: 4
- Phase 6: 25
- Phase 7: 22
- Phase 8: 19
- Phase 9: 21
- Phase 10: 29
- Phase 11: 18
- Phase 12: 9

## v1.3.0 fail-closed invariants
- Usable approvals require `ACTIVE + APPROVE`; an active `REJECT` is rejected as authorization.
- Authority and approval revocation checks must be chronological and fresh under `revocation_max_age_seconds`.
- Green task evidence is bound to SHA-256 of the exact referenced authority-file bytes.
- Required checks must pass for green promotion; optional skips require explicit reasons.
- Green changed-artifact paths must be authorized and after-state digests must match actual target bytes.
- Terminal run-ledger current pointers must resolve to the real latest immutable attempts and matching evidence digests.
- Run-ledger revisions bind previous-ledger bytes and the actual package manifest, scheduler, authority, event log, run, target, and baseline.
- Phase `PASS` binds the actual run-ledger snapshot and actual current task-evidence bytes.
- Phase 12 `PASS` requires an external `RELEASE` approval bound to the deterministic phase candidate.
- Recomputed manifest hashes cannot legitimize immutable-source mutation, invalid shipped examples, or falsified manifest control metadata.
- ZIP special/symlink members, unsafe/colliding paths, duplicate members/records/JSON keys, and archive-bomb patterns fail closed.
- In-package integrity is not represented as publisher authentication.

## Adversarial regression coverage
See `HARDENING_TEST_MATRIX_v1.3.0.md`. The final release is accepted only when `tools/verify_package.py`, `tools/self_test_verifier.py`, and `tools/self_test_runtime.py` pass against the final manifest/package state.

**Final control verdict:** **PASS**, subject to verification of the exact emitted archive/sidecar bytes after archive construction.
