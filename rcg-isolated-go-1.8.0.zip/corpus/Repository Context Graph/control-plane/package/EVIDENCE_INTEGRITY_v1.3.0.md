# Evidence Integrity and Attempt Semantics v1.3.0

## 1. Immutable attempts
Each execution receives a fresh monotonic `ATTEMPT_ID` (`A0001`, `A0002`, …) under `<EVIDENCE_ROOT>/<RUN_ID>/PHASE_XX/<TASK_ID>/attempts/<ATTEMPT_ID>/`. Prior attempts are append-only historical evidence and may be superseded/invalidated, never overwritten.

## 2. Hash definitions
- **File digest:** SHA-256 over exact file bytes.
- **Authority-scope digest:** SHA-256 over exact UTF-8 authority-contract file bytes. Formatting changes therefore intentionally change the binding.
- **Requirement digest:** SHA-256 over UTF-8 exact source-requirement text recorded by the package after removing only the task-file `(source line N)` annotation.
- **Acceptance digest:** SHA-256 over UTF-8 exact acceptance-criterion text.
- **Task digest:** SHA-256 over exact dedicated task-file bytes.
- **Final evidence digest:** SHA-256 over exact finalized `TASK_EVIDENCE.json` bytes; stored outside that file in ledger/RTM.
- **Run-ledger digest:** when referenced by a phase gate, SHA-256 over exact run-ledger file bytes.
- **Event-log digest:** SHA-256 over exact event-log bytes at the ledger revision being validated.

## 3. RCG canonical candidate JSON
For approval candidate digests, v1.3.0 serializes JSON as UTF-8 using: object keys sorted ascending; no insignificant whitespace; separators `,` and `:`; Unicode emitted directly; and one final LF. The package implementation is `json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"`. Runtime contract values contain no floating-point fields.

For task approval, compute the candidate over a copy of `TASK_EVIDENCE` with `approval_refs=[]` and `preapproval_subject_digest=null`. For phase approval, compute over a copy of `PHASE_GATE_EVIDENCE` with `approval_ref=null`. `tools/validate_runtime.py candidate-digest ...` is the reference implementation.

## 4. Approval subject digest
Approval `subject_digest` uses the length-prefixed `RCG-APPROVAL-SUBJECT-v1` encoding implemented by `approval_subject_digest()` in `tools/validate_runtime.py`. It binds, in fixed order: subject kind, run ID, task ID, phase, authority digest, scope digest, baseline revision, candidate evidence digest, and optional diff digest. Length prefixes remove delimiter ambiguity; material change yields a different digest.

## 5. Current-attempt and ledger semantics
A final run-ledger task state must point to a real latest attempt record with identical final status/evidence digest. Attempt IDs and timestamps are monotonic. For ledger revision >0, `previous_ledger_digest` must hash the prior ledger snapshot, the revision increments by exactly one, immutable run fields remain fixed, and every prior task-attempt history is an exact prefix of the new history.

## 6. Phase exact-cover semantics
A passing phase gate binds the exact scheduler hash, exact run-ledger file hash/revision, expected task order, each current attempt ID/evidence digest, and the actual task-evidence file bytes under the run evidence root. Key coverage alone is insufficient.

## 7. Atomic publication
Write structured evidence and ledger updates to a temporary sibling, flush/sync where available, validate, then atomically rename/replace. Never advance current pointers or green state from a partial file.

## 8. Integrity versus authenticity
Manifest hashes, source/task cross-checks, runtime bindings, and archive sidecars detect accidental or unauthorized changes relative to supplied bytes. They do not independently prove publisher identity. Authenticity requires trusted distribution or signature verification.
