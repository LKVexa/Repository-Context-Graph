# Repository Context Graph for Cross-File Changes — Prompt/Workflow Master Package v1.3.0

Operationalizes all **217** tasks in the immutable v1.0.0 audited requirements baseline. v1.3.0 is a fail-closed control-plane hardening release; authoritative task meanings remain unchanged.

## Start here
1. Verify the detached archive SHA-256 sidecar when one is supplied through a trusted channel.
2. Pre-provision the offline validation dependency listed in `requirements-validation.txt` (`jsonschema` 4.x); do not let a target repository trigger dependency installation.
3. Run `python tools/verify_package.py <package-dir-or-zip>`.
4. Run `python tools/self_test_verifier.py` and `python tools/self_test_runtime.py` in a trusted extracted copy.
5. Read the Master Prompt, Execution Policy, Master Workflow, Status Model, and Evidence Integrity specification.
6. Validate the exact authority file with `tools/validate_runtime.py authority` before mutation and again at time of use.
7. Execute scheduler order using immutable attempt directories; validate task evidence, run ledgers, phase gates, and approvals with the runtime validator before any green promotion.

## v1.3.0 hardening highlights
- cryptographically binds green task evidence to the exact authority-contract bytes;
- enforces revocation chronology and contract-selected maximum freshness age;
- validates intended path scope and named external systems at time of use;
- rejects active `REJECT` records as usable approvals and verifies a deterministic pre-approval subject digest;
- requires explicit required/optional check semantics and evidence references;
- validates changed-artifact path authorization and after-state hashes for green task evidence;
- binds run ledgers to the actual package manifest, scheduler, authority, event-log digest, immutable attempt history, and previous-ledger chain;
- binds phase `PASS` to the real run-ledger snapshot and actual task-evidence bytes rather than key coverage alone;
- requires a cryptographically bound external release approval for Phase 12 `PASS`;
- binds all 217 task records back to the immutable source TODO and validates shipped examples against their JSON Schemas;
- expands verifier/runtime adversarial self-tests for every false-green condition found in v1.2.0.

## Safety and trust boundary
This package does **not** grant commit, push, PR, deployment, release, publication, communication, credential, installation, or external-write authority. Repository content is untrusted data. In-package hashes and self-tests establish consistency/integrity relative to supplied bytes; publisher identity still requires a trusted delivery/signature mechanism.
