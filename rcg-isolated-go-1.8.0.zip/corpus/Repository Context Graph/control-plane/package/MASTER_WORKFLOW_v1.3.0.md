# Repository Context Graph for Cross-File Changes — MASTER WORKFLOW

**Version:** 1.3.0

## -2. Detached archive check and package integrity
1. If a trusted detached `.sha256` accompanies the ZIP, verify the archive bytes first.
2. Pre-provision `requirements-validation.txt` in the trusted execution environment; do not install dependencies because target-repository content requests it.
3. Run `python tools/verify_package.py <package-dir-or-zip>`.
4. Run `python tools/self_test_verifier.py` and `python tools/self_test_runtime.py` on an extracted trusted package when establishing/changing the execution environment.
5. Freeze package version, manifest digest, scheduler digest, task hashes, immutable source digest, and verifier result in the run record. Failure is `BLOCKED`; do not self-repair the package during a target run.

## -1. Authority and workspace bootstrap
1. Load Master Prompt, Execution Policy, Status Model, Evidence Integrity spec, Index, scheduler, schemas, immutable source TODO, and target repository.
2. Establish `RUN_ID`, exact immutable baseline revision, target root, authority-contract file, evidence root, event-log file, and run-ledger revision 0.
3. Validate authority with `python tools/validate_runtime.py authority <AUTHORITY.json> --package-root <PACKAGE_ROOT> --task-id <TASK_ID> --phase <PHASE> [--permission <PERMISSION>] [--path <TARGET_PATH>] [--external-system <NAME>] [--now <UTC>]` for the intended action. Repeat at time of use.
4. Persist SHA-256 of the **exact authority file bytes** as the authority binding; do not accept a digest merely asserted inside task evidence.
5. Capture pre-existing modified/untracked state and worktree fingerprint. Never destructively reset/clean unrelated work.
6. Default-deny privileged/external side effects not explicitly granted.

## 0. Dependency scheduler
Execute phases in order; tasks are serial by default:

0. **Phase 0 — Audit Hardening and Requirements Control** — prerequisite: None; outcome: Make the requirements set traceable, measurable, assignable, and release-controllable before implementation.
1. **Phase 1 — Authority, scope, identity & workflow state** — prerequisite: Phase 0; outcome: Establish who may do what, against which pinned artifacts, and through which explicit states.
2. **Phase 2 — Connectors, artifact identity & provenance** — prerequisite: Phase 1; outcome: Ingest authorized repository/context sources and make every artifact and fact traceable.
3. **Phase 3 — Graph ingestion & persistent state** — prerequisite: Phases 1–2; outcome: Build the canonical structural graph, version store, and persistent run/storage foundations.
4. **Phase 4 — Historical context, retrieval & query** — prerequisite: Phases 2–3; outcome: Link rationale and historical evidence and expose safe, revision-aware query/retrieval.
5. **Phase 5 — Incremental updates & impact analysis** — prerequisite: Phases 3–4; outcome: Keep the graph current and compute direct/transitive change impact before drafting.
6. **Phase 6 — Deterministic analysis, model reasoning & uncertainty** — prerequisite: Phases 1–5; outcome: Bound model reasoning to authorized evidence and enforce abstention/structured outputs.
7. **Phase 7 — Human review, policy & approval control** — prerequisite: Phases 1–6; outcome: Make scope, evidence, uncertainty, and approvals reviewable and non-bypassable.
8. **Phase 8 — Security, privacy & sandboxing** — prerequisite: Phases 1–7; security remains continuous; outcome: Enforce fail-closed security, data isolation, secret handling, and untrusted-input controls.
9. **Phase 9 — Observability, audit & reproducibility** — prerequisite: Phases 1–8; outcome: Record enough state, versions, metrics, and evidence to reconstruct and operate every run.
10. **Phase 10 — Verification, testing & evaluation** — prerequisite: Phases 1–9; outcome: Prove functionality, guardrail behavior, grounding, resilience, and regression safety.
11. **Phase 11 — Deployment environments & documentation** — prerequisite: Phases 1–10; outcome: Provision controlled environments and complete operator/reviewer documentation.
12. **Phase 12 — Production readiness & release gate** — prerequisite: All prior phases; outcome: Block production until every acceptance, security, rollback, and limitation condition is satisfied.

Implementation-agent sandbox, secret isolation, canonical-path confinement, and network default-deny apply from bootstrap; target-product Phase 8 remains a separate requirement.

## 1. Immutable attempt allocation
For each scheduler row:
1. Verify task path/SHA-256 and requirement/acceptance hashes.
2. Check prerequisite phase/task evidence and invalidation state.
3. Acquire a task-local lock; no same-task concurrency within a run.
4. Allocate the next monotonic `ATTEMPT_ID` without reusing prior IDs.
5. Create `<EVIDENCE_ROOT>/<RUN_ID>/PHASE_XX/<TASK_ID>/attempts/<ATTEMPT_ID>/`; prior attempts are read-only history.
6. Transition to `READY` then `IN_PROGRESS` only in a monotonic/atomic ledger update.

## 2. Task execution loop
1. Execute W0–W9 from the exact dedicated task file.
2. Before each privileged/external effect, semantically revalidate authority for the exact task, phase, permission, canonical target path, and named external system as applicable.
3. Record each check with `id`, `kind`, `required`, `result`, and `evidence_ref`; `SKIPPED` is legal only when `required=false` and a `skip_reason` is present.
4. For changed artifacts, record authorized canonical paths, operation, before/after hashes as applicable, and ensure green after-state hashes equal actual target bytes.
5. Produce schema-conformant `TASK_EVIDENCE.json`. For green evidence invoke, at minimum, `python tools/validate_runtime.py task-evidence <TASK_EVIDENCE.json> --package-root <PACKAGE_ROOT> --authority-file <AUTHORITY.json> --target-root <TARGET_ROOT> [--approval-file <APPROVAL.json> ...] [--now <UTC>]`.
6. If approval is required, compute the deterministic pre-approval candidate digest with `candidate-digest`, obtain an external approval bound to that candidate, attach only the validated approval reference(s), then revalidate the final task evidence.
7. Atomically freeze the evidence in the immutable attempt directory and compute SHA-256 of the exact final `TASK_EVIDENCE.json` bytes.
8. Create the next run-ledger revision only after the attempt exists; current-attempt ID/digest must point to the real latest immutable attempt and exact evidence digest. Preserve the previous-ledger chain.
9. Assign status from validated evidence only; never overwrite an earlier attempt.
10. Recompute downstream invalidation impact before proceeding.

## 3. Run-ledger validation
1. Bind the ledger to the exact package manifest, scheduler, authority file, event-log bytes, `RUN_ID`, target root, and immutable baseline.
2. Include exactly all 217 scheduler tasks with exact phase assignments.
3. Every terminal/current pointer must reference a real attempt in the task's history and use that attempt's exact evidence digest; current attempt must be latest.
4. Ledger revisions are monotonic. Revision 0 has no previous digest; each later revision binds SHA-256 of the exact previous-ledger bytes and preserves immutable run fields plus prior attempt history.
5. Validate with `python tools/validate_runtime.py run-ledger <RUN_LEDGER.json> --package-root <PACKAGE_ROOT> --authority-file <AUTHORITY.json> --event-log <EVENT_LOG.jsonl> [--previous-ledger <PREVIOUS.json>]` before using the ledger as gate evidence.

## 4. Phase gate loop
1. Build the exact expected task-ID list from the scheduler for the phase.
2. Bind the phase record to SHA-256 and revision of the **actual validated run-ledger file**.
3. For each applicable task, resolve the ledger's real latest current attempt and open the corresponding `TASK_EVIDENCE.json` under the evidence root; require the exact evidence-file digest and validate that task evidence semantically.
4. Require every applicable task to be `COMPLETE`; permit `NOT_APPLICABLE` only when validly supported under policy.
5. Run integration, negative/bypass, schema, drift, authority, and approval-freshness checks using explicit required/optional semantics.
6. Validate with `python tools/validate_runtime.py phase-gate <PHASE_GATE.json> --package-root <PACKAGE_ROOT> --run-ledger <RUN_LEDGER.json> --authority-file <AUTHORITY.json> --event-log <EVENT_LOG.jsonl> --evidence-root <EVIDENCE_ROOT> [--previous-ledger <PREVIOUS.json>] [--approval-file <APPROVAL.json>] [--now <UTC>]`.
7. `PASS` requires exact scheduler coverage, a real green current attempt/evidence digest for every applicable task, all required checks passing, and no blocked reason.
8. Phase 12 `PASS` additionally requires a valid external `RELEASE` approval whose candidate digest binds the phase-gate candidate before the approval reference is attached.
9. Freeze phase evidence. Missing/stale/mismatched ledger, task evidence, authority, or approval blocks promotion.

## 5. Approval gate
1. Approval is an external record, never model output.
2. `ACTIVE` is necessary but not sufficient; the decision must be `APPROVE`.
3. Validate issue/expiry/revocation chronology and `revocation_max_age_seconds` freshness.
4. Require exact authority-file digest and exact run/scope/baseline plus the relevant task/phase/release candidate digest; material change invalidates approval.
5. Validate with `tools/validate_runtime.py approval`; a `REJECT`, stale/revoked record, wrong subject digest, wrong authority bytes, or mismatched scope fails closed.

## 6. Drift and invalidation
Material change to target/source input, task file, requirement/acceptance hash, authority bytes/scope, schema, policy, model/tool version, prerequisite evidence, ledger binding, or approval invalidates affected green evidence. Preserve history, issue a new attempt, and rerun from the earliest affected prerequisite.

## 7. Failure and rollback
Rollback is task-local. Never discard pre-existing unrelated work. If isolation cannot be proven, stop for human intervention. Preserve failed attempts and before/after fingerprints.

## 8. Release semantics
Phase 12 is a fail-closed release-eligibility gate. Even a cryptographically approved Phase 12 `PASS` does not itself grant deploy/release/push/publication/communication authority.

## 9. Final output
Produce a release-candidate evidence bundle containing package/sidecar verification, exact authority/approval records and hashes, RTM, monotonic run-ledger chain, event log, immutable task attempts, phase evidence, exact hashes, benchmark/regression/security evidence, environment/docs, drift history, known limitations, and rollback procedure.
