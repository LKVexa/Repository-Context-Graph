# v1.3.0 Hardening Regression Matrix

This matrix records adversarial states reproduced against v1.2.0 and the v1.3.0 control that must reject them. It supplements, rather than replaces, the immutable audited requirements baseline.

| ID | Reproduced v1.2.0 condition | v1.3.0 invariant | Regression coverage |
|---|---|---|---|
| RT-01 | `ACTIVE` approval with `decision=REJECT` accepted | Usable approval requires `ACTIVE` **and** `APPROVE` | `tools/self_test_runtime.py` — REJECT approval must fail |
| RT-02 | Revocation check predating issuance/stale by years accepted | `issued_at <= revocation_checked_at <= now < expires_at` and freshness <= `revocation_max_age_seconds` | runtime self-test — stale/pre-issuance authority must fail |
| RT-03 | `COMPLETE` task with fabricated authority digest accepted | Green task opens exact authority file and digest must equal its exact bytes; run/task/phase/baseline bindings must match | runtime self-test — missing authority file/fake digest must fail |
| RT-04 | Phase `PASS` with invented attempt/evidence digests accepted | Phase binds actual ledger hash/revision and opens/hash-validates current task evidence | runtime self-test — fabricated phase PASS over non-green ledger must fail |
| RT-05 | 217-task all-green ledger with nonexistent current attempts accepted | Every terminal current pointer must exist, be latest, and match attempt evidence digest | runtime self-test — fabricated all-green ledger must fail |
| PKG-01 | Immutable source text changed + manifest recomputed still passed | Verifier pins immutable source SHA-256 and reconstructs/cross-checks all 217 records | `tools/self_test_verifier.py` — source semantic mutation must fail |
| PKG-02 | Schema-invalid shipped example + manifest recomputed still passed | Verifier validates schemas and shipped examples | verifier self-test — invalid authority example must fail |
| PKG-03 | Manifest task count/control metadata falsified | Verifier requires exact manifest control metadata and cross-checks inventory | verifier self-test — `task_count` tamper must fail |
| PKG-04 | Case-colliding/archive special-member/duplicate-record attacks | Unsafe/special ZIP members, path collisions, duplicate manifest records/JSON keys fail closed | verifier self-tests — case collision, symlink, duplicate record |
| EVT-01 | Mandatory vs optional checks ambiguous | Every check has `required`; required checks must PASS for green, optional SKIPPED requires reason | schema + runtime validation |
| REL-01 | Phase 12 PASS lacked exact release-candidate approval | Phase 12 PASS requires external `RELEASE` approval bound to deterministic candidate and exact authority | phase schema + runtime validator |

## Positive-path controls
- Baseline package verification must pass before mutations are tested.
- A valid, current, scope-matching authority example must pass.
- A valid `APPROVE` approval bound to its candidate digest must pass.
- A valid blocked task example must pass structural/semantic validation without being promoted green.
- A structurally and semantically valid revision-0 run ledger bound to real package/scheduler/authority/event-log digests must pass.

## Acceptance
Release v1.3.0 is acceptable only when the package verifier, verifier adversarial suite, and runtime adversarial suite all pass against the final manifest/package bytes, and a 217-record source/scheduler/RTM/task preservation check reports zero drift.
