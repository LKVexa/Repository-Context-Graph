# Repository Context Graph for Cross-File Changes — Master Prompt/Workflow Index

**Version:** 1.3.0  
**Source requirements baseline:** 1.0.0  
**Task count:** 217  
**Phases:** 13 (0–12)

## How to use
1. Verify the detached archive checksum when supplied, then run `python tools/verify_package.py <package-dir-or-zip>`.
2. Read Master Prompt, Execution Policy, Master Workflow, Status Model, and Evidence Integrity spec.
3. Validate current authority and initialize run ledger/event log.
4. Use `APPLICATION_ORDER_v1.3.0.csv`; task, requirement, and acceptance SHA-256 columns are binding.
5. Allocate a fresh immutable `ATTEMPT_ID` for each task execution/retry.
6. Validate task/phase/approval evidence structurally and semantically with `tools/validate_runtime.py`.
7. Treat phase files as derived convenience views and the audited source as immutable provenance.

## Hardening controls added in v1.3.0
- Exact-byte authority binding for green task evidence; claimed authority digests are not trusted without the referenced authority file.
- Enforced authority/approval issuance, expiry, revocation chronology, and maximum freshness at time of use.
- Usable approvals require `ACTIVE + APPROVE`; candidate digest and authority-file bindings are revalidated.
- Explicit required/optional check semantics; required checks cannot be skipped for green promotion.
- Green changed-artifact claims are canonical-path authorized and after-state hashes are checked against actual target bytes.
- Run ledgers bind manifest/scheduler/authority/event-log/run/target/baseline plus immutable attempt history and a previous-ledger digest chain.
- Phase `PASS` binds the actual run-ledger bytes/revision and actual current task-evidence bytes, not merely a declared task-ID map.
- Phase 12 `PASS` additionally requires a cryptographically bound external `RELEASE` approval.
- Package verification pins the immutable source baseline and reconstructs/cross-checks all 217 source/task/scheduler/RTM records.
- Package verification validates shipped JSON Schemas and their examples and enforces exact manifest control metadata.
- Adversarial runtime tests cover REJECT approval, stale/pre-issuance revocation, fake authority digest, nonexistent ledger attempts, and fabricated phase PASS.
- Adversarial package tests cover source mutation, invalid examples, manifest metadata tamper, path collisions, duplicate records, and ZIP special members.
- Integrity-vs-authenticity boundary remains explicit; target content remains untrusted.

### Phase 0 — Audit Hardening and Requirements Control
- Prerequisite: None
- Tasks: 18
- Consolidated series: `phases/PHASE_00_Prompt_Workflow_Series_v1.3.0.md`

- `AUD-001` — Assign stable IDs to every currently anonymous checklist requirement. → `items/PHASE_00/AUD-001_Prompt_Workflow_v1.3.0.md`
- `AUD-002` — Create a bidirectional requirements traceability matrix from source requirement → implementation artifact → test/evidence → release gate. → `items/PHASE_00/AUD-002_Prompt_Workflow_v1.3.0.md`
- `AUD-003` — Define owners and accountable reviewers for every requirement and phase. → `items/PHASE_00/AUD-003_Prompt_Workflow_v1.3.0.md`
- `AUD-004` — Formalize the repository graph ontology, including node/edge types, stable identity, rename/move/delete semantics, external artifacts, and confidence/provenance fields. → `items/PHASE_00/AUD-004_Prompt_Workflow_v1.3.0.md`
- `AUD-005` — Define language/build-system support tiers and parser fallback behavior. → `items/PHASE_00/AUD-005_Prompt_Workflow_v1.3.0.md`
- `AUD-006` — Define performance, scale, freshness, and availability objectives for graph build, incremental update, query, and impact analysis. → `items/PHASE_00/AUD-006_Prompt_Workflow_v1.3.0.md`
- `AUD-007` — Define consistency, concurrency, event-ordering, and recovery semantics for incremental graph updates. → `items/PHASE_00/AUD-007_Prompt_Workflow_v1.3.0.md`
- `AUD-008` — Add backup, restore, disaster-recovery, and corruption-recovery requirements for persistent graph/run/audit data. → `items/PHASE_00/AUD-008_Prompt_Workflow_v1.3.0.md`
- `AUD-009` — Define schema/data migrations for graph, provenance, workflow state, and storage—not only API contracts. → `items/PHASE_00/AUD-009_Prompt_Workflow_v1.3.0.md`
- `AUD-010` — Define connector resilience rules: pagination, rate limits, retries, backoff, partial failures, freshness, tombstones, and credential expiry. → `items/PHASE_00/AUD-010_Prompt_Workflow_v1.3.0.md`
- `AUD-011` — Add graph lifecycle and garbage-collection rules for deleted branches, removed files, closed PRs, superseded ADRs, and retention expiry. → `items/PHASE_00/AUD-011_Prompt_Workflow_v1.3.0.md`
- `AUD-012` — Define quantitative acceptance thresholds for grounding, false positives/negatives, abstention, review burden, and bypass resistance. → `items/PHASE_00/AUD-012_Prompt_Workflow_v1.3.0.md`
- `AUD-013` — Add software-supply-chain controls for dependencies, parser/tool binaries, containers, and build artifacts. → `items/PHASE_00/AUD-013_Prompt_Workflow_v1.3.0.md`
- `AUD-014` — Define cost/resource budgets for indexing, storage, retrieval, model calls, and impact analysis. → `items/PHASE_00/AUD-014_Prompt_Workflow_v1.3.0.md`
- `AUD-015` — Define rollout controls for feature flags, staged enablement, read-only/draft-only modes, canary cohorts, and emergency disable. → `items/PHASE_00/AUD-015_Prompt_Workflow_v1.3.0.md`
- `AUD-016` — Create representative golden repositories and synthetic fixtures covering mono-repos, polyglot repos, generated code, dependency cycles, renames, large histories, and partial metadata. → `items/PHASE_00/AUD-016_Prompt_Workflow_v1.3.0.md`
- `AUD-017` — Define review-UI usability/accessibility criteria for evidence inspection, scope narrowing, uncertainty, and approval controls. → `items/PHASE_00/AUD-017_Prompt_Workflow_v1.3.0.md`
- `AUD-018` — Define release/versioning/changelog policy for graph schema, APIs, prompts, policies, connectors, models, and benchmark baselines. → `items/PHASE_00/AUD-018_Prompt_Workflow_v1.3.0.md`

### Phase 1 — Authority, scope, identity & workflow state
- Prerequisite: Phase 0
- Tasks: 15
- Consolidated series: `phases/PHASE_01_Prompt_Workflow_Series_v1.3.0.md`

- `IMPL-01` — Define a machine-readable scope contract for the Repository Context Graph for Cross-File Changes workflow → `items/PHASE_01/IMPL-01_Prompt_Workflow_v1.3.0.md`
- `IMPL-02` — Define canonical input/output schemas and validate all connector/tool payloads → `items/PHASE_01/IMPL-02_Prompt_Workflow_v1.3.0.md`
- `IMPL-03` — Create a versioned workflow state machine with explicit start, analysis, review, approval, and terminal states → `items/PHASE_01/IMPL-03_Prompt_Workflow_v1.3.0.md`
- `FLOW-01` — Authenticate and establish authority → `items/PHASE_01/FLOW-01_Prompt_Workflow_v1.3.0.md`
- `FLOW-02` — Pin the target artifacts and revisions → `items/PHASE_01/FLOW-02_Prompt_Workflow_v1.3.0.md`
- `API-01` — Versioned API contracts for all inbound and outbound integrations → `items/PHASE_01/API-01_Prompt_Workflow_v1.3.0.md`
- `API-02` — Explicit schema for scope/authority → `items/PHASE_01/API-02_Prompt_Workflow_v1.3.0.md`
- `API-05` — Explicit schema for human review decision and approver identity → `items/PHASE_01/API-05_Prompt_Workflow_v1.3.0.md`
- `XAUTH-01` — Authenticate human users and service identities → `items/PHASE_01/XAUTH-01_Prompt_Workflow_v1.3.0.md`
- `XAUTH-02` — Authorize every data source and action independently → `items/PHASE_01/XAUTH-02_Prompt_Workflow_v1.3.0.md`
- `XAUTH-03` — Separate read, analyze, draft, modify, commit, approve, deploy, and communicate permissions → `items/PHASE_01/XAUTH-03_Prompt_Workflow_v1.3.0.md`
- `XAUTH-04` — Default to read-only access where the paper requires it → `items/PHASE_01/XAUTH-04_Prompt_Workflow_v1.3.0.md`
- `XAUTH-05` — Use narrowly scoped, short-lived credentials where execution is unavoidable → `items/PHASE_01/XAUTH-05_Prompt_Workflow_v1.3.0.md`
- `XAUTH-06` — Enforce repository/service/data boundaries in infrastructure, not only in model prompts → `items/PHASE_01/XAUTH-06_Prompt_Workflow_v1.3.0.md`
- `XAUTH-07` — Record the human authority under which every privileged action occurs → `items/PHASE_01/XAUTH-07_Prompt_Workflow_v1.3.0.md`

### Phase 2 — Connectors, artifact identity & provenance
- Prerequisite: Phase 1
- Tasks: 25
- Consolidated series: `phases/PHASE_02_Prompt_Workflow_Series_v1.3.0.md`

- `DATA-01` — Source code and symbols → `items/PHASE_02/DATA-01_Prompt_Workflow_v1.3.0.md`
- `DATA-02` — Build/dependency metadata → `items/PHASE_02/DATA-02_Prompt_Workflow_v1.3.0.md`
- `DATA-03` — Tests → `items/PHASE_02/DATA-03_Prompt_Workflow_v1.3.0.md`
- `DATA-04` — Git history → `items/PHASE_02/DATA-04_Prompt_Workflow_v1.3.0.md`
- `DATA-05` — PRs and review comments → `items/PHASE_02/DATA-05_Prompt_Workflow_v1.3.0.md`
- `DATA-06` — ADRs → `items/PHASE_02/DATA-06_Prompt_Workflow_v1.3.0.md`
- `DATA-07` — Bug/issue tracker → `items/PHASE_02/DATA-07_Prompt_Workflow_v1.3.0.md`
- `DATA-08` — Code owners → `items/PHASE_02/DATA-08_Prompt_Workflow_v1.3.0.md`
- `DATA-09` — Optional approved design discussions → `items/PHASE_02/DATA-09_Prompt_Workflow_v1.3.0.md`
- `COMP-04` — Artifact linker/entity resolver → `items/PHASE_02/COMP-04_Prompt_Workflow_v1.3.0.md`
- `COMP-10` — Provenance service → `items/PHASE_02/COMP-10_Prompt_Workflow_v1.3.0.md`
- `ARCH-01` — Connector/adaptor layer for authorized source systems → `items/PHASE_02/ARCH-01_Prompt_Workflow_v1.3.0.md`
- `ARCH-02` — Canonical artifact and identity layer → `items/PHASE_02/ARCH-02_Prompt_Workflow_v1.3.0.md`
- `IMPL-04` — Create a provenance model linking generated outputs to source artifacts, analyzer results, and human approvals → `items/PHASE_02/IMPL-04_Prompt_Workflow_v1.3.0.md`
- `FLOW-03` — Collect only authorized evidence → `items/PHASE_02/FLOW-03_Prompt_Workflow_v1.3.0.md`
- `FLOW-04` — Normalize and index the evidence → `items/PHASE_02/FLOW-04_Prompt_Workflow_v1.3.0.md`
- `API-03` — Explicit schema for evidence/provenance references → `items/PHASE_02/API-03_Prompt_Workflow_v1.3.0.md`
- `STORE-03` — Evidence/provenance records → `items/PHASE_02/STORE-03_Prompt_Workflow_v1.3.0.md`
- `XPROV-01` — Assign stable identity/version metadata to every source artifact → `items/PHASE_02/XPROV-01_Prompt_Workflow_v1.3.0.md`
- `XPROV-02` — Preserve source revision, timestamp, and freshness metadata → `items/PHASE_02/XPROV-02_Prompt_Workflow_v1.3.0.md`
- `XPROV-03` — Link every material AI finding to supporting evidence → `items/PHASE_02/XPROV-03_Prompt_Workflow_v1.3.0.md`
- `XPROV-04` — Distinguish source-derived facts from model inference → `items/PHASE_02/XPROV-04_Prompt_Workflow_v1.3.0.md`
- `XPROV-05` — Preserve deterministic analyzer output separately from model synthesis → `items/PHASE_02/XPROV-05_Prompt_Workflow_v1.3.0.md`
- `XPROV-06` — Maintain an immutable or append-only activity/evidence log → `items/PHASE_02/XPROV-06_Prompt_Workflow_v1.3.0.md`
- `XPROV-07` — Support export of an auditable case file for human review → `items/PHASE_02/XPROV-07_Prompt_Workflow_v1.3.0.md`

### Phase 3 — Graph ingestion & persistent state
- Prerequisite: Phases 1–2
- Tasks: 7
- Consolidated series: `phases/PHASE_03_Prompt_Workflow_Series_v1.3.0.md`

- `PAPER-CAP-01` — Parse source and build metadata into a persistent code graph → `items/PHASE_03/PAPER-CAP-01_Prompt_Workflow_v1.3.0.md`
- `COMP-01` — Language parsers and symbol extractors → `items/PHASE_03/COMP-01_Prompt_Workflow_v1.3.0.md`
- `COMP-02` — AST/symbol/dependency graph builder → `items/PHASE_03/COMP-02_Prompt_Workflow_v1.3.0.md`
- `COMP-03` — Temporal graph/version store → `items/PHASE_03/COMP-03_Prompt_Workflow_v1.3.0.md`
- `ARCH-03` — Persistent state/context store → `items/PHASE_03/ARCH-03_Prompt_Workflow_v1.3.0.md`
- `STORE-01` — Persistent workflow/run state → `items/PHASE_03/STORE-01_Prompt_Workflow_v1.3.0.md`
- `STORE-02` — Versioned artifact metadata and source pointers → `items/PHASE_03/STORE-02_Prompt_Workflow_v1.3.0.md`

### Phase 4 — Historical context, retrieval & query
- Prerequisite: Phases 2–3
- Tasks: 5
- Consolidated series: `phases/PHASE_04_Prompt_Workflow_Series_v1.3.0.md`

- `PAPER-CAP-03` — Attach rationale from PR discussions, ADRs, and linked bugs → `items/PHASE_04/PAPER-CAP-03_Prompt_Workflow_v1.3.0.md`
- `COMP-05` — Semantic retrieval index → `items/PHASE_04/COMP-05_Prompt_Workflow_v1.3.0.md`
- `COMP-06` — Historical-rationale extractor → `items/PHASE_04/COMP-06_Prompt_Workflow_v1.3.0.md`
- `COMP-07` — Graph query layer → `items/PHASE_04/COMP-07_Prompt_Workflow_v1.3.0.md`
- `ARCH-04` — Retrieval/graph/query layer as appropriate → `items/PHASE_04/ARCH-04_Prompt_Workflow_v1.3.0.md`

### Phase 5 — Incremental updates & impact analysis
- Prerequisite: Phases 3–4
- Tasks: 4
- Consolidated series: `phases/PHASE_05_Prompt_Workflow_Series_v1.3.0.md`

- `PAPER-CAP-02` — Update the graph as code changes → `items/PHASE_05/PAPER-CAP-02_Prompt_Workflow_v1.3.0.md`
- `PAPER-CAP-04` — Compute an impact report before drafting a patch → `items/PHASE_05/PAPER-CAP-04_Prompt_Workflow_v1.3.0.md`
- `COMP-08` — Incremental graph updater → `items/PHASE_05/COMP-08_Prompt_Workflow_v1.3.0.md`
- `COMP-09` — Impact analysis engine → `items/PHASE_05/COMP-09_Prompt_Workflow_v1.3.0.md`

### Phase 6 — Deterministic analysis, model reasoning & uncertainty
- Prerequisite: Phases 1–5
- Tasks: 25
- Consolidated series: `phases/PHASE_06_Prompt_Workflow_Series_v1.3.0.md`

- `PAPER-CAP-05` — Flag missing context rather than guessing → `items/PHASE_06/PAPER-CAP-05_Prompt_Workflow_v1.3.0.md`
- `ARCH-05` — Deterministic analysis/tool layer → `items/PHASE_06/ARCH-05_Prompt_Workflow_v1.3.0.md`
- `ARCH-06` — Model reasoning/orchestration layer → `items/PHASE_06/ARCH-06_Prompt_Workflow_v1.3.0.md`
- `IMPL-07` — Implement an uncertainty/abstention mechanism for insufficient evidence and out-of-scope requests → `items/PHASE_06/IMPL-07_Prompt_Workflow_v1.3.0.md`
- `FLOW-05` — Run deterministic analysis first where applicable → `items/PHASE_06/FLOW-05_Prompt_Workflow_v1.3.0.md`
- `FLOW-06` — Run model reasoning only over authorized, provenance-bearing context → `items/PHASE_06/FLOW-06_Prompt_Workflow_v1.3.0.md`
- `FLOW-07` — Generate a bounded draft/recommendation/artifact → `items/PHASE_06/FLOW-07_Prompt_Workflow_v1.3.0.md`
- `API-04` — Explicit schema for uncertainty/confidence and abstention reason → `items/PHASE_06/API-04_Prompt_Workflow_v1.3.0.md`
- `MODEL-01` — Model choice is version-pinned and recorded per run → `items/PHASE_06/MODEL-01_Prompt_Workflow_v1.3.0.md`
- `MODEL-02` — System prompts encode scope, evidence, uncertainty, and abstention rules → `items/PHASE_06/MODEL-02_Prompt_Workflow_v1.3.0.md`
- `MODEL-03` — Retrieval context is source-labeled → `items/PHASE_06/MODEL-03_Prompt_Workflow_v1.3.0.md`
- `MODEL-04` — Structured outputs are schema-validated → `items/PHASE_06/MODEL-04_Prompt_Workflow_v1.3.0.md`
- `MODEL-05` — High-impact conclusions require supporting evidence references → `items/PHASE_06/MODEL-05_Prompt_Workflow_v1.3.0.md`
- `MODEL-06` — Model cannot directly grant itself additional permissions → `items/PHASE_06/MODEL-06_Prompt_Workflow_v1.3.0.md`
- `MODEL-07` — Evaluation includes hallucination, overreach, and stale-context cases → `items/PHASE_06/MODEL-07_Prompt_Workflow_v1.3.0.md`
- `XUNC-01` — Represent known, supported, inferred, uncertain, stale, missing, and out-of-scope states → `items/PHASE_06/XUNC-01_Prompt_Workflow_v1.3.0.md`
- `XUNC-02` — Calibrate confidence against validation data where quantitative scores are shown → `items/PHASE_06/XUNC-02_Prompt_Workflow_v1.3.0.md`
- `XUNC-03` — Surface missing context instead of filling gaps silently → `items/PHASE_06/XUNC-03_Prompt_Workflow_v1.3.0.md`
- `XUNC-04` — Define stop/abstain thresholds → `items/PHASE_06/XUNC-04_Prompt_Workflow_v1.3.0.md`
- `XUNC-05` — Route high-impact or ambiguous cases to human review → `items/PHASE_06/XUNC-05_Prompt_Workflow_v1.3.0.md`
- `XUNC-06` — Never present unsupported assumptions as facts → `items/PHASE_06/XUNC-06_Prompt_Workflow_v1.3.0.md`
- `XTOOL-01` — Use deterministic analyzers before probabilistic reasoning where applicable → `items/PHASE_06/XTOOL-01_Prompt_Workflow_v1.3.0.md`
- `XTOOL-05` — Implement retrieval/source ranking and stale-source detection → `items/PHASE_06/XTOOL-05_Prompt_Workflow_v1.3.0.md`
- `XTOOL-06` — Track model/tool versions for every run → `items/PHASE_06/XTOOL-06_Prompt_Workflow_v1.3.0.md`
- `XTOOL-07` — Provide fallback behavior when a model or connector fails → `items/PHASE_06/XTOOL-07_Prompt_Workflow_v1.3.0.md`

### Phase 7 — Human review, policy & approval control
- Prerequisite: Phases 1–6
- Tasks: 22
- Consolidated series: `phases/PHASE_07_Prompt_Workflow_Series_v1.3.0.md`

- `PAPER-GRD-01` — No modifications outside the approved task → `items/PHASE_07/PAPER-GRD-01_Prompt_Workflow_v1.3.0.md`
- `PAPER-GRD-02` — No substantial structural change without interactive scoping → `items/PHASE_07/PAPER-GRD-02_Prompt_Workflow_v1.3.0.md`
- `PAPER-GRD-03` — Do not introduce design decisions that diverge from established conventions without approval → `items/PHASE_07/PAPER-GRD-03_Prompt_Workflow_v1.3.0.md`
- `PAPER-GRD-04` — All diffs remain human-reviewable → `items/PHASE_07/PAPER-GRD-04_Prompt_Workflow_v1.3.0.md`
- `ARCH-07` — Policy/authority enforcement layer → `items/PHASE_07/ARCH-07_Prompt_Workflow_v1.3.0.md`
- `ARCH-09` — Human review and approval interface → `items/PHASE_07/ARCH-09_Prompt_Workflow_v1.3.0.md`
- `IMPL-06` — Create a policy layer that converts paper guardrails into enforceable permissions and stop conditions → `items/PHASE_07/IMPL-06_Prompt_Workflow_v1.3.0.md`
- `IMPL-08` — Provide a human review surface that exposes evidence, rationale, changed artifacts, uncertainty, and approval controls → `items/PHASE_07/IMPL-08_Prompt_Workflow_v1.3.0.md`
- `FLOW-09` — Expose evidence, uncertainty, scope, and verification results to the human reviewer → `items/PHASE_07/FLOW-09_Prompt_Workflow_v1.3.0.md`
- `FLOW-10` — Require the paper-specified human decision/approval before any subsequent state change → `items/PHASE_07/FLOW-10_Prompt_Workflow_v1.3.0.md`
- `HUMAN-01` — Reviewer can inspect original evidence → `items/PHASE_07/HUMAN-01_Prompt_Workflow_v1.3.0.md`
- `HUMAN-02` — Reviewer can see exactly what the system did and did not analyze → `items/PHASE_07/HUMAN-02_Prompt_Workflow_v1.3.0.md`
- `HUMAN-03` — Reviewer can narrow scope and rerun → `items/PHASE_07/HUMAN-03_Prompt_Workflow_v1.3.0.md`
- `HUMAN-04` — Reviewer can reject without side effects → `items/PHASE_07/HUMAN-04_Prompt_Workflow_v1.3.0.md`
- `HUMAN-05` — Reviewer can require additional evidence → `items/PHASE_07/HUMAN-05_Prompt_Workflow_v1.3.0.md`
- `HUMAN-06` — Approval identity, timestamp, and approved scope are recorded → `items/PHASE_07/HUMAN-06_Prompt_Workflow_v1.3.0.md`
- `HUMAN-07` — Final accountability is never represented as belonging to the AI → `items/PHASE_07/HUMAN-07_Prompt_Workflow_v1.3.0.md`
- `XHITL-01` — Provide preview before state-changing actions → `items/PHASE_07/XHITL-01_Prompt_Workflow_v1.3.0.md`
- `XHITL-02` — Require explicit approval at the paper-specified human gates → `items/PHASE_07/XHITL-02_Prompt_Workflow_v1.3.0.md`
- `XHITL-03` — Support approve, reject, edit, narrow scope, and request-more-evidence operations → `items/PHASE_07/XHITL-03_Prompt_Workflow_v1.3.0.md`
- `XHITL-04` — Keep final accountability visible in the UI and audit record → `items/PHASE_07/XHITL-04_Prompt_Workflow_v1.3.0.md`
- `XHITL-05` — Prevent the AI from approving or attesting to its own work where prohibited → `items/PHASE_07/XHITL-05_Prompt_Workflow_v1.3.0.md`

### Phase 8 — Security, privacy & sandboxing
- Prerequisite: Phases 1–7; security remains continuous
- Tasks: 19
- Consolidated series: `phases/PHASE_08_Prompt_Workflow_Series_v1.3.0.md`

- `STORE-06` — Retention, deletion, and privacy controls → `items/PHASE_08/STORE-06_Prompt_Workflow_v1.3.0.md`
- `SEC-01` — Prompt injection from repository/docs/tickets/logs is treated as untrusted input → `items/PHASE_08/SEC-01_Prompt_Workflow_v1.3.0.md`
- `SEC-02` — Tool-call argument validation blocks command/path/scope injection → `items/PHASE_08/SEC-02_Prompt_Workflow_v1.3.0.md`
- `SEC-03` — Secrets are never copied into model context unless explicitly required and protected → `items/PHASE_08/SEC-03_Prompt_Workflow_v1.3.0.md`
- `SEC-04` — Cross-project/tenant data leakage tests exist → `items/PHASE_08/SEC-04_Prompt_Workflow_v1.3.0.md`
- `SEC-05` — Unauthorized write attempts fail closed → `items/PHASE_08/SEC-05_Prompt_Workflow_v1.3.0.md`
- `SEC-06` — Sensitive generated output is classified before display/export → `items/PHASE_08/SEC-06_Prompt_Workflow_v1.3.0.md`
- `SEC-07` — Human approval tokens cannot be fabricated by model output → `items/PHASE_08/SEC-07_Prompt_Workflow_v1.3.0.md`
- `SEC-08` — Audit records cannot be modified by the model → `items/PHASE_08/SEC-08_Prompt_Workflow_v1.3.0.md`
- `XSEC-01` — Classify data before model/tool access → `items/PHASE_08/XSEC-01_Prompt_Workflow_v1.3.0.md`
- `XSEC-02` — Redact or exclude sensitive data where not required → `items/PHASE_08/XSEC-02_Prompt_Workflow_v1.3.0.md`
- `XSEC-03` — Prevent cross-tenant/project leakage → `items/PHASE_08/XSEC-03_Prompt_Workflow_v1.3.0.md`
- `XSEC-04` — Encrypt data in transit and at rest → `items/PHASE_08/XSEC-04_Prompt_Workflow_v1.3.0.md`
- `XSEC-05` — Keep secrets out of prompts, logs, generated artifacts, and model context → `items/PHASE_08/XSEC-05_Prompt_Workflow_v1.3.0.md`
- `XSEC-06` — Maintain configurable retention and deletion policies → `items/PHASE_08/XSEC-06_Prompt_Workflow_v1.3.0.md`
- `XSEC-07` — Threat-model prompt injection and malicious repository/artifact content → `items/PHASE_08/XSEC-07_Prompt_Workflow_v1.3.0.md`
- `XTOOL-02` — Validate tool inputs and outputs against schemas → `items/PHASE_08/XTOOL-02_Prompt_Workflow_v1.3.0.md`
- `XTOOL-03` — Sandbox code execution and untrusted artifact processing → `items/PHASE_08/XTOOL-03_Prompt_Workflow_v1.3.0.md`
- `XTOOL-04` — Bound token/context retrieval to authorized material → `items/PHASE_08/XTOOL-04_Prompt_Workflow_v1.3.0.md`

### Phase 9 — Observability, audit & reproducibility
- Prerequisite: Phases 1–8
- Tasks: 21
- Consolidated series: `phases/PHASE_09_Prompt_Workflow_Series_v1.3.0.md`

- `ARCH-08` — Provenance/evidence ledger → `items/PHASE_09/ARCH-08_Prompt_Workflow_v1.3.0.md`
- `ARCH-10` — Observability/evaluation subsystem → `items/PHASE_09/ARCH-10_Prompt_Workflow_v1.3.0.md`
- `IMPL-05` — Implement source freshness and revision pinning so analyses can be reproduced → `items/PHASE_09/IMPL-05_Prompt_Workflow_v1.3.0.md`
- `IMPL-09` — Implement audit logging for retrievals, model/tool calls, generated artifacts, approvals, overrides, and denied actions → `items/PHASE_09/IMPL-09_Prompt_Workflow_v1.3.0.md`
- `FLOW-11` — Record the full evidence and decision trail → `items/PHASE_09/FLOW-11_Prompt_Workflow_v1.3.0.md`
- `API-06` — Idempotency support for retried workflow steps → `items/PHASE_09/API-06_Prompt_Workflow_v1.3.0.md`
- `API-07` — Immutable run ID and artifact IDs → `items/PHASE_09/API-07_Prompt_Workflow_v1.3.0.md`
- `API-08` — Backward-compatible versioning or migration plan → `items/PHASE_09/API-08_Prompt_Workflow_v1.3.0.md`
- `STORE-04` — Human approval/rejection history → `items/PHASE_09/STORE-04_Prompt_Workflow_v1.3.0.md`
- `STORE-05` — Model/tool version metadata → `items/PHASE_09/STORE-05_Prompt_Workflow_v1.3.0.md`
- `STORE-07` — Append-only audit trail for privileged actions → `items/PHASE_09/STORE-07_Prompt_Workflow_v1.3.0.md`
- `XSTATE-01` — Pin repository/data revisions used for analysis → `items/PHASE_09/XSTATE-01_Prompt_Workflow_v1.3.0.md`
- `XSTATE-02` — Version prompts, models, tools, policies, and schemas → `items/PHASE_09/XSTATE-02_Prompt_Workflow_v1.3.0.md`
- `XSTATE-03` — Store workflow state so an interrupted run can be reconstructed → `items/PHASE_09/XSTATE-03_Prompt_Workflow_v1.3.0.md`
- `XSTATE-04` — Make generated artifacts reproducible from recorded inputs where feasible → `items/PHASE_09/XSTATE-04_Prompt_Workflow_v1.3.0.md`
- `XSTATE-05` — Use deterministic IDs for runs, artifacts, findings, and approvals → `items/PHASE_09/XSTATE-05_Prompt_Workflow_v1.3.0.md`
- `XOBS-01` — Emit structured logs for workflow state transitions → `items/PHASE_09/XOBS-01_Prompt_Workflow_v1.3.0.md`
- `XOBS-02` — Measure latency, cost, tool failures, abstention, approval, and override rates → `items/PHASE_09/XOBS-02_Prompt_Workflow_v1.3.0.md`
- `XOBS-03` — Track false-positive/false-negative rates where ground truth exists → `items/PHASE_09/XOBS-03_Prompt_Workflow_v1.3.0.md`
- `XOBS-04` — Alert on abnormal permission use or unexpected write attempts → `items/PHASE_09/XOBS-04_Prompt_Workflow_v1.3.0.md`
- `XOBS-05` — Provide run-level tracing across retrieval, tools, model calls, and approvals → `items/PHASE_09/XOBS-05_Prompt_Workflow_v1.3.0.md`

### Phase 10 — Verification, testing & evaluation
- Prerequisite: Phases 1–9
- Tasks: 29
- Consolidated series: `phases/PHASE_10_Prompt_Workflow_Series_v1.3.0.md`

- `IMPL-10` — Define an offline benchmark and regression suite before enabling production use → `items/PHASE_10/IMPL-10_Prompt_Workflow_v1.3.0.md`
- `FLOW-08` — Verify the output using independent tools or checks → `items/PHASE_10/FLOW-08_Prompt_Workflow_v1.3.0.md`
- `VERIFY-01` — Graph edges are traceable to source artifacts → `items/PHASE_10/VERIFY-01_Prompt_Workflow_v1.3.0.md`
- `VERIFY-02` — Graph updates are incremental and revision-aware → `items/PHASE_10/VERIFY-02_Prompt_Workflow_v1.3.0.md`
- `VERIFY-03` — Impact reports identify direct and transitive dependents → `items/PHASE_10/VERIFY-03_Prompt_Workflow_v1.3.0.md`
- `VERIFY-04` — Stale/missing source context is marked → `items/PHASE_10/VERIFY-04_Prompt_Workflow_v1.3.0.md`
- `VERIFY-05` — Queries reproduce consistent results for a pinned repository revision → `items/PHASE_10/VERIFY-05_Prompt_Workflow_v1.3.0.md`
- `TEST-UNIT-01` — Parsers, schema validators, policy checks, scoring logic, provenance links, and state transitions → `items/PHASE_10/TEST-UNIT-01_Prompt_Workflow_v1.3.0.md`
- `TEST-INT-01` — Connectors, retrieval, deterministic analyzers, model orchestration, review UI, and audit storage → `items/PHASE_10/TEST-INT-01_Prompt_Workflow_v1.3.0.md`
- `TEST-ADV-01` — Malicious repository/document instructions → `items/PHASE_10/TEST-ADV-01_Prompt_Workflow_v1.3.0.md`
- `TEST-ADV-02` — Missing/stale/conflicting evidence → `items/PHASE_10/TEST-ADV-02_Prompt_Workflow_v1.3.0.md`
- `TEST-ADV-03` — Oversized scope requests → `items/PHASE_10/TEST-ADV-03_Prompt_Workflow_v1.3.0.md`
- `TEST-ADV-04` — Unauthorized write/tool calls → `items/PHASE_10/TEST-ADV-04_Prompt_Workflow_v1.3.0.md`
- `TEST-ADV-05` — Sensitive-data leakage → `items/PHASE_10/TEST-ADV-05_Prompt_Workflow_v1.3.0.md`
- `TEST-ADV-06` — Hallucinated provenance → `items/PHASE_10/TEST-ADV-06_Prompt_Workflow_v1.3.0.md`
- `TEST-ADV-07` — False human-approval claims → `items/PHASE_10/TEST-ADV-07_Prompt_Workflow_v1.3.0.md`
- `TEST-E2E-01` — Golden-path scenario → `items/PHASE_10/TEST-E2E-01_Prompt_Workflow_v1.3.0.md`
- `TEST-E2E-02` — Human rejection scenario → `items/PHASE_10/TEST-E2E-02_Prompt_Workflow_v1.3.0.md`
- `TEST-E2E-03` — Human scope-narrowing scenario → `items/PHASE_10/TEST-E2E-03_Prompt_Workflow_v1.3.0.md`
- `TEST-E2E-04` — Tool failure scenario → `items/PHASE_10/TEST-E2E-04_Prompt_Workflow_v1.3.0.md`
- `TEST-E2E-05` — Missing-context abstention scenario → `items/PHASE_10/TEST-E2E-05_Prompt_Workflow_v1.3.0.md`
- `TEST-E2E-06` — Rollback/abort scenario → `items/PHASE_10/TEST-E2E-06_Prompt_Workflow_v1.3.0.md`
- `XEVAL-01` — Build a representative offline evaluation corpus → `items/PHASE_10/XEVAL-01_Prompt_Workflow_v1.3.0.md`
- `XEVAL-02` — Include adversarial, ambiguous, stale, incomplete, and out-of-scope cases → `items/PHASE_10/XEVAL-02_Prompt_Workflow_v1.3.0.md`
- `XEVAL-03` — Measure grounding/provenance correctness → `items/PHASE_10/XEVAL-03_Prompt_Workflow_v1.3.0.md`
- `XEVAL-04` — Measure human review burden, not only task completion → `items/PHASE_10/XEVAL-04_Prompt_Workflow_v1.3.0.md`
- `XEVAL-05` — Validate that guardrails fail closed → `items/PHASE_10/XEVAL-05_Prompt_Workflow_v1.3.0.md`
- `XEVAL-06` — Run pilot deployment under read-only/draft-only permissions before broader rollout → `items/PHASE_10/XEVAL-06_Prompt_Workflow_v1.3.0.md`
- `XEVAL-07` — Require documented acceptance criteria and rollback procedure before production use → `items/PHASE_10/XEVAL-07_Prompt_Workflow_v1.3.0.md`

### Phase 11 — Deployment environments & documentation
- Prerequisite: Phases 1–10
- Tasks: 18
- Consolidated series: `phases/PHASE_11_Prompt_Workflow_Series_v1.3.0.md`

- `ENV-01` — Developer/local sandbox → `items/PHASE_11/ENV-01_Prompt_Workflow_v1.3.0.md`
- `ENV-02` — CI validation environment → `items/PHASE_11/ENV-02_Prompt_Workflow_v1.3.0.md`
- `ENV-03` — Staging/pre-production environment → `items/PHASE_11/ENV-03_Prompt_Workflow_v1.3.0.md`
- `ENV-04` — Production read-only integration where applicable → `items/PHASE_11/ENV-04_Prompt_Workflow_v1.3.0.md`
- `ENV-05` — Separate privileged execution path only where explicitly authorized → `items/PHASE_11/ENV-05_Prompt_Workflow_v1.3.0.md`
- `ENV-06` — Isolated test tenant/data set for privacy/security validation → `items/PHASE_11/ENV-06_Prompt_Workflow_v1.3.0.md`
- `DOC-01` — Architecture diagram → `items/PHASE_11/DOC-01_Prompt_Workflow_v1.3.0.md`
- `DOC-02` — Data-flow and trust-boundary diagram → `items/PHASE_11/DOC-02_Prompt_Workflow_v1.3.0.md`
- `DOC-03` — Source/connector inventory → `items/PHASE_11/DOC-03_Prompt_Workflow_v1.3.0.md`
- `DOC-04` — Permission matrix → `items/PHASE_11/DOC-04_Prompt_Workflow_v1.3.0.md`
- `DOC-05` — Threat model → `items/PHASE_11/DOC-05_Prompt_Workflow_v1.3.0.md`
- `DOC-06` — Model/tool inventory → `items/PHASE_11/DOC-06_Prompt_Workflow_v1.3.0.md`
- `DOC-07` — Provenance schema → `items/PHASE_11/DOC-07_Prompt_Workflow_v1.3.0.md`
- `DOC-08` — Run-state schema → `items/PHASE_11/DOC-08_Prompt_Workflow_v1.3.0.md`
- `DOC-09` — Human approval policy → `items/PHASE_11/DOC-09_Prompt_Workflow_v1.3.0.md`
- `DOC-10` — Evaluation plan and benchmark corpus description → `items/PHASE_11/DOC-10_Prompt_Workflow_v1.3.0.md`
- `DOC-11` — Incident/rollback runbook → `items/PHASE_11/DOC-11_Prompt_Workflow_v1.3.0.md`
- `DOC-12` — Known limitations and non-goals → `items/PHASE_11/DOC-12_Prompt_Workflow_v1.3.0.md`

### Phase 12 — Production readiness & release gate
- Prerequisite: All prior phases
- Tasks: 9
- Consolidated series: `phases/PHASE_12_Prompt_Workflow_Series_v1.3.0.md`

- `FLOW-12` — Rollback/abort cleanly if scope, evidence, authorization, or verification conditions fail → `items/PHASE_12/FLOW-12_Prompt_Workflow_v1.3.0.md`
- `PROD-01` — All paper-stated guardrails are implemented as enforceable controls → `items/PHASE_12/PROD-01_Prompt_Workflow_v1.3.0.md`
- `PROD-02` — Evaluation demonstrates acceptable grounding and false-positive behavior → `items/PHASE_12/PROD-02_Prompt_Workflow_v1.3.0.md`
- `PROD-03` — No hidden write authority exists outside approved workflows → `items/PHASE_12/PROD-03_Prompt_Workflow_v1.3.0.md`
- `PROD-04` — Every material output is traceable to evidence → `items/PHASE_12/PROD-04_Prompt_Workflow_v1.3.0.md`
- `PROD-05` — Human approval gates have been tested for bypass resistance → `items/PHASE_12/PROD-05_Prompt_Workflow_v1.3.0.md`
- `PROD-06` — Rollback and incident procedures are documented and exercised → `items/PHASE_12/PROD-06_Prompt_Workflow_v1.3.0.md`
- `PROD-07` — Security/privacy review is complete → `items/PHASE_12/PROD-07_Prompt_Workflow_v1.3.0.md`
- `PROD-08` — Known limitations and non-goals are published → `items/PHASE_12/PROD-08_Prompt_Workflow_v1.3.0.md`
