# Status Model v1.3.0

Runtime progression is `NOT_STARTED` → `READY` → `IN_PROGRESS` → a final/holding state. Same-task execution is single-writer under a task lock.

- `COMPLETE`: exact acceptance criterion is scheduler/source-bound and `PASS`; exact authority-file digest is current and `ACTIVE`; every required check passes; no check fails/blocks; changed-artifact after-state hashes validate; immutable evidence is structurally and semantically valid.
- `BLOCKED`: execution cannot proceed because a prerequisite, authority, scope, environment, evidence, approval, lock, or dependency is missing/unavailable; no acceptance failure is asserted.
- `FAILED`: execution occurred and implementation, verification, or acceptance failed.
- `INVALIDATED`: previously valid evidence/approval became stale because a bound input, revision, hash, scope, version, dependency, or authority state changed.
- `NOT_APPLICABLE`: only for explicitly conditional requirements with current authorized applicability evidence and matching verdict.

Every final ledger state points to a real latest immutable attempt whose status/evidence digest matches the task record. A new attempt may supersede an older failed/blocked/invalidated attempt but never erases it. Ledger revisions form a digest chain and prior attempt history is prefix-immutable. Manual status edits cannot create green state without matching evidence bytes.
