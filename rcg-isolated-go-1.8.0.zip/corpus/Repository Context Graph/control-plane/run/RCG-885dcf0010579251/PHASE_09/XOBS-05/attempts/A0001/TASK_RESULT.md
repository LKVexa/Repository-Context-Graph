# XOBS-05 — Task Result

- **Status:** `COMPLETE`
- **Phase:** 9  
- **Attempt:** `A0001`
- **Run:** `RCG-885dcf0010579251`
- **Elapsed:** 0.09 ms

## Acceptance criterion

> Operators can observe the condition per run/environment and a synthetic failure demonstrates the intended metric/alert/trace.

**Verdict:** `PASS`

## Checks

| id | kind | required | result | detail |
|---|---|---|---|---|
| `xobs-05-tests` | test | yes | **PASS** | test_e2e.TestInt01Integration: OK |
| `xobs-05-alerts` | operations | yes | **PASS** | synthetic failures fired ['ALERT-DENY-01', 'ALERT-PERM-01', 'ALERT-SELFAPP-01', 'ALERT-WRITE-01'] |

## Status reason

2 required check(s) passed: xobs-05-tests=test_e2e.TestInt01Integration: OK; xobs-05-alerts=synthetic failures fired ['ALERT-DENY-01', 'ALERT-PERM-01', 'ALERT-SELFAPP-01', 'ALERT-WRITE-01']

## Changed artifacts

_None recorded for this task._

## Rollback boundary

Only files under Repository Context Graph/ attributable to XOBS-05. The 66 specification suites are untouched.
