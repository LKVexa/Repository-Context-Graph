"""The check registry: what each of the 217 tasks must actually demonstrate.

Every entry is a *real* check. A check runs code, reads an artifact, or
executes a suite, and returns `PASS`, `FAIL` or `BLOCKED` with a concrete
detail string. Nothing here returns `PASS` because a task "looks done".

Three kinds of entry exist:

* **specific** -- a named function for a task whose acceptance needs its own
  demonstration (`AUD-001` counts stable ids; `VERIFY-05` compares two logical
  digests).
* **family** -- a default set derived from the task's family, so every task has
  at least one required check that exercises the module implementing it.
* **blocked** -- a declared, reasoned blocker for a task whose acceptance
  genuinely cannot be met in this environment. These are listed explicitly in
  :data:`BLOCKERS` with the reason that goes into `status_reason`, and they are
  the only way a task avoids having to pass real checks.
"""
from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

HERE = Path(__file__).resolve().parent
OVERLAY = HERE.parent
sys.path.insert(0, str(OVERLAY))
sys.path.insert(0, str(OVERLAY / "eval"))
sys.path.insert(0, str(OVERLAY / "tests"))

__all__ = ["CheckResult", "BLOCKERS", "blocked_reason_for", "checks_for",
           "run_suite_once", "SuiteCache"]


#: The evidence schema constrains `kind` to a fixed vocabulary. These are the
#: descriptive kinds this registry uses, mapped onto it; the descriptive kind
#: survives in the check id and the TASK_RESULT table.
_KIND_MAP = {
    "artifact": "other", "analysis": "other", "operations": "other",
    "test": "unit", "suite": "e2e", "policy": "contract", "storage": "integration",
    "contract": "contract", "integration": "integration", "security": "security",
    "coverage": "other", "gate": "other",
}


@dataclass
class CheckResult:
    check_id: str
    kind: str
    required: bool
    result: str                    # PASS | FAIL | BLOCKED | SKIPPED
    detail: str
    command: str = ""
    exit_code: int | None = None
    skip_reason: str | None = None
    evidence_ref: str = ""

    def as_document(self) -> dict[str, Any]:
        document = {
            "id": self.check_id, "kind": _KIND_MAP.get(self.kind, "other"),
            "required": self.required,
            "result": self.result, "command_or_check": self.command or self.check_id,
            "exit_code": self.exit_code,
            "evidence_ref": self.evidence_ref or self.check_id,
        }
        if self.skip_reason:
            document["skip_reason"] = self.skip_reason
        return document


# --------------------------------------------------------------------------- #
# Declared blockers -- the only route to BLOCKED that is not a failing check.   #
# --------------------------------------------------------------------------- #
BLOCKERS: dict[str, str] = {
    "ENV-03": ("No staging/pre-production host exists in this delivery. The profile is declared in "
               "environments/ENVIRONMENTS.json with its contract ceiling, but nothing has been "
               "provisioned, so its designated smoke/security/isolation checks cannot run."),
    "ENV-04": ("No production integration exists in this delivery. Read-only production access is "
               "declared and bounded but not provisioned, so no smoke check can be executed."),
    "ENV-05": ("The privileged execution path is declared and enforced by the contract ceiling, but "
               "it is not provisioned as a distinct host, so its isolation checks cannot run here."),
    "XSEC-04": ("Encryption in transit and at rest is not implemented. This package stores plaintext "
                "on the local filesystem and makes no network calls; the control is delegated to the "
                "host and is not satisfied by anything in this delivery. The data-flow half of the "
                "acceptance (prevent/redact before model access) IS implemented and tested, but the "
                "requirement itself is encryption, so this is reported BLOCKED rather than partially "
                "credited."),
    "XEVAL-06": ("No pilot deployment has been run. The read-only/draft-only rollout stages are "
                 "declared in registry/ROLLOUT.json and enforced by rcg.rollout, but stage 2 (canary) "
                 "has not been executed, so there is no pilot evidence to record."),
    "PROD-01": None, "PROD-02": None, "PROD-03": None, "PROD-04": None,
    "PROD-05": None, "PROD-06": None, "PROD-07": None, "PROD-08": None,
}
_PROD_REASON = (
    "Release-gate tasks require an external, human-signed RELEASE approval bound to the "
    "phase-gate candidate digest. No such approval was given for this run: the owner "
    "authorized implementation, not release. The gate is therefore BLOCKED, which is the "
    "gate working correctly, not a defect."
)
for _task, _reason in list(BLOCKERS.items()):
    if _reason is None:
        BLOCKERS[_task] = _PROD_REASON


# --------------------------------------------------------------------------- #
# GO-01-01: the entries above are now the registry of conditions, not the       #
# answer. Each dispatches to a validator of actual bound evidence.              #
# --------------------------------------------------------------------------- #
def blocked_reason_for(task_id: str, *, receipts=(), subject=None, trust_root=None,
                       exclusion=None) -> str | None:
    """Return the reason ``task_id`` is blocked, computed from evidence.

    Before v1.5.0 this was ``BLOCKERS.get(task_id)`` -- a stored string that let
    a task skip every check. The entries are deliberately kept (deleting them
    would turn thirteen honest blocks into thirteen silent passes) but each one
    now dispatches to :mod:`successor.evidence_validators`, which keeps
    returning BLOCKED until its proof exists and says *which* of the seven
    refusals applies.

    ``None`` means the condition is satisfied by current, subject-bound,
    attested evidence and the task's real checks should run.
    """
    if task_id not in BLOCKERS:
        return None
    import sys as _sys
    _here = str(Path(__file__).resolve().parent)
    if _here not in _sys.path:
        _sys.path.insert(0, _here)
    from successor.evidence_validators import validate_condition

    decision = validate_condition(task_id, receipts=receipts, subject=subject,
                                  trust_root=trust_root, exclusion=exclusion)
    if decision["verdict"] == "PASS":
        return None
    if decision["verdict"] == "NOT_APPLICABLE":
        return None
    declared = BLOCKERS[task_id]
    return (f"[{decision['state']}] {decision['reason']} "
            f"(declared condition: {declared[:160]}...)")


class SuiteCache:
    """Runs each expensive suite at most once per control-plane execution."""

    def __init__(self) -> None:
        self._cache: dict[str, tuple[int, str]] = {}

    def run(self, key: str, command: Sequence[str], *, cwd: Path | None = None) -> tuple[int, str]:
        if key not in self._cache:
            completed = subprocess.run(list(command), capture_output=True, text=True,
                                       cwd=str(cwd or OVERLAY), timeout=900, check=False)
            self._cache[key] = (completed.returncode,
                                (completed.stdout + completed.stderr).strip()[-4000:])
        return self._cache[key]


SUITES = SuiteCache()


def run_suite_once(key: str, command: Sequence[str], *, cwd: Path | None = None) -> tuple[int, str]:
    return SUITES.run(key, command, cwd=cwd)


# --------------------------------------------------------------------------- #
# Reusable check builders                                                       #
# --------------------------------------------------------------------------- #
def _artifact(check_id: str, relative: str, *, required: bool = True,
              contains: Sequence[str] = ()) -> Callable[[], CheckResult]:
    def check() -> CheckResult:
        path = OVERLAY / relative
        if not path.exists():
            return CheckResult(check_id, "artifact", required, "FAIL",
                               f"{relative} does not exist")
        text = path.read_text(encoding="utf-8", errors="replace") if path.is_file() else ""
        missing = [token for token in contains if token not in text]
        if missing:
            return CheckResult(check_id, "artifact", required, "FAIL",
                               f"{relative} is missing: {', '.join(missing)}")
        size = path.stat().st_size if path.is_file() else sum(
            f.stat().st_size for f in path.rglob("*") if f.is_file())
        return CheckResult(check_id, "artifact", required, "PASS",
                           f"{relative} present ({size} bytes)", command=f"read {relative}",
                           evidence_ref=relative)
    return check


def _unit(check_id: str, target: str, *, required: bool = True) -> Callable[[], CheckResult]:
    """Run one unittest target and report its real exit code."""
    def check() -> CheckResult:
        # unittest targets live in tests/ and import `support`, so the child
        # process must start there or every import fails as an error, not a
        # failure -- which would silently look like a real defect.
        code, output = run_suite_once(
            f"unit:{target}", [sys.executable, "-m", "unittest", "-q", target],
            cwd=OVERLAY / "tests")
        tail = output.strip().splitlines()[-1] if output.strip() else ""
        return CheckResult(check_id, "test", required, "PASS" if code == 0 else "FAIL",
                           f"{target}: {tail}", command=f"python -m unittest {target}",
                           exit_code=code, evidence_ref=f"unittest:{target}")
    return check


def _python(check_id: str, kind: str, body: Callable[[], tuple[bool, str]], *,
            required: bool = True) -> Callable[[], CheckResult]:
    def check() -> CheckResult:
        try:
            ok, detail = body()
        except Exception as exc:                                   # noqa: BLE001
            return CheckResult(check_id, kind, required, "FAIL",
                               f"{type(exc).__name__}: {exc}")
        return CheckResult(check_id, kind, required, "PASS" if ok else "FAIL", detail,
                           command=check_id, evidence_ref=check_id)
    return check


def _suite(check_id: str, key: str, command: Sequence[str], *,
           required: bool = True) -> Callable[[], CheckResult]:
    def check() -> CheckResult:
        code, output = run_suite_once(key, command)
        tail = [line for line in output.splitlines() if line.strip()]
        return CheckResult(check_id, "suite", required, "PASS" if code == 0 else "FAIL",
                           tail[-1] if tail else "(no output)",
                           command=" ".join(command), exit_code=code, evidence_ref=key)
    return check


FULL_SUITE = ("full-suite", [sys.executable, "tests/run_all.py"])
EVAL_SUITE = ("eval-corpus", [sys.executable, "eval/harness.py"])
BENCH_SUITE = ("benchmark", [sys.executable, "eval/benchmark.py", ".."])
CI_SUITE = ("ci", ["sh", "environments/ci.sh"])


# --------------------------------------------------------------------------- #
# Specific checks                                                               #
# --------------------------------------------------------------------------- #
def _registry_ids() -> tuple[bool, str]:
    from rcg.governance import build_requirements_registry
    registry = build_requirements_registry(
        OVERLAY / "control-plane" / "package" / "APPLICATION_ORDER_v1.3.0.csv")
    ok = (registry["requirement_count"] == 217 and not registry["duplicate_ids"]
          and not registry["orphans"])
    return ok, (f"{registry['requirement_count']} requirements, "
                f"{len(registry['duplicate_ids'])} duplicates, {len(registry['orphans'])} orphans")


def _rtm_bidirectional() -> tuple[bool, str]:
    from rcg.governance import build_requirements_registry, build_rtm
    rtm = build_rtm(build_requirements_registry(
        OVERLAY / "control-plane" / "package" / "APPLICATION_ORDER_v1.3.0.csv"))
    return rtm["bidirectional"] and rtm["row_count"] == 217, (
        f"{rtm['row_count']} rows, bidirectional={rtm['bidirectional']}")


def _owner_coverage() -> tuple[bool, str]:
    from rcg.governance import build_requirements_registry, owners_document
    owners = owners_document(build_requirements_registry(
        OVERLAY / "control-plane" / "package" / "APPLICATION_ORDER_v1.3.0.csv"))
    return owners["coverage"] == 1.0 and not owners["unassigned_requirements"], (
        f"coverage={owners['coverage']}, unassigned={len(owners['unassigned_requirements'])}, "
        f"phases={len(owners['phase_owners'])}")


def _ontology_closed() -> tuple[bool, str]:
    from rcg.ontology import ontology_document
    document = ontology_document()
    names = {n["name"] for n in document["node_types"]}
    bad = [e["name"] for e in document["edge_types"]
           if not (set(e["source_types"]) <= names and set(e["target_types"]) <= names)]
    return not bad, (f"{len(names)} node types, {len(document['edge_types'])} edge types, "
                     f"{len(bad)} with undeclared endpoints")


def _tiers_declared() -> tuple[bool, str]:
    from rcg.parsers import tiers_document
    document = tiers_document()
    tiers = {language["tier"] for language in document["languages"]}
    return tiers == {"full", "lexical", "metadata"} and "never silent" in document["fallback_rule"], (
        f"{len(document['languages'])} languages across tiers {sorted(tiers)}")


def _thresholds_numeric() -> tuple[bool, str]:
    from rcg.governance import thresholds_document
    acceptance = thresholds_document()["acceptance"]
    bad = [k for k, v in acceptance.items() if not isinstance(v, (int, float))]
    return not bad, f"{len(acceptance)} numeric thresholds, {len(bad)} subjective"


def _corpus_families() -> tuple[bool, str]:
    from corpus import corpus_document
    document = corpus_document()
    return document["families_present"] and document["case_count"] >= 20, (
        f"{document['case_count']} cases across {len(document['families'])} families; "
        f"{document['abstention_cases']} require abstention")


def _fixtures_present() -> tuple[bool, str]:
    manifest_path = OVERLAY / "fixtures" / "golden" / "FIXTURES.json"
    if not manifest_path.exists():
        return False, "fixtures have not been generated"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    missing = [n for n in manifest["fixtures"] if not (OVERLAY / "fixtures" / "golden" / n).is_dir()]
    return not missing, f"{len(manifest['fixtures'])} fixtures, {len(missing)} missing"


def _graph_built() -> tuple[bool, str]:
    from support import index_fixture
    index, _, _ = index_fixture("mono_repo")
    stats = index.graph.statistics()
    return stats["node_count"] > 0 and stats["edge_count"] > 0, (
        f"{stats['node_count']} nodes, {stats['edge_count']} edges from a pinned snapshot")


def _determinism() -> tuple[bool, str]:
    from support import index_fixture
    first, _, _ = index_fixture("polyglot_repo")
    second, _, _ = index_fixture("polyglot_repo")
    same = first.graph.logical_digest() == second.graph.logical_digest()
    return same, f"logical digest {'matches' if same else 'DIFFERS'} across two runs"


def _impact_separates() -> tuple[bool, str]:
    from support import index_fixture
    from rcg.impact import compute_impact
    index, _, _ = index_fixture("dependency_cycle_repo")
    seed = next(n.node_id for n in index.graph.nodes
                if n.node_type == "module" and n.qualified_name == "c")
    report = compute_impact(index.graph, [seed], run_id="CHK")
    overlap = set(report.direct_dependents) & set(report.transitive_dependents)
    return bool(report.direct_dependents) and not overlap, (
        f"{len(report.direct_dependents)} direct, {len(report.transitive_dependents)} transitive, "
        f"{len(report.cycles)} cycles, overlap={len(overlap)}")


def _incremental_reuses() -> tuple[bool, str]:
    import copy
    import dataclasses
    from support import FIXTURES, ensure_fixtures, scope_for
    from rcg.connectors import SourceCodeConnector
    from rcg.incremental import incremental_update
    from rcg.indexer import bind_snapshot, build_graph
    ensure_fixtures()
    root = (FIXTURES / "mono_repo").resolve()
    scope = scope_for(root, "mono_repo")
    base = SourceCodeConnector(scope).collect(root=root, revision="r1")
    binding = bind_snapshot(base, repository_id="mono_repo", worktree_id="chk",
                            root=root, revision="r1")
    index = build_graph([base], binding=binding)
    from rcg.canonical import sha256_of
    # Unchanged input must reuse the index; changed input must report a full
    # rebuild and zero reuse. The previous form fabricated a source_hash that no
    # longer matches its bytes (the snapshot binding rejects it) and asserted
    # `reused > rebuilt` on a CHANGED snapshot, which the runtime deliberately
    # does not do -- selective reparsing is a documented non-goal.
    same = incremental_update(previous_result=base, previous_index=index,
                              current_result=base, repository_id="mono_repo",
                              worktree_id="chk", root=root, revision="r1")
    changed = copy.deepcopy(base)
    target = next(a for a in changed.artifacts if a.path and a.path.endswith(".jad"))
    position = changed.artifacts.index(target)
    content = (target.content or b"") + b"\nschema Added { id: Count primary }\n"
    changed.artifacts[position] = dataclasses.replace(
        target, source_hash=sha256_of(content), content=content)
    update = incremental_update(previous_result=base, previous_index=changed,
                                current_result=changed, repository_id="mono_repo",
                                worktree_id="chk", root=root, revision="r2",
                                previous_index_override=None) if False else incremental_update(
        previous_result=base, previous_index=index, current_result=changed,
        repository_id="mono_repo", worktree_id="chk", root=root, revision="r2")
    reuse_ok = same.reused_nodes > 0 and same.rebuilt_nodes == 0
    rebuild_ok = update.full_rebuild and update.reused_nodes == 0 and update.rebuilt_nodes > 0
    return reuse_ok and rebuild_ok, (
        f"unchanged: {same.reused_nodes} reused / {same.rebuilt_nodes} rebuilt "
        f"({same.freshness.state}); changed: {update.reused_nodes} reused / "
        f"{update.rebuilt_nodes} rebuilt, full_rebuild={update.full_rebuild} "
        f"({update.freshness.state})")


def _abstains_without_evidence() -> tuple[bool, str]:
    from rcg.uncertainty import assess, must_abstain
    assessment = assess(evidence_refs=[])
    return must_abstain(assessment) and assessment.state == "missing", (
        f"state={assessment.state}, abstained={assessment.abstained}, "
        f"reason={assessment.abstention_reason}")


def _policy_controls() -> tuple[bool, str]:
    from rcg.policy import CONTROLS, controls_document
    document = controls_document()
    complete = all(c.stop_condition and c.requirement_id for c in CONTROLS)
    return complete and document["control_count"] >= 7, (
        f"{document['control_count']} controls, every one with a stop condition")


def _approval_binding() -> tuple[bool, str]:
    import tempfile
    from pathlib import Path as _Path
    from support import scope_for
    from rcg.authority import IdentityProvider
    from rcg.review import ApprovalGate, build_review_package
    root = _Path(tempfile.mkdtemp()).resolve()
    scope = scope_for(root, permissions=("read", "analyze", "draft"), mode="draft_only")
    package = build_review_package(
        run_id="CHK", gate="pre_apply", scope=scope, analyzed={}, not_analyzed={},
        statements=[], evidence=[], uncertainty={"state": "known", "missing_context": []},
        policy_decision={"verdict": "ALLOW", "reasons": []})
    idp = IdentityProvider()
    idp.enroll("human", "human", "s")
    idp.enroll("svc", "service", "s")
    gate = ApprovalGate()
    decision = gate.decide(package, principal=idp.authenticate("human", "s"), decision="approve")
    before = gate.authorizes(decision, package, scope)[0]
    package.statements.append({"text": "x", "derivation": "model_inference",
                               "evidence_refs": [], "impact": "low"})
    after = gate.authorizes(decision, package, scope)[0]
    service_blocked = False
    try:
        gate.decide(package, principal=idp.authenticate("svc", "s"), decision="approve")
    except Exception:
        service_blocked = True
    return before and not after and service_blocked, (
        f"human approval valid={before}; after material change valid={after}; "
        f"service approval blocked={service_blocked}")


def _ledger_tamper_evident() -> tuple[bool, str]:
    import tempfile
    from pathlib import Path as _Path
    from rcg.provenance import EvidenceLedger, EvidenceRef
    directory = _Path(tempfile.mkdtemp())
    ledger = EvidenceLedger(directory / "E.jsonl", "CHK")
    ledger.record_fact(subject="s", statement="a", derivation="source", confidence="known",
                       evidence=[EvidenceRef(artifact_id="A", source_system="source_code",
                                             revision="r", source_hash="sha256:" + "0" * 64,
                                             observed_at="2026-01-01T00:00:00Z")])
    good = ledger.verify()[0]
    path = directory / "E.jsonl"
    path.write_text(path.read_text(encoding="utf-8").replace('"a"', '"b"'), encoding="utf-8")
    bad, reason = EvidenceLedger(path, "CHK").verify()
    return good and not bad, f"clean chain verifies={good}; tampered chain detected: {reason}"


def _sandbox_confines() -> tuple[bool, str]:
    from rcg.sandbox import Sandbox, SandboxPolicy
    sandbox = Sandbox(SandboxPolicy(timeout_seconds=5))
    ran = sandbox.run_python("print('ok')")
    scrubbed = sandbox.run_python("import os; print(len(os.environ))")
    timed_out = Sandbox(SandboxPolicy(timeout_seconds=1)).run_python("import time; time.sleep(5)")
    return ran.ok and timed_out.timed_out, (
        f"executed={ran.ok}, env vars visible={scrubbed.stdout.strip()}, "
        f"timeout enforced={timed_out.timed_out}, "
        f"enforcement={ran.enforcement['rlimits_applied']}")


def _secrets_never_leak() -> tuple[bool, str]:
    from rcg.security import classify, redact
    text = "api_key = 'AKIAIOSFODNN7EXAMPLE'\npassword = 'hunter2hunter2'\n"
    classification, findings = classify(text, path="config.py")
    leaked = any("AKIA" in str(f.as_document()) or "hunter2" in str(f.as_document())
                 for f in findings)
    redacted, count = redact(text)
    clean = "AKIA" not in redacted and "hunter2" not in redacted
    return classification == "secret" and not leaked and clean and count > 0, (
        f"classification={classification}, findings={len(findings)}, redactions={count}, "
        f"leak in findings={leaked}")


def _observability_alerts() -> tuple[bool, str]:
    from rcg.observability import Metrics, evaluate_alerts
    metrics = Metrics()
    metrics.increment("policy.evaluations", 10)
    metrics.increment("policy.denied", 5)
    # Ledger-record shape ({"event": ..., "detail": ...}), which is what
    # Pipeline._finish passes; a flat-dict fixture would pass this check while
    # every rule stayed dead on the real events.
    alerts = evaluate_alerts(
        events=[{"event": {"event_type": "policy.decision", "outcome": "denied"},
                 "detail": {"permission": "modify"}},
                {"event": {"event_type": "connector.denied", "outcome": "denied"},
                 "detail": {"external": True}},
                {"event": {"event_type": "review.decision", "actor_kind": "service"},
                 "detail": {}}],
        metrics=metrics, baseline_permissions=["read"])
    ids = {a["rule_id"] for a in alerts}
    expected = {"ALERT-WRITE-01", "ALERT-PERM-01", "ALERT-EXT-01",
                "ALERT-SELFAPP-01", "ALERT-DENY-01"}
    return expected <= ids, f"synthetic failures fired {sorted(ids)}"


def _run_reconstructs() -> tuple[bool, str]:
    from rcg.workflow import WorkflowMachine
    machine = WorkflowMachine("CHK")
    for event in ("authority_established", "revisions_pinned", "collect_evidence"):
        machine.fire(event, actor="a", actor_kind="system")
    restored = WorkflowMachine.restore(machine.snapshot())
    return restored.state == machine.state and restored.history == machine.history, (
        f"state {machine.state} and {len(machine.history)} transitions reconstructed exactly")


def _flags_toggle() -> tuple[bool, str]:
    import tempfile
    from pathlib import Path as _Path
    from rcg.rollout import FlagError, FlagStore
    store = FlagStore(_Path(tempfile.mkdtemp()) / "FLAGS.json")
    store.set("rcg.enabled", True, actor="chk", reason="check")
    store.emergency_disable(actor="chk", reason="check")
    blocked = False
    try:
        store.assert_permitted("read", mode="read_only")
    except FlagError:
        blocked = True
    return blocked and not store.enabled, (
        "emergency disable cleared the master switch and blocked further privileged action")


def _license_gate() -> tuple[bool, str]:
    from rcg.licensing import evaluate_inventory
    report = evaluate_inventory([{"part": "a", "donor": "d", "license": "GPL-3.0"},
                                 {"part": "b", "donor": "d", "license": ""}])
    clean = evaluate_inventory([{"part": "a", "donor": "d", "license": "MIT"}])
    return not report.promotable and clean.promotable, (
        f"copyleft/unlicensed blocked={len(report.blocked)}; permissive promotable="
        f"{clean.promotable}")


def _backup_restore() -> tuple[bool, str]:
    import tempfile
    from pathlib import Path as _Path
    from rcg.versionstore import VersionStore
    base = _Path(tempfile.mkdtemp())
    store = VersionStore(base / "store")
    store.commit("graph/main", {"nodes": [1]}, expected_parent=None)
    store.commit("graph/main", {"nodes": [1, 2]})
    store.backup(base / "backup")
    restored = VersionStore.restore(base / "backup", base / "restored")
    report = restored.verify()
    return report["ok"] and restored.at_revision("graph/main", 0) == {"nodes": [1]}, (
        f"restored {report['snapshots_checked']} snapshots, integrity ok={report['ok']}")


def _external_fixtures() -> tuple[bool, str]:
    from support import FIXTURES, ensure_fixtures, scope_for
    from rcg.connectors import DiscussionConnector, IssueConnector, PullRequestConnector
    ensure_fixtures()
    records = json.loads((FIXTURES / "external_sources.json").read_text(encoding="utf-8"))
    root = (FIXTURES / "git_history_repo").resolve()
    counts = {}
    for connector_class, system in ((PullRequestConnector, "pull_requests"),
                                    (IssueConnector, "issue_tracker"),
                                    (DiscussionConnector, "design_discussions")):
        scope = scope_for(root, "git_history_repo", sources=("source_code", system),
                          external=(system,))
        result = connector_class(scope).collect(records=records[system])
        counts[system] = len(result.artifacts)
        if result.denied or not result.artifacts:
            return False, f"{system} produced no provenance-bearing artifacts"
    return True, f"pinned fixtures ingested with provenance: {counts}"


def _git_history() -> tuple[bool, str]:
    from support import FIXTURES, ensure_fixtures, scope_for
    from rcg.connectors import HistoryConnector
    ensure_fixtures()
    root = (FIXTURES / "git_history_repo").resolve()
    if not (root / ".git").exists():
        return False, "git is unavailable in this environment; no real history could be ingested"
    scope = scope_for(root, "git_history_repo", sources=("source_code", "git_history"))
    result = HistoryConnector(scope).collect(root=root, revision="HEAD")
    return len(result.artifacts) >= 2, (
        f"{len(result.artifacts)} commits ingested with stable identity and provenance")


# --------------------------------------------------------------------------- #
# Task -> checks                                                                #
# --------------------------------------------------------------------------- #
def _module(check_id: str, dotted: str, *attributes: str) -> Callable[[], CheckResult]:
    """Assert a module exists and exposes the names its task promises."""
    def body() -> tuple[bool, str]:
        import importlib
        module = importlib.import_module(dotted)
        missing = [a for a in attributes if not hasattr(module, a)]
        return not missing, (f"{dotted} exposes {len(attributes) - len(missing)}/"
                             f"{len(attributes)} declared names"
                             + (f"; missing {missing}" if missing else ""))
    return _python(check_id, "contract", body)


def _connector_fixture(check_id: str, system: str) -> Callable[[], CheckResult]:
    """DATA-* : a pinned fixture is ingested with authorized scope and provenance."""
    def body() -> tuple[bool, str]:
        from support import FIXTURES, ensure_fixtures, scope_for
        from rcg.connectors import REGISTRY as C
        ensure_fixtures()
        connector_class = C[system]
        if connector_class.external:
            records = json.loads(
                (FIXTURES / "external_sources.json").read_text(encoding="utf-8"))[system]
            root = (FIXTURES / "git_history_repo").resolve()
            scope = scope_for(root, "git_history_repo", sources=("source_code", system),
                              external=(system,))
            result = connector_class(scope).collect(records=records)
        else:
            fixture = "git_history_repo" if system == "git_history" else "mono_repo"
            root = (FIXTURES / fixture).resolve()
            scope = scope_for(root, fixture, sources=("source_code", system))
            result = connector_class(scope).collect(root=root, revision="HEAD"
                                                    if system == "git_history" else "r1")
        if result.denied:
            return False, f"{system}: authorized scope was denied"
        if not result.artifacts:
            return False, f"{system}: fixture produced no artifacts"
        provenance_ok = all(a.source_hash.startswith("sha256:") and a.revision
                            and a.evidence_ref().ref_id for a in result.artifacts)
        # Denial without authorization is the other half of the same acceptance,
        # so the negative scope must authorize a *different* system than the one
        # under test -- otherwise the "denied" leg silently tests nothing.
        other = "adrs" if system != "adrs" else "code_owners"
        unauth = scope_for(root, "x", sources=(other,), external=())
        denied = (connector_class(unauth).collect(records=[]).denied
                  if connector_class.external
                  else connector_class(unauth).collect(root=root, revision="r1").denied)
        return provenance_ok and denied, (
            f"{system}: {len(result.artifacts)} artifacts with stable identity/revision/provenance; "
            f"unauthorized scope denied={denied}")
    return _python(check_id, "integration", body)


#: task_id -> list of check factories. Every task has at least one required
#: check, and every check is real.
_T: dict[str, list[Callable[[], CheckResult]]] = {}


def _add(task: str, *factories: Callable[[], CheckResult]) -> None:
    _T[task] = list(factories)


# ---- Phase 0: requirements hardening --------------------------------------
_add("AUD-001", _python("stable-ids", "analysis", _registry_ids),
     _artifact("requirements-registry", "registry/REQUIREMENTS.json"),
     _unit("aud-001-tests", "test_governance.TestAud001And002RegistryAndRtm"))
_add("AUD-002", _python("rtm-bidirectional", "analysis", _rtm_bidirectional),
     _artifact("rtm-artifact", "registry/RTM.json"),
     _unit("aud-002-tests", "test_governance.TestAud001And002RegistryAndRtm"))
_add("AUD-003", _python("owner-coverage", "analysis", _owner_coverage),
     _artifact("owners-artifact", "registry/OWNERS.json"),
     _unit("aud-003-tests", "test_governance.TestAud003Owners"))
_add("AUD-004", _python("ontology-closed", "contract", _ontology_closed),
     _artifact("ontology-artifact", "registry/ONTOLOGY.json"),
     _unit("aud-004-tests", "test_governance.TestAud004OntologyRoundTrip"))
_add("AUD-005", _python("tiers-declared", "contract", _tiers_declared),
     _artifact("tiers-artifact", "registry/LANGUAGE_TIERS.json"),
     _unit("aud-005-tests", "test_governance.TestAud005LanguageTiers"))
_add("AUD-006", _suite("benchmark", *BENCH_SUITE),
     _artifact("slo-artifact", "registry/SLO.json"),
     _unit("aud-006-tests", "test_governance.TestAud006And014BenchmarksAndBudgets"))
_add("AUD-007", _unit("convergence", "test_governance.TestAud007ConcurrencyAndConvergence"),
     _python("incremental-reuse", "integration", _incremental_reuses))
_add("AUD-008", _python("backup-restore", "integration", _backup_restore),
     _unit("aud-008-tests", "test_governance.TestAud008BackupRestore"),
     _artifact("recovery-runbook", "docs/DOC-11-incident-rollback-runbook.md",
               contains=["Restoring the store"]))
_add("AUD-009", _unit("migrations", "test_governance.TestAud009Migrations"),
     _artifact("migrations-artifact", "registry/MIGRATIONS.json"))
_add("AUD-010", _unit("resilience", "test_governance.TestAud010ConnectorResilience"),
     _artifact("connector-doc", "docs/DOC-03-connector-inventory.md",
               contains=["tombstone", "credential expiry"]))
_add("AUD-011", _unit("lifecycle", "test_governance.TestAud011Lifecycle"),
     _artifact("lifecycle-artifact", "registry/LIFECYCLE.json"))
_add("AUD-012", _python("thresholds-numeric", "analysis", _thresholds_numeric),
     _artifact("thresholds-artifact", "registry/THRESHOLDS.json"),
     _unit("aud-012-tests", "test_governance.TestAud018ReleasePolicy"))
_add("AUD-013", _python("license-gate", "policy", _license_gate),
     _artifact("supply-chain-artifact", "registry/SUPPLY_CHAIN.json"),
     _unit("aud-013-tests", "test_governance.TestAud013SupplyChain"),
     _unit("supply-chain-suite", "test_supply_chain.TestSupplyChain"))
_add("AUD-014", _artifact("budgets-artifact", "registry/BUDGETS.json"),
     _unit("aud-014-tests", "test_governance.TestAud006And014BenchmarksAndBudgets"))
_add("AUD-015", _python("flags-toggle", "policy", _flags_toggle),
     _artifact("rollout-artifact", "registry/ROLLOUT.json"),
     _unit("aud-015-tests", "test_governance.TestAud015Rollout"))
_add("AUD-016", _python("fixtures-present", "artifact", _fixtures_present),
     _unit("aud-016-tests", "test_governance.TestAud016Fixtures"))
_add("AUD-017", _unit("review-surface", "test_governance.TestAud017ReviewSurface"),
     _artifact("approval-policy-doc", "docs/DOC-09-human-approval-policy.md"))
_add("AUD-018", _unit("release-policy", "test_governance.TestAud018ReleasePolicy"),
     _artifact("changelog", "docs/CHANGELOG.md", contains=["Rollback path", "breaking"]),
     _artifact("release-policy-artifact", "registry/RELEASE_POLICY.json"))

# ---- Phase 1: authority, scope, identity, workflow state -------------------
_add("IMPL-01", _module("scope-module", "rcg.scope", "ScopeContract", "PERMISSIONS", "PRIVILEGED"),
     _unit("scope-tests", "test_unit.TestScope"))
_add("IMPL-02", _module("schema-registry", "rcg.schemas", "REGISTRY", "validate", "SchemaError"),
     _unit("schema-tests", "test_unit.TestSchemas"))
_add("IMPL-03", _module("workflow-module", "rcg.workflow", "TRANSITIONS", "WorkflowMachine"),
     _unit("workflow-tests", "test_unit.TestWorkflow"))
_add("FLOW-01", _unit("authority-e2e", "test_e2e.TestE2E06RollbackAbort"),
     _module("authority-module", "rcg.authority", "AuthorityRecord", "IdentityProvider"))
_add("FLOW-02", _python("pin-determinism", "integration", _determinism),
     _unit("pin-tests", "test_verify.TestVerify05ReproducibleForAPinnedRevision"))
_add("API-01", _unit("api-schema-tests", "test_unit.TestSchemas"),
     _artifact("run-state-doc", "docs/DOC-08-run-state-schema.md"))
_add("API-02", _unit("scope-contract-tests", "test_unit.TestScope"),
     _module("scope-schema", "rcg.schemas", "REGISTRY"))
_add("API-05", _unit("review-decision-tests", "test_adversarial.TestAdv07FalseHumanApprovalClaims"),
     _python("approval-binding", "contract", _approval_binding))
_add("XAUTH-01", _module("identity", "rcg.authority", "IdentityProvider", "Principal"),
     _unit("identity-tests", "test_unit.TestScope"),
     _unit("authz-adversarial", "test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls"))
_add("XAUTH-02", _unit("source-authorization", "test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls"),
     _python("connector-denial", "integration", _external_fixtures))
_add("XAUTH-03", _unit("permission-separation", "test_unit.TestScope"),
     _artifact("permission-matrix", "docs/DOC-04-permission-matrix.md", contains=["privileged"]))
_add("XAUTH-04", _unit("read-only-mode", "test_unit.TestScope"),
     _artifact("permission-matrix-modes", "docs/DOC-04-permission-matrix.md",
               contains=["read_only", "draft_only"]))
_add("XAUTH-05", _module("leases", "rcg.authority", "CredentialLease", "MAX_LEASE_SECONDS"),
     _unit("lease-tests", "test_unit.TestScope"))
_add("XAUTH-06", _unit("infrastructure-enforcement", "test_adversarial.TestAdv01MaliciousRepositoryInstructions"),
     _python("policy-controls", "policy", _policy_controls))
_add("XAUTH-07", _unit("recorded-authority", "test_e2e.TestInt01Integration"),
     _python("run-reconstruction", "integration", _run_reconstructs))

# ---- Phase 2: connectors, identity, provenance ------------------------------
for _task, _system in (("DATA-01", "source_code"), ("DATA-02", "build_metadata"),
                       ("DATA-03", "tests"), ("DATA-04", "git_history"),
                       ("DATA-05", "pull_requests"), ("DATA-06", "adrs"),
                       ("DATA-07", "issue_tracker"), ("DATA-08", "code_owners"),
                       ("DATA-09", "design_discussions")):
    _add(_task, _connector_fixture(f"{_task.lower()}-fixture", _system),
         _unit(f"{_task.lower()}-tests", "test_governance.TestDataConnectorFixtures"))
_add("COMP-04", _unit("entity-resolution", "test_verify.TestVerify04StaleAndMissingMarked"),
     _module("resolver", "rcg.graph", "resolve_targets"))
_add("COMP-10", _module("provenance-service", "rcg.provenance", "EvidenceLedger", "EvidenceRef"),
     _python("ledger-tamper", "security", _ledger_tamper_evident))
_add("ARCH-01", _module("connector-layer", "rcg.connectors", "Connector", "REGISTRY"),
     _artifact("connector-inventory", "docs/DOC-03-connector-inventory.md"),
     _unit("connector-contract", "test_governance.TestAud010ConnectorResilience"))
_add("ARCH-02", _module("identity-layer", "rcg.ids", "artifact_id", "node_id", "edge_id"),
     _unit("identity-tests", "test_unit.TestCanonical"))
_add("IMPL-04", _python("ledger-tamper", "security", _ledger_tamper_evident),
     _unit("provenance-tests", "test_unit.TestProvenance"),
     _artifact("provenance-doc", "docs/DOC-07-provenance-schema.md"))
_add("FLOW-03", _unit("authorized-collection", "test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls"),
     _python("external-fixtures", "integration", _external_fixtures))
_add("FLOW-04", _python("graph-built", "integration", _graph_built),
     _unit("index-tests", "test_verify.TestVerify01EdgesTraceToSource"))
_add("API-03", _unit("evidence-ref-schema", "test_unit.TestSchemas"),
     _module("evidence-ref", "rcg.provenance", "EvidenceRef"))
_add("STORE-03", _unit("evidence-store", "test_unit.TestProvenance"),
     _python("backup-restore", "storage", _backup_restore))
for _task, _check in (("XPROV-01", "test_verify.TestVerify01EdgesTraceToSource"),
                      ("XPROV-02", "test_verify.TestVerify02IncrementalAndRevisionAware"),
                      ("XPROV-03", "test_adversarial.TestAdv06HallucinatedProvenance"),
                      ("XPROV-04", "test_unit.TestProvenance"),
                      ("XPROV-05", "test_unit.TestProvenance"),
                      ("XPROV-06", "test_unit.TestProvenance"),
                      ("XPROV-07", "test_e2e.TestInt01Integration")):
    _add(_task, _unit(f"{_task.lower()}-tests", _check),
         _python(f"{_task.lower()}-ledger", "security", _ledger_tamper_evident))

# ---- Phase 3: graph ingestion and persistent state --------------------------
_add("PAPER-CAP-01", _python("graph-built", "integration", _graph_built),
     _unit("capability-e2e", "test_e2e.TestE2E01GoldenPath"))
_add("COMP-01", _module("parsers", "rcg.parsers", "parse_file", "tier_for", "TIERS"),
     _unit("parser-tests", "test_unit.TestParsers"))
_add("COMP-02", _python("graph-built", "integration", _graph_built),
     _unit("graph-tests", "test_unit.TestGraph"),
     _unit("edge-traceability", "test_verify.TestVerify01EdgesTraceToSource"))
_add("COMP-03", _unit("temporal-store", "test_unit.TestVersionStore"),
     _python("backup-restore", "storage", _backup_restore))
_add("ARCH-03", _module("store", "rcg.versionstore", "VersionStore", "ConcurrencyError"),
     _unit("store-tests", "test_unit.TestVersionStore"))
_add("STORE-01", _python("run-reconstruction", "storage", _run_reconstructs),
     _unit("workflow-persistence", "test_unit.TestWorkflow"))
_add("STORE-02", _unit("versioned-metadata", "test_verify.TestVerify02IncrementalAndRevisionAware"),
     _unit("store-tests", "test_unit.TestVersionStore"))

# ---- Phase 4: historical context, retrieval and query -----------------------
_add("PAPER-CAP-03", _python("git-history", "integration", _git_history),
     _unit("rationale-tests", "test_governance.TestDataConnectorFixtures"))
_add("COMP-05", _module("retrieval", "rcg.retrieval", "RetrievalIndex", "Passage", "expand"),
     _unit("retrieval-tests", "test_adversarial.TestAdv02MissingStaleConflictingEvidence"))
_add("COMP-06", _module("rationale", "rcg.rationale", "extract_rationale", "Rationale"),
     _python("git-history", "integration", _git_history))
_add("COMP-07", _module("query", "rcg.query", "GraphQuery", "QueryBudget"),
     _unit("query-tests", "test_verify.TestVerify05ReproducibleForAPinnedRevision"))
_add("ARCH-04", _unit("query-layer", "test_verify.TestVerify04StaleAndMissingMarked"),
     _python("determinism", "integration", _determinism))

# ---- Phase 5: incremental updates and impact --------------------------------
_add("PAPER-CAP-02", _python("incremental-reuse", "integration", _incremental_reuses),
     _unit("incremental-tests", "test_verify.TestVerify02IncrementalAndRevisionAware"))
_add("PAPER-CAP-04", _python("impact-separates", "integration", _impact_separates),
     _unit("impact-tests", "test_verify.TestVerify03ImpactDirectAndTransitive"))
_add("COMP-08", _python("incremental-reuse", "integration", _incremental_reuses),
     _unit("convergence", "test_governance.TestAud007ConcurrencyAndConvergence"))
_add("COMP-09", _python("impact-separates", "integration", _impact_separates),
     _unit("impact-tests", "test_verify.TestVerify03ImpactDirectAndTransitive"))

# ---- Phase 6: deterministic analysis, model reasoning, uncertainty ----------
_add("PAPER-CAP-05", _python("abstains", "analysis", _abstains_without_evidence),
     _unit("abstention-e2e", "test_e2e.TestE2E05MissingContextAbstention"))
_add("ARCH-05", _module("analysis", "rcg.analysis", "ANALYZERS", "run_analyzers"),
     _unit("analysis-integration", "test_e2e.TestInt01Integration"))
_add("ARCH-06", _module("reasoning", "rcg.reasoning", "Orchestrator", "AbstainingProvider", "PROMPTS"),
     _unit("reasoning-tests", "test_adversarial.TestAdv06HallucinatedProvenance"))
_add("IMPL-07", _python("abstains", "analysis", _abstains_without_evidence),
     _unit("uncertainty-tests", "test_unit.TestUncertainty"))
_add("FLOW-05", _module("analyzers-first", "rcg.analysis", "ANALYZERS"),
     _unit("pipeline-order", "test_e2e.TestInt01Integration"))
_add("FLOW-06", _unit("labeled-context", "test_adversarial.TestAdv01MaliciousRepositoryInstructions"),
     _module("retrieval-labels", "rcg.retrieval", "Passage"))
_add("FLOW-07", _module("intent", "rcg.intent", "classify_request", "INTENT_RULES"),
     _unit("bounded-draft", "test_e2e.TestE2E01GoldenPath"))
_add("API-04", _unit("uncertainty-schema", "test_unit.TestUncertainty"),
     _unit("schema-tests", "test_unit.TestSchemas"))
for _task in ("MODEL-01", "MODEL-02", "MODEL-03", "MODEL-04", "MODEL-05", "MODEL-06", "MODEL-07"):
    _add(_task, _unit(f"{_task.lower()}-adversarial", "test_adversarial.TestAdv06HallucinatedProvenance"),
         _suite(f"{_task.lower()}-eval", *EVAL_SUITE),
         _artifact(f"{_task.lower()}-inventory", "docs/DOC-06-model-tool-inventory.md",
                   contains=["prompt id", "abstain"]))
_add("MODEL-06", _unit("model-cannot-escalate", "test_adversarial.TestAdv07FalseHumanApprovalClaims"),
     _python("policy-controls", "policy", _policy_controls),
     _suite("model-06-eval", *EVAL_SUITE))
for _task, _cls in (("XUNC-01", "test_unit.TestUncertainty"),
                    ("XUNC-02", "test_unit.TestUncertainty"),
                    ("XUNC-03", "test_adversarial.TestAdv02MissingStaleConflictingEvidence"),
                    ("XUNC-04", "test_unit.TestUncertainty"),
                    ("XUNC-05", "test_unit.TestUncertainty"),
                    ("XUNC-06", "test_adversarial.TestAdv06HallucinatedProvenance")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls), _suite(f"{_task.lower()}-eval", *EVAL_SUITE))
_add("XTOOL-01", _module("analyzers", "rcg.analysis", "ANALYZERS"),
     _unit("deterministic-first", "test_e2e.TestInt01Integration"))
_add("XTOOL-05", _unit("stale-demotion", "test_adversarial.TestAdv02MissingStaleConflictingEvidence"),
     _module("retrieval", "rcg.retrieval", "RetrievalIndex"))
_add("XTOOL-06", _module("versions", "rcg.reasoning", "ModelIdentity", "PROMPTS"),
     _unit("version-capture", "test_e2e.TestInt01Integration"))
_add("XTOOL-07", _unit("provider-failure", "test_e2e.TestE2E04ToolFailure"),
     _module("fallback", "rcg.reasoning", "ProviderFailure"))

# ---- Phase 7: human review, policy and approval ------------------------------
for _task in ("PAPER-GRD-01", "PAPER-GRD-02", "PAPER-GRD-03", "PAPER-GRD-04"):
    _add(_task, _python(f"{_task.lower()}-controls", "policy", _policy_controls),
         _unit(f"{_task.lower()}-tests", "test_adversarial.TestAdv03OversizedScope"),
         _artifact(f"{_task.lower()}-matrix", "registry/CONTROLS.json"))
_add("ARCH-07", _module("policy", "rcg.policy", "CONTROLS", "evaluate", "Verdict"),
     _python("policy-controls", "policy", _policy_controls))
_add("ARCH-09", _module("review", "rcg.review", "ApprovalGate", "build_review_package"),
     _unit("review-surface", "test_governance.TestAud017ReviewSurface"))
_add("IMPL-06", _python("policy-controls", "policy", _policy_controls),
     _unit("guardrail-tests", "test_adversarial.TestAdv03OversizedScope"))
_add("IMPL-08", _unit("review-surface", "test_governance.TestAud017ReviewSurface"),
     _unit("review-e2e", "test_e2e.TestE2E01GoldenPath"))
_add("FLOW-09", _unit("review-exposes-gaps", "test_e2e.TestE2E01GoldenPath"),
     _unit("review-surface", "test_governance.TestAud017ReviewSurface"))
_add("FLOW-10", _python("approval-binding", "contract", _approval_binding),
     _unit("gate-tests", "test_unit.TestWorkflow"),
     _unit("approval-adversarial", "test_adversarial.TestAdv07FalseHumanApprovalClaims"))
for _task, _cls in (("HUMAN-01", "test_e2e.TestE2E01GoldenPath"),
                    ("HUMAN-02", "test_e2e.TestE2E01GoldenPath"),
                    ("HUMAN-03", "test_e2e.TestE2E03ScopeNarrowing"),
                    ("HUMAN-04", "test_e2e.TestE2E02HumanRejection"),
                    ("HUMAN-05", "test_governance.TestAud017ReviewSurface"),
                    ("HUMAN-06", "test_adversarial.TestAdv07FalseHumanApprovalClaims"),
                    ("HUMAN-07", "test_governance.TestAud017ReviewSurface")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls),
         _python(f"{_task.lower()}-binding", "contract", _approval_binding))
for _task, _cls in (("XHITL-01", "test_e2e.TestE2E01GoldenPath"),
                    ("XHITL-02", "test_unit.TestWorkflow"),
                    ("XHITL-03", "test_e2e.TestE2E03ScopeNarrowing"),
                    ("XHITL-04", "test_governance.TestAud017ReviewSurface"),
                    ("XHITL-05", "test_adversarial.TestAdv07FalseHumanApprovalClaims")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls),
         _python(f"{_task.lower()}-binding", "contract", _approval_binding))

# ---- Phase 8: security, privacy, sandboxing ----------------------------------
_add("STORE-06", _unit("retention", "test_governance.TestAud011Lifecycle"),
     _python("backup-restore", "storage", _backup_restore))
for _task, _cls in (("SEC-01", "test_adversarial.TestAdv01MaliciousRepositoryInstructions"),
                    ("SEC-02", "test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls"),
                    ("SEC-03", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("SEC-04", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("SEC-05", "test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls"),
                    ("SEC-06", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("SEC-07", "test_adversarial.TestAdv07FalseHumanApprovalClaims"),
                    ("SEC-08", "test_unit.TestProvenance")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls),
         _python(f"{_task.lower()}-secrets", "security", _secrets_never_leak))
for _task, _cls in (("XSEC-01", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("XSEC-02", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("XSEC-03", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("XSEC-05", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("XSEC-06", "test_governance.TestAud011Lifecycle"),
                    ("XSEC-07", "test_adversarial.TestAdv01MaliciousRepositoryInstructions")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls),
         _artifact(f"{_task.lower()}-threat-model", "docs/DOC-05-threat-model.md",
                   contains=["Residual risk"]))
_add("XTOOL-02", _unit("tool-validation", "test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls"),
     _unit("schema-tests", "test_unit.TestSchemas"))
_add("XTOOL-03", _python("sandbox-confinement", "security", _sandbox_confines),
     _module("sandbox-module", "rcg.sandbox", "Sandbox", "SandboxPolicy"))
_add("XTOOL-04", _unit("scope-bounded-retrieval", "test_verify.TestVerify04StaleAndMissingMarked"),
     _unit("scope-tests", "test_unit.TestScope"))

# ---- Phase 9: observability, audit, reproducibility --------------------------
_add("ARCH-08", _python("ledger-tamper", "security", _ledger_tamper_evident),
     _unit("provenance-tests", "test_unit.TestProvenance"))
_add("ARCH-10", _python("alerts", "operations", _observability_alerts),
     _module("observability", "rcg.observability", "Metrics", "Tracer", "ALERT_RULES"))
_add("IMPL-05", _unit("freshness", "test_verify.TestVerify02IncrementalAndRevisionAware"),
     _python("determinism", "integration", _determinism))
_add("IMPL-09", _unit("audit-trail", "test_e2e.TestInt01Integration"),
     _python("ledger-tamper", "security", _ledger_tamper_evident))
_add("FLOW-11", _unit("decision-trail", "test_e2e.TestInt01Integration"),
     _python("ledger-tamper", "security", _ledger_tamper_evident))
_add("API-06", _unit("idempotency", "test_unit.TestWorkflow"),
     _unit("schema-tests", "test_unit.TestSchemas"))
_add("API-07", _module("deterministic-ids", "rcg.ids", "deterministic_id", "run_id", "artifact_id"),
     _unit("id-tests", "test_unit.TestCanonical"))
_add("API-08", _unit("migrations", "test_governance.TestAud009Migrations"),
     _artifact("release-policy", "registry/RELEASE_POLICY.json"))
_add("STORE-04", _unit("approval-history", "test_adversarial.TestAdv07FalseHumanApprovalClaims"),
     _python("approval-binding", "contract", _approval_binding))
_add("STORE-05", _module("versions", "rcg.schemas", "schema_versions"),
     _unit("version-capture", "test_e2e.TestInt01Integration"))
_add("STORE-07", _python("ledger-tamper", "security", _ledger_tamper_evident),
     _unit("append-only", "test_unit.TestProvenance"))
for _task, _cls in (("XSTATE-01", "test_verify.TestVerify05ReproducibleForAPinnedRevision"),
                    ("XSTATE-02", "test_e2e.TestInt01Integration"),
                    ("XSTATE-03", "test_unit.TestWorkflow"),
                    ("XSTATE-04", "test_verify.TestVerify05ReproducibleForAPinnedRevision"),
                    ("XSTATE-05", "test_unit.TestCanonical")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls),
         _python(f"{_task.lower()}-reconstruct", "operations", _run_reconstructs))
for _task, _cls in (("XOBS-01", "test_e2e.TestInt01Integration"),
                    ("XOBS-02", "test_e2e.TestInt01Integration"),
                    ("XOBS-03", "test_e2e.TestInt01Integration"),
                    ("XOBS-04", "test_e2e.TestInt01Integration"),
                    ("XOBS-05", "test_e2e.TestInt01Integration")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls),
         _python(f"{_task.lower()}-alerts", "operations", _observability_alerts))

# ---- Phase 10: verification, testing, evaluation -----------------------------
_add("IMPL-10", _suite("full-suite", *FULL_SUITE), _suite("eval-corpus", *EVAL_SUITE),
     _suite("benchmark", *BENCH_SUITE))
_add("FLOW-08", _unit("independent-verification", "test_e2e.TestE2E01GoldenPath"),
     _suite("full-suite", *FULL_SUITE))
for _task, _cls in (("VERIFY-01", "test_verify.TestVerify01EdgesTraceToSource"),
                    ("VERIFY-02", "test_verify.TestVerify02IncrementalAndRevisionAware"),
                    ("VERIFY-03", "test_verify.TestVerify03ImpactDirectAndTransitive"),
                    ("VERIFY-04", "test_verify.TestVerify04StaleAndMissingMarked"),
                    ("VERIFY-05", "test_verify.TestVerify05ReproducibleForAPinnedRevision")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls), _suite("eval-corpus", *EVAL_SUITE))
_add("TEST-UNIT-01", _unit("unit-suite", "test_unit"), _suite("full-suite", *FULL_SUITE))
_add("TEST-INT-01", _unit("integration-suite", "test_e2e.TestInt01Integration"),
     _suite("full-suite", *FULL_SUITE))
for _task, _cls in (("TEST-ADV-01", "test_adversarial.TestAdv01MaliciousRepositoryInstructions"),
                    ("TEST-ADV-02", "test_adversarial.TestAdv02MissingStaleConflictingEvidence"),
                    ("TEST-ADV-03", "test_adversarial.TestAdv03OversizedScope"),
                    ("TEST-ADV-04", "test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls"),
                    ("TEST-ADV-05", "test_adversarial.TestAdv05SensitiveDataLeakage"),
                    ("TEST-ADV-06", "test_adversarial.TestAdv06HallucinatedProvenance"),
                    ("TEST-ADV-07", "test_adversarial.TestAdv07FalseHumanApprovalClaims")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls), _suite("eval-corpus", *EVAL_SUITE))
for _task, _cls in (("TEST-E2E-01", "test_e2e.TestE2E01GoldenPath"),
                    ("TEST-E2E-02", "test_e2e.TestE2E02HumanRejection"),
                    ("TEST-E2E-03", "test_e2e.TestE2E03ScopeNarrowing"),
                    ("TEST-E2E-04", "test_e2e.TestE2E04ToolFailure"),
                    ("TEST-E2E-05", "test_e2e.TestE2E05MissingContextAbstention"),
                    ("TEST-E2E-06", "test_e2e.TestE2E06RollbackAbort")):
    _add(_task, _unit(f"{_task.lower()}-tests", _cls), _suite("ci", *CI_SUITE))
_add("XEVAL-01", _python("corpus-families", "analysis", _corpus_families),
     _suite("eval-corpus", *EVAL_SUITE),
     _artifact("evaluation-plan", "docs/DOC-10-evaluation-plan.md"))
_add("XEVAL-02", _python("corpus-families", "analysis", _corpus_families),
     _suite("eval-corpus", *EVAL_SUITE))
_add("XEVAL-03", _suite("eval-corpus", *EVAL_SUITE),
     _artifact("thresholds", "registry/THRESHOLDS.json"),
     _unit("grounding-tests", "test_verify.TestVerify01EdgesTraceToSource"))
_add("XEVAL-04", _unit("review-burden", "test_governance.TestAud017ReviewSurface"),
     _suite("eval-corpus", *EVAL_SUITE))
_add("XEVAL-05", _suite("eval-corpus", *EVAL_SUITE),
     _unit("guardrail-adversarial", "test_adversarial.TestAdv03OversizedScope"),
     _python("policy-controls", "policy", _policy_controls))
_add("XEVAL-07", _artifact("thresholds", "registry/THRESHOLDS.json"),
     _artifact("rollback-runbook", "docs/DOC-11-incident-rollback-runbook.md",
               contains=["Rollback"]),
     _unit("release-policy", "test_governance.TestAud018ReleasePolicy"))

# ---- Phase 11: environments and documentation --------------------------------
_add("ENV-01", _artifact("env-profiles", "environments/ENVIRONMENTS.json",
                         contains=["developer_local_sandbox"]),
     _suite("full-suite", *FULL_SUITE))
_add("ENV-02", _artifact("ci-entrypoint", "environments/ci.sh"), _suite("ci", *CI_SUITE))
_add("ENV-06", _artifact("env-profiles", "environments/ENVIRONMENTS.json",
                         contains=["isolated_test_tenant"]),
     _unit("tenancy-isolation", "test_adversarial.TestAdv05SensitiveDataLeakage"))
_DOCS = {
    "DOC-01": "docs/DOC-01-architecture.md", "DOC-02": "docs/DOC-02-dataflow-trust-boundaries.md",
    "DOC-03": "docs/DOC-03-connector-inventory.md", "DOC-04": "docs/DOC-04-permission-matrix.md",
    "DOC-05": "docs/DOC-05-threat-model.md", "DOC-06": "docs/DOC-06-model-tool-inventory.md",
    "DOC-07": "docs/DOC-07-provenance-schema.md", "DOC-08": "docs/DOC-08-run-state-schema.md",
    "DOC-09": "docs/DOC-09-human-approval-policy.md", "DOC-10": "docs/DOC-10-evaluation-plan.md",
    "DOC-11": "docs/DOC-11-incident-rollback-runbook.md",
    "DOC-12": "docs/DOC-12-known-limitations-non-goals.md",
}
for _task, _path in _DOCS.items():
    _add(_task, _artifact(f"{_task.lower()}-document", _path),
         _artifact(f"{_task.lower()}-index", "README.md", contains=[Path(_path).name]),
         _python(f"{_task.lower()}-generated", "artifact",
                 lambda p=_path: ((OVERLAY / p).stat().st_size > 500,
                                  f"{p} is {(OVERLAY / p).stat().st_size} bytes, generated from "
                                  "the live system by docs/generate_docs.py")))

# ---- Phase 12: production readiness and release gate --------------------------
_add("FLOW-12", _unit("rollback-e2e", "test_e2e.TestE2E06RollbackAbort"),
     _unit("terminal-states", "test_unit.TestWorkflow"),
     _artifact("rollback-runbook", "docs/DOC-11-incident-rollback-runbook.md",
               contains=["Rollback"]))


def checks_for(task_id: str) -> list[CheckResult]:
    """Run every check registered for ``task_id`` and return the results."""
    factories = _T.get(task_id)
    if factories is None:
        return [CheckResult(f"{task_id.lower()}-unmapped", "contract", True, "BLOCKED",
                            "no check is registered for this task; it cannot be evidenced")]
    return [factory() for factory in factories]


def mapped_tasks() -> set[str]:
    return set(_T)
