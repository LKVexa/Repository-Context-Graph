"""Proof-driven blocker validation (GO-01-01).

``control-plane/checks.py`` declares ``BLOCKERS: dict[str, str]`` and the module
docstring says what it is: *"they are the only way a task avoids having to pass
real checks."* A task named there skips every check and reports a stored string.

That was defensible while nothing could possibly pass -- there was no evidence to
check. It stops being defensible the moment evidence starts arriving, because
the dispatch has no way to notice.

The repair is **not** to delete the entries. A reference to a thing that is not
there has two explanations -- the reference is dead, or the thing was lost -- and
they call for opposite fixes. Deleting thirteen honest blocks would produce
thirteen silent passes. Each string becomes a validator of actual bound evidence
that keeps returning BLOCKED until its proof exists, and the classification
vocabulary is imported from ``rcg.promotion`` rather than redefined, so the
control plane and the promotion gate cannot form two different opinions about
what "stale" means.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

OVERLAY = Path(__file__).resolve().parent.parent.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from rcg.promotion import (CONDITION_STATES, PLANNING_ONLY_EVIDENCE, PROD_CONDITIONS,  # noqa: E402
                           QualificationSubject, Receipt, SATISFIED, classify_evidence)
from rcg.trustroot import TrustRoot                                                    # noqa: E402

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from successor.applicability import ApplicabilityRecord, evaluate_exclusion   # noqa: E402
else:
    from .applicability import ApplicabilityRecord, evaluate_exclusion            # noqa: E402

__all__ = ["ConditionContract", "CONTRACTS", "validate_condition", "validate_all",
           "PAYLOAD_SCHEMAS", "PAYLOAD_SCHEMA_VERSION", "validate_payload",
           "PLANNING_ONLY_EVIDENCE", "CONDITION_STATES"]


@dataclass(frozen=True)
class ConditionContract:
    """What a condition needs before it may stop being BLOCKED."""

    condition_id: str
    acceptance: str                     # verbatim from GATE_CLOSURE_MATRIX.md
    required_receipt_kinds: tuple[str, ...]
    requires_attestation: bool
    responsible_roles: str
    conditional: bool = False           # may a governed exclusion apply at all?

    def as_document(self) -> dict[str, Any]:
        return {
            "condition_id": self.condition_id, "acceptance": self.acceptance,
            "required_receipt_kinds": list(self.required_receipt_kinds),
            "requires_attestation": self.requires_attestation,
            "responsible_roles": self.responsible_roles, "conditional": self.conditional,
        }


_ENV_ACCEPTANCE = ("The environment can be recreated from versioned configuration and passes its "
                   "designated smoke/security/isolation checks.")
_PROD_ACCEPTANCE = ("Production promotion is blocked when the condition is false or evidence is "
                    "missing, and the gate passes only from recorded evidence.")

CONTRACTS: dict[str, ConditionContract] = {
    "XSEC-04": ConditionContract(
        "XSEC-04",
        ("Unauthorized or unsafe data flow is prevented or redacted before model/tool access and "
         "the behavior is covered by negative tests."),
        ("encryption_at_rest", "encryption_in_transit", "key_lifecycle",
         "deployed_host_proof", "security_acceptance"),
        True, "Security Engineering"),
    "ENV-03": ConditionContract(
        "ENV-03", _ENV_ACCEPTANCE,
        ("environment_recreation", "smoke_check", "security_check", "isolation_check"),
        True, "Platform / SRE"),
    "ENV-04": ConditionContract(
        "ENV-04", _ENV_ACCEPTANCE,
        ("environment_recreation", "smoke_check", "security_check", "isolation_check",
         "upstream_denial_proof", "tenant_authorization"),
        True, "Platform / SRE"),
    "ENV-05": ConditionContract(
        "ENV-05", _ENV_ACCEPTANCE,
        ("environment_recreation", "smoke_check", "security_check", "isolation_check",
         "privileged_separation_proof"),
        True, "Platform / SRE + Release Authority"),
    "XEVAL-06": ConditionContract(
        "XEVAL-06",
        ("The metric has a documented threshold and the benchmark produces repeatable results that "
         "gate release/pilot progression where required."),
        ("canary_observation", "pilot_disposition", "independent_pilot_review"),
        True, "QA / Pilot Owner / Security"),
    **{cid: ConditionContract(cid, _PROD_ACCEPTANCE,
                              ("substantive_proof", "task_approval", "release_approval"),
                              True, "Authorized Human Release Authority")
       for cid in PROD_CONDITIONS},
}


# --------------------------------------------------------------------------- #
# WG-08: substantive payload contracts, per receipt kind                        #
# --------------------------------------------------------------------------- #
#: What each receipt kind must actually *carry* to count. Every entry names the
#: fields, the field that identifies the raw artifact the payload was computed
#: from, and the field that names who produced it. A receipt whose payload is
#: missing any of these is INDETERMINATE for its condition, whatever its verdict
#: label says and however well its signature verifies. Version 1; a kind
#: without an entry here has no substantive contract yet and is refused as
#: such rather than waved through.
PAYLOAD_SCHEMA_VERSION = "rcg.receipt_payload/1"

_COMMON = ("producer", "produced_at", "environment_id", "raw_artifact_digest", "command")

PAYLOAD_SCHEMAS: dict[str, tuple[str, ...]] = {
    # ENV-03/04/05
    "environment_recreation": _COMMON + ("configuration_digest", "host_identity", "recreated_from"),
    "smoke_check":            _COMMON + ("checks_run", "checks_passed", "checks_failed", "log_digest"),
    "security_check":         _COMMON + ("scanner", "scanner_version", "findings_high", "findings_total", "report_digest"),
    "isolation_check":        _COMMON + ("egress_attempts", "egress_blocked", "privilege_escalation_attempts", "report_digest"),
    "upstream_denial_proof":  _COMMON + ("denied_operations", "attempted_operations", "report_digest"),
    "tenant_authorization":   _COMMON + ("tenant_id", "authorized_by", "authorization_record_digest"),
    "privileged_separation_proof": _COMMON + ("privileged_path", "unprivileged_path", "crossing_attempts", "crossings_blocked"),
    # XSEC-04
    "encryption_at_rest":     _COMMON + ("cipher", "key_reference", "stores_covered", "stores_total"),
    "encryption_in_transit":  _COMMON + ("protocol", "min_version", "endpoints_covered", "endpoints_total"),
    "key_lifecycle":          _COMMON + ("kms_binding", "rotation_period_days", "last_rotation_at", "revocation_tested"),
    "deployed_host_proof":    _COMMON + ("host_identity", "image_digest", "attested_boot"),
    "security_acceptance":    _COMMON + ("accepted_by_role", "residual_risks", "acceptance_record_digest"),
    # XEVAL-06
    "canary_observation":     _COMMON + ("window_id", "sample_count", "duration_seconds", "slo_results", "measurement_definition_digest"),
    "pilot_disposition":      _COMMON + ("pilot_id", "disposed_by_role", "findings_open", "findings_resolved"),
    "independent_pilot_review": _COMMON + ("reviewer_role", "reviewed_artifacts", "review_record_digest"),
    # PROD-01..08
    "substantive_proof":      _COMMON + ("claim", "method", "result_digest", "negative_cases_run", "negative_cases_refused"),
    "task_approval":          _COMMON + ("task_id", "approved_by_role", "approval_record_digest"),
    "release_approval":       _COMMON + ("approved_by_role", "desk_verdict_digest", "approval_record_digest"),
}

#: Numeric fields that must be non-negative integers, and pairs where the first
#: may not exceed the second. Cheap, but they catch the payloads that read well
#: and mean nothing: 0 checks run, 0 samples, more passed than run.
_NON_NEGATIVE_INT = ("checks_run", "checks_passed", "checks_failed", "findings_high", "findings_total",
                     "egress_attempts", "egress_blocked", "privilege_escalation_attempts",
                     "crossing_attempts", "crossings_blocked", "stores_covered", "stores_total",
                     "endpoints_covered", "endpoints_total", "sample_count", "duration_seconds",
                     "negative_cases_run", "negative_cases_refused", "findings_open", "findings_resolved",
                     "denied_operations", "attempted_operations")
_MUST_BE_POSITIVE = ("checks_run", "sample_count", "duration_seconds", "negative_cases_run",
                     "stores_total", "endpoints_total", "attempted_operations")
_LE_PAIRS = (("checks_passed", "checks_run"), ("checks_failed", "checks_run"),
             ("stores_covered", "stores_total"), ("endpoints_covered", "endpoints_total"),
             ("egress_blocked", "egress_attempts"), ("crossings_blocked", "crossing_attempts"),
             ("negative_cases_refused", "negative_cases_run"), ("findings_high", "findings_total"))
_MUST_EQUAL = (("egress_blocked", "egress_attempts"), ("crossings_blocked", "crossing_attempts"),
               ("negative_cases_refused", "negative_cases_run"), ("stores_covered", "stores_total"),
               ("endpoints_covered", "endpoints_total"))


def validate_payload(receipt: Receipt) -> str | None:
    """None when the payload is substantive for its kind; otherwise why not."""
    schema = PAYLOAD_SCHEMAS.get(receipt.kind)
    if schema is None:
        return (f"kind {receipt.kind!r} has no substantive payload contract in "
                f"{PAYLOAD_SCHEMA_VERSION}; an unspecified kind cannot close a condition")
    payload = receipt.payload
    if not payload:
        return (f"{receipt.kind!r} receipt carries no payload; a {receipt.verdict} label with "
                "nothing behind it is a label")
    missing = [f for f in schema if f not in payload or payload[f] in (None, "", [], {})]
    if missing:
        return f"{receipt.kind!r} payload is missing {missing}"
    dig = str(payload.get("raw_artifact_digest", ""))
    if not (dig.startswith("sha256:") and len(dig) == 71):
        return "raw_artifact_digest must be a full sha256: digest of the retained raw artifact"
    for f in _NON_NEGATIVE_INT:
        if f in payload and (not isinstance(payload[f], int) or isinstance(payload[f], bool) or payload[f] < 0):
            return f"{f} must be a non-negative integer"
    for f in _MUST_BE_POSITIVE:
        if f in payload and payload[f] == 0:
            return f"{f} is 0; a measurement over nothing measures nothing"
    for a, b in _LE_PAIRS:
        if a in payload and b in payload and payload[a] > payload[b]:
            return f"{a}={payload[a]} exceeds {b}={payload[b]}"
    for a, b in _MUST_EQUAL:
        if a in payload and b in payload and payload[a] != payload[b]:
            return f"{a}={payload[a]} but {b}={payload[b]}: not every attempt was contained"
    if receipt.kind == "smoke_check" and payload.get("checks_failed", 0) > 0 and receipt.verdict == "PASS":
        return "smoke_check reports failed checks and a PASS verdict; the label contradicts the payload"
    if receipt.kind == "security_check" and payload.get("findings_high", 0) > 0 and receipt.verdict == "PASS":
        return "security_check reports high findings and a PASS verdict; the label contradicts the payload"
    return None


def validate_condition(condition_id: str, *,
                       receipts: Sequence[Receipt] = (),
                       subject: QualificationSubject | None = None,
                       trust_root: TrustRoot | None = None,
                       audience: str = "rcg-production",
                       exclusion: ApplicabilityRecord | None = None,
                       now: datetime | None = None) -> dict[str, Any]:
    """Decide one condition from evidence. BLOCKED until its proof exists.

    Returns a record carrying the computed state, a specific reason, and the
    contract it was judged against. The reason is the point: seven different
    refusals have seven different remedies, and a generic "not satisfied" throws
    away the information the next person needs.
    """
    moment = now or datetime.now(timezone.utc)
    contract = CONTRACTS.get(condition_id)
    if contract is None:
        return {"condition_id": condition_id, "state": "INDETERMINATE",
                "reason": f"no evidence contract is registered for {condition_id}",
                "verdict": "BLOCKED"}

    if exclusion is not None:
        decision = evaluate_exclusion(exclusion, now=moment)
        if decision["admitted"]:
            return {"condition_id": condition_id, "state": "NOT_APPLICABLE",
                    "reason": decision["reason"], "verdict": "NOT_APPLICABLE",
                    "unmet_original_obligation": decision.get("unmet_original_obligation", False),
                    "contract": contract.as_document()}
        return {"condition_id": condition_id, "state": "ABSENT",
                "reason": f"the offered exclusion was refused: {decision['reason']}",
                "verdict": "BLOCKED", "contract": contract.as_document()}

    if subject is None:
        return {"condition_id": condition_id, "state": "ABSENT",
                "reason": ("no qualification subject is frozen, so no receipt can be bound to one; "
                           "freeze the subject (GO-09-09) before collecting evidence"),
                "verdict": "BLOCKED", "contract": contract.as_document()}

    classification = classify_evidence(condition_id, list(receipts), subject,
                                       root=trust_root, audience=audience, now=moment)
    state = classification["state"]

    if state == SATISFIED:
        # WG-08: the envelope verified; now the contents. Each receipt must carry
        # a substantive payload for its kind, or the label means nothing.
        for r in receipts:
            if r.condition_id != condition_id or r.subject_digest != subject.subject_digest:
                continue
            if r.kind in PLANNING_ONLY_EVIDENCE:
                continue
            problem = validate_payload(r)
            if problem is not None:
                return {"condition_id": condition_id, "state": "INDETERMINATE",
                        "reason": f"{r.selector}: {problem}", "verdict": "BLOCKED",
                        "contract": contract.as_document()}
        offered = {r.kind for r in receipts
                   if r.condition_id == condition_id
                   and r.subject_digest == subject.subject_digest}
        missing = [k for k in contract.required_receipt_kinds if k not in offered]
        if missing:
            return {"condition_id": condition_id, "state": "ABSENT",
                    "reason": (f"receipts verify, but the contract requires {missing} and none was "
                               "offered; a partial proof is not the proof"),
                    "verdict": "BLOCKED", "missing_kinds": missing,
                    "contract": contract.as_document()}
        return {"condition_id": condition_id, "state": SATISFIED,
                "reason": classification["reason"], "verdict": "PASS",
                "selectors": classification.get("selectors", []),
                "contract": contract.as_document()}

    return {"condition_id": condition_id, "state": state,
            "reason": classification["reason"], "verdict": "BLOCKED",
            "contract": contract.as_document(),
            **{k: v for k, v in classification.items() if k not in ("state", "reason")}}


def validate_all(*, receipts: Sequence[Receipt] = (),
                 subject: QualificationSubject | None = None,
                 trust_root: TrustRoot | None = None,
                 exclusions: Mapping[str, ApplicabilityRecord] | None = None,
                 now: datetime | None = None) -> dict[str, Any]:
    """Validate all thirteen. With today's evidence, all thirteen stay BLOCKED."""
    exclusions = dict(exclusions or {})
    rows = [validate_condition(cid, receipts=receipts, subject=subject, trust_root=trust_root,
                               exclusion=exclusions.get(cid), now=now)
            for cid in CONTRACTS]
    blocked = [r for r in rows if r["verdict"] == "BLOCKED"]
    return {
        "schema_id": "rcg.condition_validation/1",
        "conditions": rows,
        "blocked": [r["condition_id"] for r in blocked],
        "satisfied": [r["condition_id"] for r in rows if r["verdict"] == "PASS"],
        "not_applicable": [r["condition_id"] for r in rows if r["verdict"] == "NOT_APPLICABLE"],
        "verdict": "PASS" if not blocked else "BLOCKED",
        "boundary": ("a blocked condition is the gate working; these validators compute the "
                     "reason from evidence rather than reading a stored string"),
    }
