"""WG-22: requalify inherited implementation records; quarantine stale attempts.

``production-evidence/`` holds RESULT.json records written by earlier passes.
Each names the artifact digests it was evidence *about*. Files change; the
records do not. So a record whose artifacts have since been rewritten is a
statement about bytes that no longer exist, and its ``IMPLEMENTED_PENDING_REVIEW``
status is a claim nobody re-checked.

This module never edits or deletes a record -- evidence is append-only. It
writes a sibling ``REQUALIFICATION.json`` beside each RESULT.json with the
computed disposition, and a run-level ``QUARANTINE.json`` listing every record
that may not be cited as current. Dispositions:

* ``CURRENT``  -- every named artifact still has the digest the record names.
* ``STALE``    -- at least one artifact changed; the record describes history.
* ``ORPHANED`` -- at least one artifact is gone.
* ``UNBOUND``  -- the record names no artifacts, so it cannot be checked.

None of these is an acceptance. A CURRENT record is still
``independent_review: UNASSIGNED`` until a person reviews it.
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

OVERLAY = Path(__file__).resolve().parent.parent.parent

CURRENT, STALE, ORPHANED, UNBOUND = "CURRENT", "STALE", "ORPHANED", "UNBOUND"


def _digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def requalify_record(result_path: Path, *, overlay: Path = OVERLAY,
                     now: datetime | None = None) -> dict[str, Any]:
    moment = (now or datetime.now(timezone.utc)).isoformat().replace("+00:00", "Z")
    record = json.loads(result_path.read_text(encoding="utf-8"))
    named = record.get("artifact_digests") or {}
    checks = []
    disposition = CURRENT if named else UNBOUND
    for rel, recorded in sorted(named.items()):
        target = overlay / rel
        if not target.exists():
            checks.append({"artifact": rel, "recorded": recorded, "current": None, "state": "MISSING"})
            disposition = ORPHANED
            continue
        current = _digest(target)
        same = current == recorded
        checks.append({"artifact": rel, "recorded": recorded, "current": current,
                       "state": "UNCHANGED" if same else "CHANGED"})
        if not same and disposition == CURRENT:
            disposition = STALE
    return {
        "schema_id": "rcg.requalification/1",
        "task_id": record.get("task_id"),
        "run_id": record.get("run_id"),
        "attempt_id": record.get("attempt_id"),
        "result_path": str(result_path.relative_to(overlay)),
        "result_digest": _digest(result_path),
        "inherited_status": record.get("status"),
        "disposition": disposition,
        "citable_as_current": disposition == CURRENT,
        "artifacts": checks,
        "requalified_at": moment,
        "boundary": ("a disposition of CURRENT means the bytes the record describes still exist; "
                     "it is not a review and not an acceptance. independent_review stays "
                     f"{(record.get('independent_review') or {}).get('disposition', 'UNASSIGNED')!r}."),
    }


def requalify_all(*, evidence_root: Path | None = None, overlay: Path = OVERLAY,
                  write: bool = True, now: datetime | None = None) -> dict[str, Any]:
    root = evidence_root or (overlay / "production-evidence")
    moment = now or datetime.now(timezone.utc)
    rows = []
    for result in sorted(root.rglob("RESULT.json")):
        row = requalify_record(result, overlay=overlay, now=moment)
        rows.append(row)
        if write:
            (result.parent / "REQUALIFICATION.json").write_text(
                json.dumps(row, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    counts: dict[str, int] = {}
    for r in rows:
        counts[r["disposition"]] = counts.get(r["disposition"], 0) + 1
    quarantine = {
        "schema_id": "rcg.quarantine/1",
        "generated_at": moment.isoformat().replace("+00:00", "Z"),
        "records": len(rows),
        "by_disposition": dict(sorted(counts.items())),
        "quarantined": [{"task_id": r["task_id"], "run_id": r["run_id"], "disposition": r["disposition"],
                         "changed": [a["artifact"] for a in r["artifacts"] if a["state"] != "UNCHANGED"]}
                        for r in rows if not r["citable_as_current"]],
        "boundary": ("quarantined records are not deleted and not edited; they are history. "
                     "Nothing here accepts a record, and nothing in the release path reads "
                     "RESULT.json files as receipts."),
    }
    if write:
        (root / "QUARANTINE.json").write_text(json.dumps(quarantine, indent=2, sort_keys=True) + "\n",
                                              encoding="utf-8")
    return quarantine


def main(argv=None) -> int:
    q = requalify_all()
    print(f"records: {q['records']}  {q['by_disposition']}")
    for row in q["quarantined"]:
        print(f"  {row['disposition']:8} {row['task_id']:9} {', '.join(row['changed'])[:90]}")
    return 0 if not q["quarantined"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
