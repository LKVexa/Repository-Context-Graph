"""Check results bound to retrievable, re-hashed evidence (GO-01-09).

The failure this prevents is a check that proves itself. A result whose only
evidence is the name of the check that produced it is circular, and a system
full of them looks thoroughly evidenced while proving nothing.

Every result therefore carries evidence objects with digests and retrieval
paths, and every referenced artifact is re-hashed on read by
``rcg.evidence.resolve_artifact`` -- a stored digest is a claim, not a check.
"""
from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

OVERLAY = Path(__file__).resolve().parent.parent.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from rcg.canonical import sha256_of                                    # noqa: E402
from rcg.evidence import UnsafeReference, resolve_artifact             # noqa: E402

__all__ = ["EvidenceObject", "BoundResult", "SelfReferential", "bind_result"]


class SelfReferential(ValueError):
    """The check offered itself as its own proof."""


@dataclass(frozen=True)
class EvidenceObject:
    """One retrievable artifact, addressed by digest."""

    kind: str
    reference: str            # sha256:<64 hex>
    relative_path: str
    producing_command: str = ""
    exit_code: int | None = None

    def resolve(self, *, evidence_root: Path) -> bytes:
        return resolve_artifact(self.reference, root=evidence_root,
                                relative_path=self.relative_path)

    def as_document(self) -> dict[str, Any]:
        return {"kind": self.kind, "reference": self.reference,
                "relative_path": self.relative_path,
                "producing_command": self.producing_command, "exit_code": self.exit_code}


@dataclass
class BoundResult:
    check_id: str
    verdict: str
    detail: str
    evidence: list[EvidenceObject] = field(default_factory=list)
    verified: list[str] = field(default_factory=list)
    at: str = ""

    def as_document(self) -> dict[str, Any]:
        return {"check_id": self.check_id, "verdict": self.verdict, "detail": self.detail,
                "evidence": [e.as_document() for e in self.evidence],
                "verified_references": list(self.verified), "at": self.at}


def bind_result(check_id: str, verdict: str, detail: str, *,
                evidence: Sequence[EvidenceObject], evidence_root: Path) -> BoundResult:
    """Verify every referenced artifact, or downgrade the result to INDETERMINATE.

    A result with no evidence, or whose evidence is only the check's own
    identifier, is ``INDETERMINATE`` -- never ``PASS``. That is the whole point:
    the absence of proof has to be visible in the verdict, not only in a field
    nobody reads.
    """
    at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    if not evidence:
        return BoundResult(check_id, "INDETERMINATE",
                           f"{detail} [no evidence object was offered; a check is not its own proof]",
                           [], [], at)
    only_self = all(e.kind == "check_name" or e.relative_path.strip() in ("", check_id)
                    for e in evidence)
    if only_self:
        return BoundResult(check_id, "INDETERMINATE",
                           f"{detail} [the only evidence offered is the check's own identifier]",
                           list(evidence), [], at)
    verified: list[str] = []
    for obj in evidence:
        try:
            obj.resolve(evidence_root=evidence_root)
        except UnsafeReference as exc:
            return BoundResult(check_id, "INDETERMINATE",
                               f"{detail} [evidence {obj.relative_path!r} did not verify: {exc}]",
                               list(evidence), verified, at)
        verified.append(obj.reference)
    return BoundResult(check_id, verdict, detail, list(evidence), verified, at)
