"""Task-ID-bound approvals in phase validation (GO-01-04).

``control-plane/package/tools/validate_runtime.py`` walks each task's evidence
inside ``validate_phase`` and calls
``validate_task(..., approval_files=None, enforce_approval_files=False, quiet=True)``.
The signature supports approvals; the phase walk declines to supply them. So a
COMPLETE PROD task that requires an approval is validated as though it required
none.

A two-line defect with a large blast radius: it is the difference between "the
phase chain checked the approvals" and "the phase chain checked that
approval-shaped fields were present somewhere".

The vendored validator is immutable, so this module does not edit it. It
composes with it: the vendored ``validate_phase`` still runs and still does
everything it did, and then :func:`enforce_phase_approvals` re-walks the same
task evidence with a **task-ID-bound** approval collection and
``enforce_approval_files=True``. An approval for task A cannot satisfy task B,
because the collection is keyed by task id and each candidate approval is
re-validated against the task it is offered for.
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

OVERLAY = Path(__file__).resolve().parent.parent.parent
PACKAGE = OVERLAY / "control-plane" / "package"
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from rcg.evidence import EvidenceError, loads_strict          # noqa: E402

__all__ = ["ApprovalBindingError", "build_collection", "enforce_phase_approvals",
           "RELEASE_KIND", "TASK_KIND"]

TASK_KIND = "TASK"
RELEASE_KIND = "RELEASE"


class ApprovalBindingError(RuntimeError):
    """An approval is not bound to the task it was offered for."""


def _load_validator():
    """Import the vendored validator without editing, copying or touching it.

    ``sys.dont_write_bytecode`` is not a nicety here. Importing a module writes
    ``__pycache__`` beside it by default, and the vendored package's manifest
    covers *every regular file*: a stray ``.pyc`` makes ``verify_package.py``
    fail with "manifest must cover every regular package file except itself".
    Reading an immutable package must leave no trace in it.
    """
    import importlib.util
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec = importlib.util.spec_from_file_location(
            "rcg_vendored_validate_runtime", PACKAGE / "tools" / "validate_runtime.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module
    finally:
        sys.dont_write_bytecode = previous


def build_collection(approval_paths: Iterable[str | Path]) -> dict[str, list[Path]]:
    """Group approval documents by the task id each one names.

    An approval that names no task, or names a task other than its own, never
    reaches another task's validation: the collection is the binding.
    """
    collection: dict[str, list[Path]] = defaultdict(list)
    for raw in approval_paths:
        path = Path(raw)
        try:
            document = loads_strict(path.read_bytes())
        except (OSError, EvidenceError) as exc:
            raise ApprovalBindingError(f"approval {path} is unreadable or ambiguous: {exc}") from None
        subject = document.get("subject") or {}
        task_id = document.get("task_id") or subject.get("task_id")
        if not task_id:
            raise ApprovalBindingError(
                f"approval {path} names no task id; an unbound approval cannot be enforced")
        collection[str(task_id)].append(path)
    return dict(collection)


def enforce_phase_approvals(phase_document: Mapping[str, Any], *,
                            root: str | Path = PACKAGE,
                            evidence_root: str | Path,
                            authority_file: str | Path,
                            approvals_by_task: Mapping[str, Sequence[str | Path]],
                            now: str | None = None) -> dict[str, Any]:
    """Re-walk a phase's task evidence with approvals actually supplied.

    Returns a record naming every task whose approval requirement was enforced
    and every one that failed it. A phase containing a COMPLETE PROD task with no
    matching approval fails here, where the shipped code passed it.
    """
    VR = _load_validator()
    root = Path(root)
    evidence_root = Path(evidence_root)
    enforced: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []

    digests = phase_document.get("task_evidence_digests") or {}
    attempts = phase_document.get("task_attempt_ids") or {}
    run_id = phase_document.get("run_id")

    for task_id in phase_document.get("expected_task_ids", []):
        attempt = attempts.get(task_id)
        if attempt is None:
            continue
        try:
            amap, _ = VR.app(str(root))
            relative = amap[task_id]
            evidence_path = VR.evidence_path(str(evidence_root), run_id, relative, attempt)
        except Exception as exc:                                    # pragma: no cover - shape guard
            failures.append({"task_id": task_id, "reason": f"evidence path unresolved: {exc}"})
            continue
        if not Path(evidence_path).is_file():
            failures.append({"task_id": task_id, "reason": "task evidence file missing"})
            continue
        evidence, _ = VR.strict_load(evidence_path)
        requires = evidence.get("status") == "COMPLETE" and task_id.startswith("PROD-")
        supplied = [str(p) for p in approvals_by_task.get(task_id, ())]
        if not requires and not supplied:
            continue
        try:
            # The whole repair: the per-task collection, and enforcement on.
            VR.validate_task(evidence, str(root), authority_file=str(authority_file),
                             now=now, approval_files=supplied,
                             enforce_approval_files=True, quiet=True)
            enforced.append({"task_id": task_id, "approvals": supplied,
                             "required": requires, "result": "PASS"})
        except SystemExit as refusal:
            failures.append({"task_id": task_id, "approvals": supplied,
                             "required": requires, "reason": str(refusal)})

    return {
        "schema_id": "rcg.phase_approval_enforcement/1",
        "phase": phase_document.get("phase"),
        "run_id": run_id,
        "enforced": enforced,
        "failures": failures,
        "verdict": "PASS" if not failures else "FAIL",
        "boundary": ("TASK approvals only; the Phase-12 RELEASE approval is a separate kind on a "
                     "separate subject and is never satisfied by a task approval"),
    }
