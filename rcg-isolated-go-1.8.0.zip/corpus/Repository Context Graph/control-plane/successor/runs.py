"""Append-only, restart-safe run and attempt identity (GO-01-07).

``run_control_plane.py`` called ``shutil.rmtree(self.run_dir)`` on every
execution and hard-coded ``attempt = "A0001"``. Together those meant a re-run
destroyed the previous run's evidence and reused its identity: an interrupted
run could not be resumed, and a superseded attempt could not be distinguished
from the attempt that replaced it, because they had the same name and only one
of them still existed.

For a system whose whole value is auditable evidence, deleting the audit trail
on retry is the defect that undermines the others.

The design is taken from the Scoped PR Builder's ``archive_adapter`` -- a
hash-chained, append-only ledger whose chaining, genesis link and verification
walk transfer unchanged -- and its most important property is taken literally:
**there is no update method and no delete method.** Retention and deletion are a
separate governed concern (GO-02-10), never a side effect of pressing retry.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

OVERLAY = Path(__file__).resolve().parent.parent.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from rcg.canonical import canonical_bytes, sha256_of      # noqa: E402
from rcg.evidence import EvidenceError, loads_strict      # noqa: E402

__all__ = ["RunLedgerError", "ChainBroken", "RunLedger", "allocate_run_id",
           "next_attempt_id", "GENESIS"]

GENESIS = "sha256:" + "0" * 64


class RunLedgerError(RuntimeError):
    """The ledger refused an operation."""


class ChainBroken(RunLedgerError):
    """The hash chain does not verify."""


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def allocate_run_id(root: Path, *, prefix: str = "RCG") -> str:
    """A run id that has never been used under ``root``.

    Uniqueness is by construction (timestamp plus entropy) and then verified
    against the filesystem, because "probably unique" is not the property an
    append-only store needs.
    """
    root = Path(root)
    for _ in range(64):
        candidate = f"{prefix}-{datetime.now(timezone.utc):%Y%m%dT%H%M%S}-{os.urandom(4).hex()}"
        if not (root / candidate).exists():
            return candidate
    raise RunLedgerError("could not allocate an unused run id")   # pragma: no cover


def next_attempt_id(ledger: "RunLedger", task_id: str) -> str:
    """Monotonic per task. ``A0001`` is the first attempt, not the only one."""
    highest = 0
    for row in ledger.rows():
        if row.get("task_id") == task_id and isinstance(row.get("attempt_id"), str):
            try:
                highest = max(highest, int(row["attempt_id"].lstrip("A")))
            except ValueError:                                     # pragma: no cover
                continue
    return f"A{highest + 1:04d}"


@dataclass
class RunLedger:
    """A hash-chained, append-only run-state ledger. No update, no delete.

    The absence of those methods is the design, not an omission: a caller that
    cannot rewrite history does not have to be trusted not to.
    """

    path: Path

    def __post_init__(self) -> None:
        self.path = Path(self.path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ read --
    def rows(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        out: list[dict[str, Any]] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                out.append(loads_strict(line))
            except EvidenceError as exc:
                raise ChainBroken(f"ledger row is not an unambiguous document: {exc}") from None
        return out

    def head(self) -> str:
        rows = self.rows()
        return rows[-1]["row_digest"] if rows else GENESIS

    def verify(self) -> tuple[bool, str]:
        """Walk the chain. Returns ``(ok, reason)`` and never raises on a break."""
        previous = GENESIS
        try:
            rows = self.rows()
        except ChainBroken as exc:
            return False, str(exc)
        for index, row in enumerate(rows):
            if row.get("previous_digest") != previous:
                return False, (f"row {index} ({row.get('event', '?')}) claims previous "
                               f"{row.get('previous_digest')!r}, chain is at {previous!r}")
            body = {k: v for k, v in row.items() if k != "row_digest"}
            expected = sha256_of(canonical_bytes(body))
            if row.get("row_digest") != expected:
                return False, f"row {index} digest mismatch: content was altered after append"
            previous = row["row_digest"]
        return True, f"chain verifies over {len(rows)} row(s)"

    # ----------------------------------------------------------------- write --
    def append(self, event: str, **fields: Any) -> dict[str, Any]:
        """Append one row. This is the only mutation this class offers."""
        if "row_digest" in fields or "previous_digest" in fields:
            raise RunLedgerError("chain fields are computed, never supplied")
        body = {"event": event, "at": _now(), "previous_digest": self.head(), **fields}
        row = {**body, "row_digest": sha256_of(canonical_bytes(body))}
        line = json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n"
        # Append durably: O_APPEND is atomic for a single write under the page
        # size on POSIX, and the fsync makes an interrupted run resumable rather
        # than truncated.
        with open(self.path, "a", encoding="utf-8") as handle:
            handle.write(line)
            handle.flush()
            os.fsync(handle.fileno())
        return row

    def supersede(self, *, task_id: str, superseded_attempt: str, new_attempt: str,
                  reason: str) -> dict[str, Any]:
        """Record that one attempt replaces another. Neither row is removed."""
        return self.append("attempt.superseded", task_id=task_id,
                           superseded_attempt=superseded_attempt, attempt_id=new_attempt,
                           reason=reason)

    def resume_point(self, run_id: str) -> dict[str, Any]:
        """What an interrupted run should do next, computed from the ledger alone."""
        rows = [r for r in self.rows() if r.get("run_id") == run_id]
        completed = {r["task_id"] for r in rows
                     if r.get("event") == "task.finished" and r.get("task_id")}
        started = {r["task_id"] for r in rows
                   if r.get("event") == "task.started" and r.get("task_id")}
        return {
            "run_id": run_id,
            "rows": len(rows),
            "completed_tasks": sorted(completed),
            "interrupted_tasks": sorted(started - completed),
            "resumable": bool(rows),
        }
