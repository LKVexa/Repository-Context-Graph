#!/usr/bin/env python3
"""Self-tests for the control-plane successor (GO-01-13).

A self-test that still passes with its control removed is not a self-test. Each
check here asserts a *refusal*, and the accompanying negative asserts that the
refusal is what produces the result -- so removing the control makes the test
fail rather than quietly still pass.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONTROL_PLANE = HERE.parent
OVERLAY = CONTROL_PLANE.parent
for candidate in (str(OVERLAY), str(CONTROL_PLANE)):
    if candidate not in sys.path:
        sys.path.insert(0, candidate)

from successor import SUPERSEDES, VERSION
from successor.applicability import ApplicabilityRecord, MANDATORY_ORIGINAL, evaluate_exclusion
from successor.evidence_validators import CONTRACTS, validate_all
from successor.qualify import EXIT_BLOCKED, audit, release
from successor.runs import RunLedger
from rcg.promotion import PLANNING_ONLY_EVIDENCE, Receipt, freeze_subject

CHECKS: list[tuple[str, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    CHECKS.append((name, "PASS" if condition else "FAIL"))
    print(f"  {'PASS' if condition else 'FAIL'}  {name}" + (f"  -- {detail}" if detail else ""))


def write_manifest() -> int:
    """Reseal the successor manifest. An explicit authoring act, never automatic.

    Resealing on every run would make the manifest incapable of catching the
    thing it exists to catch -- a file changed without the manifest being
    updated -- which is exactly what it caught during this package's own build.
    """
    import hashlib
    files = sorted(p for p in HERE.glob("*.py"))
    manifest = {
        "package": "rcg-control-plane-successor",
        "version": VERSION,
        "supersedes": SUPERSEDES,
        "supersedes_manifest": "control-plane/package/MANIFEST_v1.3.0.json",
        "note": ("The vendored v1.3.0 package is immutable and stays byte-identical; this successor "
                 "carries the validator and runner changes R01 requires, with its own manifest and "
                 "self-tests. The historical run RCG-885dcf0010579251 remains interpretable "
                 "against v1.3.0."),
        "files": [{"path": p.name, "bytes": p.stat().st_size,
                   "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],
    }
    (HERE / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"resealed MANIFEST.json over {len(files)} files")
    return 0


def main() -> int:
    if "--write-manifest" in sys.argv[1:]:
        return write_manifest()
    print(f"control-plane successor v{VERSION} (supersedes v{SUPERSEDES}) self-test")
    now = datetime.now(timezone.utc)
    subject = freeze_subject(
        candidate_digest="sha256:" + "4b" * 32, runtime_version=VERSION,
        configuration_digest="sha256:" + "11" * 32, data_binding="self-test",
        observation_authority_ref="SELF-TEST",
        observation_authority_expires_at=now + timedelta(days=1), now=now)

    check("thirteen conditions have evidence contracts", len(CONTRACTS) == 13,
          f"{len(CONTRACTS)} contracts")

    report = validate_all(subject=subject)
    check("no evidence blocks every condition", len(report["blocked"]) == 13,
          f"{len(report['blocked'])} blocked")
    check("every refusal names a reason",
          all(r["reason"] for r in report["conditions"]))

    planning = [Receipt("R", "PROD-01", kind, subject.subject_digest, "PASS", now)
                for kind in sorted(PLANNING_ONLY_EVIDENCE)]
    states = {validate_all(receipts=[r], subject=subject)["conditions"][5]["state"]
              for r in planning}
    check("planning-only evidence never satisfies a condition",
          states == {"PLANNING_ONLY"}, str(states))

    stale = [Receipt("R1", "ENV-03", "smoke_check", "sha256:" + "00" * 32, "PASS", now)]
    row = next(r for r in validate_all(receipts=stale, subject=subject)["conditions"]
               if r["condition_id"] == "ENV-03")
    check("a receipt bound to another subject reads STALE", row["state"] == "STALE", row["state"])

    excluded = ApplicabilityRecord(
        subject_id="ENV-05", profile_dimension="modify_enabled", profile_value=False,
        rationale="x", disabled_path_evidence={"t": "t"}, approver_identity="a",
        owner_identity="b", approval_reference="AP", expires_at=now + timedelta(days=1),
        release_scope="FULL_ORIGINAL_SCOPE")
    check("a mandatory original requirement is not excludable under full scope",
          not evaluate_exclusion(excluded, now=now)["admitted"])
    check("the mandatory set covers all thirteen",
          MANDATORY_ORIGINAL >= {"ENV-03", "ENV-04", "ENV-05", "XSEC-04", "XEVAL-06"})

    decision = release(subject=subject)
    check("release fails closed with no evidence", decision["decision"] == "NO_GO")
    check("release reports a non-zero exit code", decision["exit_code"] == EXIT_BLOCKED,
          str(decision["exit_code"]))
    check("schema validity and gate verdict are separate",
          decision["schema_valid"] is True and decision["gate_verdict"] == "NO_GO")

    summary = audit(subject=subject)
    check("audit cannot promote", summary["promotes"] is False)

    import tempfile
    ledger = RunLedger(Path(tempfile.mkdtemp()) / "L.jsonl")
    ledger.append("a", run_id="R")
    ledger.append("b", run_id="R")
    check("the run ledger chain verifies", ledger.verify()[0])
    check("the run ledger exposes no delete or update",
          not any(hasattr(ledger, m) for m in ("delete", "update", "truncate")))

    manifest = HERE / "MANIFEST.json"
    if manifest.is_file():
        import hashlib
        declared = json.loads(manifest.read_text(encoding="utf-8"))
        bad = [e["path"] for e in declared["files"]
               if not (HERE / e["path"]).is_file()
               or hashlib.sha256((HERE / e["path"]).read_bytes()).hexdigest() != e["sha256"]]
        check("successor manifest matches its files", not bad, str(bad))

    failed = [name for name, result in CHECKS if result == "FAIL"]
    print()
    print(f"{len(CHECKS) - len(failed)}/{len(CHECKS)} self-tests passed")
    if failed:
        print("FAILED: " + ", ".join(failed))
    print("This self-test qualifies the successor's refusals. It is not a production credential.")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
