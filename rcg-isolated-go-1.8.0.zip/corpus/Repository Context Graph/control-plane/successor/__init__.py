"""Versioned control-plane successor to the vendored v1.3.0 package (GO-01-13).

The vendored package at ``control-plane/package/`` is immutable: its manifest
covers 261 files, its digest is bound into the historical run, and the plan's
change-control rule is that it is never hot-edited. Everything R01 asks for
changes the validator and runner surface, so it lands here instead, versioned,
with its own manifest and self-tests, declaring what it supersedes.

What this package adds over v1.3.0:

* ``evidence_validators`` -- proof-driven checks in place of the static
  ``BLOCKERS`` strings (GO-01-01).
* ``applicability`` -- authenticated, expiring, profile-bound non-applicability
  records, the only route to ``NOT_APPLICABLE`` (GO-01-06).
* ``runs`` -- append-only, restart-safe run and attempt identity, with no update
  or delete method at all (GO-01-07).
* ``results`` -- every check result bound to retrievable, re-hashed evidence,
  and self-referential proof refused (GO-01-09).
* ``qualify`` -- audit mode and release mode as separate operations, the
  prepare/finalize split, and an exit status that reflects the gate
  (GO-01-03, GO-01-08, GO-01-10).
* ``approvals`` -- task-ID-bound approval collection for phase validation, the
  half ``validate_runtime.py`` declined to supply (GO-01-04).

The v1.3.0 package stays where it is and stays readable: the historical run
``RCG-885dcf0010579251`` was produced by it and is interpreted against it.
"""
from __future__ import annotations

VERSION = "1.4.0"
SUPERSEDES = "1.3.0"

__all__ = ["VERSION", "SUPERSEDES"]
