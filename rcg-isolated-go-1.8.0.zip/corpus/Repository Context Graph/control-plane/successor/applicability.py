"""Governed non-applicability (GO-01-06).

``NOT_APPLICABLE`` is the most dangerous state in a compliance system: it looks
like a decision and behaves like a pass. Audit finding A09 was exactly this --
the previous plan allowed a profile-only ENV-05 exclusion to stand against an
original requirement the source never made conditional.

So the state is unreachable except through a record that carries: the profile
dimension that justifies it, a rationale, *disabled-path evidence* (a
demonstration that the path is genuinely inert, not merely unused), an approver
who is not the owner, an approval reference, and an expiry. The expiry matters
more than it looks: an exclusion granted for a profile that later changes must
lapse rather than persist quietly, so validity is computed at time of use like
every other authority in this system.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

OVERLAY = Path(__file__).resolve().parent.parent.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from rcg.evidence import EvidenceError, loads_strict          # noqa: E402
from rcg.promotion import PROD_CONDITIONS                     # noqa: E402

__all__ = ["ApplicabilityError", "MANDATORY_ORIGINAL", "ApplicabilityRecord",
           "load_record", "evaluate_exclusion"]


class ApplicabilityError(ValueError):
    """The exclusion is not admissible."""


#: The original requirements the source makes mandatory. None of these is
#: excludable for a FULL_ORIGINAL_SCOPE claim; the plan sets
#: ``original_mandatory_exclusions_allowed: false`` and means it.
MANDATORY_ORIGINAL: frozenset[str] = frozenset(
    {"ENV-03", "ENV-04", "ENV-05", "XSEC-04", "XEVAL-06"} | set(PROD_CONDITIONS)
)

#: Profile dimensions that can justify an exclusion at all.
PROFILE_DIMENSIONS = ("model_enabled", "external_relations_claimed", "modify_enabled",
                      "hosted_service_claimed", "native_windows_claimed", "drafts_claimed")


def _parse(value: Any, field: str) -> datetime:
    if not isinstance(value, str):
        raise ApplicabilityError(f"{field} must be an RFC-3339 string")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise ApplicabilityError(f"{field} is not a valid timestamp: {value!r}") from None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


@dataclass(frozen=True)
class ApplicabilityRecord:
    subject_id: str                     # the task or requirement being excluded
    profile_dimension: str
    profile_value: bool
    rationale: str
    disabled_path_evidence: Mapping[str, Any]
    approver_identity: str
    owner_identity: str
    approval_reference: str
    expires_at: datetime
    release_scope: str                  # FULL_ORIGINAL_SCOPE | SCOPED_SUCCESSOR
    amended_source_reference: str = ""
    requirement_mapping_reference: str = ""

    def as_document(self) -> dict[str, Any]:
        return {
            "subject_id": self.subject_id, "profile_dimension": self.profile_dimension,
            "profile_value": self.profile_value, "rationale": self.rationale,
            "disabled_path_evidence": dict(self.disabled_path_evidence),
            "approver_identity": self.approver_identity, "owner_identity": self.owner_identity,
            "approval_reference": self.approval_reference,
            "expires_at": self.expires_at.isoformat().replace("+00:00", "Z"),
            "release_scope": self.release_scope,
            "amended_source_reference": self.amended_source_reference,
            "requirement_mapping_reference": self.requirement_mapping_reference,
        }


def load_record(document: Mapping[str, Any] | bytes | str) -> ApplicabilityRecord:
    """Parse strictly. A record with two readings is not a record."""
    if isinstance(document, (bytes, str)):
        try:
            document = loads_strict(document)
        except EvidenceError as exc:
            raise ApplicabilityError(f"applicability record is not unambiguous: {exc}") from None
    required = ("subject_id", "profile_dimension", "profile_value", "rationale",
                "disabled_path_evidence", "approver_identity", "owner_identity",
                "approval_reference", "expires_at", "release_scope")
    missing = [k for k in required if k not in document]
    if missing:
        raise ApplicabilityError(f"applicability record is missing {missing}")
    if document["profile_dimension"] not in PROFILE_DIMENSIONS:
        raise ApplicabilityError(
            f"{document['profile_dimension']!r} is not a profile dimension; an exclusion must be "
            f"justified by one of {PROFILE_DIMENSIONS}")
    if not isinstance(document["profile_value"], bool):
        raise ApplicabilityError("profile_value must be an exact boolean")
    return ApplicabilityRecord(
        subject_id=str(document["subject_id"]),
        profile_dimension=str(document["profile_dimension"]),
        profile_value=bool(document["profile_value"]),
        rationale=str(document["rationale"]),
        disabled_path_evidence=dict(document["disabled_path_evidence"]),
        approver_identity=str(document["approver_identity"]),
        owner_identity=str(document["owner_identity"]),
        approval_reference=str(document["approval_reference"]),
        expires_at=_parse(document["expires_at"], "expires_at"),
        release_scope=str(document["release_scope"]),
        amended_source_reference=str(document.get("amended_source_reference", "")),
        requirement_mapping_reference=str(document.get("requirement_mapping_reference", "")),
    )


def evaluate_exclusion(record: ApplicabilityRecord, *, now: datetime | None = None) -> dict[str, Any]:
    """Accept or refuse one exclusion, naming the reason either way."""
    moment = now or datetime.now(timezone.utc)

    if record.subject_id in MANDATORY_ORIGINAL and record.release_scope == "FULL_ORIGINAL_SCOPE":
        return {"admitted": False, "state": "REFUSED",
                "reason": (f"{record.subject_id} is a mandatory original requirement and is not "
                           "excludable for a FULL_ORIGINAL_SCOPE claim; a narrower product needs a "
                           "separately audited SCOPED_SUCCESSOR, and the original-scope report "
                           "still carries this obligation as unmet")}
    if record.subject_id in MANDATORY_ORIGINAL and record.release_scope == "SCOPED_SUCCESSOR":
        if not record.amended_source_reference or not record.requirement_mapping_reference:
            return {"admitted": False, "state": "REFUSED",
                    "reason": ("a SCOPED_SUCCESSOR exclusion of a mandatory original requirement "
                               "requires both an amended audited source and an explicit "
                               "old-to-new requirement mapping; relabelling is not amending")}
    if not record.disabled_path_evidence:
        return {"admitted": False, "state": "REFUSED",
                "reason": ("no disabled-path evidence: an exclusion claims a path is off, and "
                           "something has to show that it is off")}
    if record.approver_identity == record.owner_identity:
        return {"admitted": False, "state": "REFUSED",
                "reason": ("the approver is the owner; an exclusion approved by the person it "
                           "relieves is not an independent decision")}
    if moment >= record.expires_at:
        return {"admitted": False, "state": "EXPIRED",
                "reason": (f"the exclusion expired at {record.expires_at.isoformat()}; its subject "
                           "is applicable again")}
    return {"admitted": True, "state": "NOT_APPLICABLE",
            "reason": (f"excluded under {record.profile_dimension}={record.profile_value} "
                       f"by {record.approver_identity}, expiring "
                       f"{record.expires_at.isoformat()}"),
            "unmet_original_obligation": record.subject_id in MANDATORY_ORIGINAL}
