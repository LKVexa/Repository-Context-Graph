"""``python -m successor <command>`` -- the successor's command surface."""
from __future__ import annotations

import sys

from .qualify import main

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
