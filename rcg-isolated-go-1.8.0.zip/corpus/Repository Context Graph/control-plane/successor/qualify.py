"""Readiness, promotion, and the exit status that reflects them
(GO-01-03, GO-01-08, GO-01-10).

Three defects, one command surface.

**The exit status lied.** ``run_control_plane.py`` prints a blocked summary and
returns ``0``. Everything that consumes an exit status -- which is to say every
CI system ever built -- read a blocked promotion as success. The information was
on the screen and absent from the only channel that is machine-checked.

**Readiness and promotion shared a path.** There was no way to hand a human the
exact bytes they were approving and no way to take their decision back in, so
approval was something the tool inferred rather than something it ingested.

**Audit and release asked the same question.** *What is wrong with this release?*
wants every finding, continuing past failures. *May this release proceed?* wants
a fail-closed verdict at the first unmet gate. Running the second as though it
were the first is how a schema-valid phase gets read as a passing phase.

Four commands, four distinct meanings, and exit codes that a machine can act on.
"""
from __future__ import annotations

import argparse
import os
import json
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

OVERLAY = Path(__file__).resolve().parent.parent.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from rcg.canonical import canonical_bytes, sha256_of                  # noqa: E402
from rcg.promotion import (PROD_CONDITIONS, QualificationSubject,     # noqa: E402
                           Receipt, freeze_subject)

if __package__ in (None, ""):   # allow `python successor/qualify.py` as well as `-m`
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from successor.evidence_validators import validate_all             # noqa: E402
else:
    from .evidence_validators import validate_all                      # noqa: E402

__all__ = ["EXIT_OK", "EXIT_BLOCKED", "EXIT_FAILED", "EXIT_UNTRUSTED", "EXIT_INDETERMINATE",
           "audit", "release", "prepare_candidate", "finalize_with_approvals", "main"]

#: Distinct codes per refusal class. A caller that only knows "non-zero" still
#: fails safely; a caller that reads the code knows which remedy applies.
EXIT_OK = 0
EXIT_BLOCKED = 1            # evidence absent or a condition not satisfied
EXIT_FAILED = 2             # a substantive check failed
EXIT_UNTRUSTED = 3          # evidence exists but its attestation does not verify
EXIT_INDETERMINATE = 4      # the verdict could not be computed at all

_REPORTING_BANNER = (
    "REPORTING ONLY -- this output is a summary, not a gate. It cannot authorize promotion, and "
    "its exit status is non-zero whenever the underlying gate is not GO."
)


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _exit_for(rows: Sequence[Mapping[str, Any]]) -> int:
    """Map the worst state present onto an exit code. Fail closed on unknowns."""
    states = {r["state"] for r in rows}
    if "INDETERMINATE" in states:
        return EXIT_INDETERMINATE
    if "UNTRUSTED" in states or "UNATTESTED" in states:
        return EXIT_UNTRUSTED
    if "FAILED" in states or "CONFLICTING" in states:
        return EXIT_FAILED
    if {"ABSENT", "STALE", "PLANNING_ONLY"} & states:
        return EXIT_BLOCKED
    return EXIT_OK


# --------------------------------------------------------------------------- #
# GO-01-08: two modes, two meanings                                             #
# --------------------------------------------------------------------------- #
def audit(*, receipts: Sequence[Receipt] = (), subject: QualificationSubject | None = None,
          trust_root: Any = None) -> dict[str, Any]:
    """Enumerate every finding. Structurally incapable of promoting anything."""
    report = validate_all(receipts=receipts, subject=subject, trust_root=trust_root)
    return {
        "schema_id": "rcg.qualification_audit/1",
        "mode": "AUDIT",
        "at": _now(),
        "promotes": False,
        "banner": _REPORTING_BANNER,
        "conditions": report["conditions"],
        "blocked": report["blocked"],
        "satisfied": report["satisfied"],
        "findings": [{"condition_id": r["condition_id"], "state": r["state"],
                      "remedy": r["reason"]} for r in report["conditions"]
                     if r["verdict"] != "PASS"],
    }


def release(*, receipts: Sequence[Receipt] = (), subject: QualificationSubject | None = None,
            trust_root: Any = None, upstream_digests: Mapping[str, str] | None = None,
            observed_digests: Mapping[str, str] | None = None,
            authority_valid_until: datetime | None = None,
            windows: Sequence[Any] = (), desk_verdict: Mapping[str, Any] | None = None,
            now: datetime | None = None) -> dict[str, Any]:
    """Fail closed at the first unmet applicable gate.

    Before advancing, upstream digests and authority freshness are validated: a
    phase whose inputs have changed since it passed has not passed *for this
    subject*, and a schema-valid phase is not automatically a passing phase.
    """
    moment = now or datetime.now(timezone.utc)
    blockers: list[dict[str, Any]] = []

    upstream = dict(upstream_digests or {})
    observed = dict(observed_digests or {})
    for name, expected in upstream.items():
        actual = observed.get(name)
        if actual != expected:
            blockers.append({"kind": "UPSTREAM_DRIFT", "subject": name,
                             "reason": (f"upstream input {name!r} was {expected[:19]}... when the "
                                        f"phase passed and is {str(actual)[:19]}... now")})
    if authority_valid_until is not None and moment >= authority_valid_until:
        blockers.append({"kind": "AUTHORITY_EXPIRED", "subject": "authority",
                         "reason": f"authority expired at {authority_valid_until.isoformat()}"})

    # WG-06: one policy on every route. The successor release used to decide on
    # the thirteen conditions alone; the contract probe reached GO with no
    # observation window at all. The window policy lives in rcg.promotion and is
    # applied here identically, and the accountable-role decision must be
    # AUTHORIZED, not merely absent.
    from rcg.promotion import REQUIRED_WINDOWS
    for kind, floor in REQUIRED_WINDOWS.items():
        good = [w for w in windows if getattr(w, "kind", None) == kind and getattr(w, "valid", False)
                and subject is not None and w.subject.subject_digest == subject.subject_digest]
        if not good:
            blockers.append({"kind": "OBSERVATION_MISSING", "subject": kind,
                             "reason": (f"no valid {kind!r} observation window of at least {floor} "
                                        "over this subject; a release decided without the window "
                                        "is a release decided before the evidence exists")})
    if desk_verdict is None or desk_verdict.get("verdict") != "AUTHORIZED":
        blockers.append({"kind": "RELEASE_AUTHORITY", "subject": "accountable_roles",
                         "reason": ("release authority is " +
                                    (str(desk_verdict.get("verdict")) if desk_verdict else "not presented")
                                    + "; every accountable role must have approved this exact subject")})

    report = validate_all(receipts=receipts, subject=subject, trust_root=trust_root)
    rows = report["conditions"]
    decision = "GO" if not blockers and report["verdict"] == "PASS" else "NO_GO"
    code = EXIT_OK if decision == "GO" else (EXIT_BLOCKED if blockers else _exit_for(rows))

    return {
        "schema_id": "rcg.qualification_release/1",
        "mode": "RELEASE",
        "at": _now(),
        "decision": decision,
        "production_verdict": decision if decision == "GO" else "NO_GO",
        "exit_code": code,
        "prerequisite_blockers": blockers,
        "conditions": rows,
        "blocked": report["blocked"],
        "schema_valid": True,
        "gate_verdict": decision,
        "boundary": ("schema validity and gate passing are different properties and are reported "
                     "separately; no consumer may read the first as the second"),
    }


# --------------------------------------------------------------------------- #
# GO-01-03: readiness and promotion are different operations                    #
# --------------------------------------------------------------------------- #
#: Fields excluded from an exported candidate. The same rules the verifier
#: applies -- a mismatch here is silently fatal later, because the bytes a human
#: approves would not be the bytes the gate verifies.
CANONICAL_EXCLUSIONS = ("approval_refs", "preapproval_subject_digest", "generated_at",
                        "authority_checked_at", "row_digest", "previous_digest")


def prepare_candidate(document: Mapping[str, Any], *, kind: str,
                      subject: QualificationSubject) -> dict[str, Any]:
    """Export the exact bytes a human will approve. Never touches an approval."""
    body = {k: v for k, v in document.items() if k not in CANONICAL_EXCLUSIONS}
    payload = canonical_bytes(body)
    return {
        "schema_id": "rcg.candidate_export/1",
        "kind": kind,
        "exported_at": _now(),
        "subject_digest": subject.subject_digest,
        "candidate_digest": sha256_of(payload),
        "excluded_fields": list(CANONICAL_EXCLUSIONS),
        "bytes": payload.decode("utf-8"),
        "promotes": False,
    }


def finalize_with_approvals(export: Mapping[str, Any], approvals: Sequence[Mapping[str, Any]],
                            *, subject: QualificationSubject) -> dict[str, Any]:
    """Import decisions, verify each against the export, then evaluate.

    A decision that does not match the exported bytes is refused, not
    reconciled: the approver approved something, and if it was not this, saying
    so is the only honest option.
    """
    accepted, refused = [], []
    for approval in approvals:
        candidate = approval.get("candidate_digest")
        subject_digest = approval.get("subject_digest")
        if candidate != export["candidate_digest"]:
            refused.append({"approval_id": approval.get("approval_id"),
                            "reason": (f"approves candidate {str(candidate)[:19]}..., but the "
                                       f"export is {export['candidate_digest'][:19]}...")})
        elif subject_digest != subject.subject_digest:
            refused.append({"approval_id": approval.get("approval_id"),
                            "reason": "bound to a different qualification subject"})
        elif approval.get("kind") not in ("TASK", "RELEASE"):
            refused.append({"approval_id": approval.get("approval_id"),
                            "reason": f"unknown approval kind {approval.get('kind')!r}"})
        else:
            accepted.append(approval)
    return {
        "schema_id": "rcg.finalize/1",
        "at": _now(),
        "export_candidate_digest": export["candidate_digest"],
        "accepted": [a.get("approval_id") for a in accepted],
        "refused": refused,
        "verdict": "PASS" if accepted and not refused else "FAIL",
    }



def _load_subject_document(path: str) -> QualificationSubject:
    """A frozen subject is read from a document with every field present.

    WG-03: no field is defaulted. A subject with an unknown configuration digest
    or an unassigned observation authority is a subject nobody froze.
    """
    from rcg.evidence import load_strict
    doc = load_strict(Path(path))
    required = ("candidate_digest", "runtime_version", "configuration_digest", "data_binding",
                "observation_authority_ref", "observation_authority_expires_at")
    missing = [k for k in required if not doc.get(k)]
    if missing:
        raise ValueError(f"subject document is missing {missing}")
    for k in ("candidate_digest", "configuration_digest"):
        v = str(doc[k])
        if not (v.startswith("sha256:") and len(v) == 71 and set(v[7:]) <= set("0123456789abcdef")):
            raise ValueError(f"{k} must be a full sha256: digest, got {v[:24]!r}")
        if v[7:] == "0" * 64:
            raise ValueError(f"{k} is the all-zero placeholder; a placeholder is not a digest")
    for placeholder in ("UNASSIGNED", "unbound", "NOT_ISSUED", "TBD"):
        for k in ("data_binding", "observation_authority_ref"):
            if placeholder.lower() in str(doc[k]).lower():
                raise ValueError(f"{k} reads {doc[k]!r}; a placeholder is not a binding")
    expires = datetime.fromisoformat(str(doc["observation_authority_expires_at"]).replace("Z", "+00:00"))
    if expires.tzinfo is None:
        raise ValueError("observation_authority_expires_at must carry a timezone")
    return freeze_subject(
        candidate_digest=str(doc["candidate_digest"]), runtime_version=str(doc["runtime_version"]),
        configuration_digest=str(doc["configuration_digest"]), data_binding=str(doc["data_binding"]),
        observation_authority_ref=str(doc["observation_authority_ref"]),
        observation_authority_expires_at=expires,
        model_identity=doc.get("model_identity"))


# --------------------------------------------------------------------------- #
def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("command", choices=("audit", "release"),
                        help="audit enumerates findings and cannot promote; "
                             "release decides, fail-closed")
    parser.add_argument("--candidate-digest", default=None,
                        help="audit only: a digest to report against. Refused for release, "
                             "which needs a full --subject document (WG-03).")
    parser.add_argument("--runtime-version", default=None)
    parser.add_argument("--subject", default=None,
                        help="path to a frozen QualificationSubject document (WG-03). Every "
                             "field is required; nothing is synthesized.")
    parser.add_argument("--trust-root", default=None,
                        help="path to the enrolled trust root; defaults to $RCG_TRUST_ROOT. "
                             "Release without one is refused, not evaluated unattested.")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--evidence", default=None,
                        help="directory of receipts to read (GO-00-03). Without it the "
                             "run evaluates against an empty evidence set, which is "
                             "honest but can never change.")
    args = parser.parse_args(list(argv) if argv is not None else None)

    subject = None
    trust_root = None
    if args.subject:
        try:
            subject = _load_subject_document(args.subject)
        except Exception as exc:                                    # noqa: BLE001
            print(f"subject document refused: {type(exc).__name__}: {exc}")
            return EXIT_INDETERMINATE
    elif args.candidate_digest and args.runtime_version:
        if args.command == "release":
            # WG-03: the release route used to synthesize configuration_digest,
            # data_binding, authority ref and a one-year expiry from two flags.
            # An invented subject cannot be released; only audited against.
            print("release refuses --candidate-digest: a release subject is a frozen document "
                  "with a real configuration digest, data binding and observation authority. "
                  "Pass --subject FILE. (--candidate-digest remains available to `audit`, "
                  "which is reporting-only.)")
            return EXIT_INDETERMINATE
        subject = freeze_subject(
            candidate_digest=args.candidate_digest, runtime_version=args.runtime_version,
            configuration_digest="sha256:" + "0" * 64, data_binding="unbound (audit only)",
            observation_authority_ref="UNASSIGNED (audit only)",
            observation_authority_expires_at=datetime.now(timezone.utc).replace(
                year=datetime.now(timezone.utc).year + 1))

    root_path = args.trust_root or os.environ.get("RCG_TRUST_ROOT")
    if args.command == "release":
        if not root_path:
            print("release refuses to run without a trust root: set RCG_TRUST_ROOT or pass "
                  "--trust-root. Evaluating a release unattested is not a weaker release, it is "
                  "not one.")
            return EXIT_UNTRUSTED
        try:
            from rcg.trustroot import TrustRoot
            trust_root = TrustRoot.load(root_path)
        except Exception as exc:                                    # noqa: BLE001
            print(f"trust root refused: {type(exc).__name__}: {exc}")
            return EXIT_UNTRUSTED
        if subject is None:
            print("release needs --subject FILE; there is nothing to decide about otherwise.")
            return EXIT_INDETERMINATE
    elif root_path:
        try:
            from rcg.trustroot import TrustRoot
            trust_root = TrustRoot.load(root_path)
        except Exception as exc:                                    # noqa: BLE001
            print(f"warning: trust root at {root_path} refused ({type(exc).__name__}: {exc}); "
                  "audit continues unattested")

    receipts: tuple = ()
    intake_summary = None
    if args.evidence:
        if subject is None:
            print("--evidence needs --candidate-digest and --runtime-version: a receipt "
                  "is bound to a subject, so there is nothing to bind it to otherwise.")
            return EXIT_INDETERMINATE
        from rcg.intake import intake_report, load_receipts
        result = load_receipts(args.evidence, subject=subject)
        receipts = result.accepted
        intake_summary = intake_report(result)

    if args.command == "audit":
        report = audit(subject=subject, receipts=receipts, trust_root=trust_root)
        if intake_summary is not None:
            report["intake"] = intake_summary
        if args.json:
            print(json.dumps(report, indent=2))
        else:
            print(_REPORTING_BANNER)
            for row in report["conditions"]:
                print(f"  {row['condition_id']:<9} {row['state']:<14} {row['reason'][:88]}")
            print(f"\n  {len(report['blocked'])} of {len(PROD_CONDITIONS) + 5} conditions blocked")
            if intake_summary is not None:
                print(f"  evidence: {intake_summary['accepted_count']} accepted, "
                      f"{intake_summary['rejected_count']} rejected, "
                      f"{intake_summary['scanned']} scanned from {intake_summary['root']}")
                for reason, count in intake_summary["rejected_by_reason"].items():
                    print(f"    refused {count:>3}  {reason}")
        # Reporting-only mode still exits non-zero when the gate is not GO.
        return EXIT_OK if not report["blocked"] else EXIT_BLOCKED

    report = release(subject=subject, receipts=receipts, trust_root=trust_root)
    if intake_summary is not None:
        report["intake"] = intake_summary
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print(f"decision: {report['decision']}  (exit {report['exit_code']})")
        for row in report["conditions"]:
            if row["verdict"] != "PASS":
                print(f"  {row['condition_id']:<9} {row['state']:<14} {row['reason'][:88]}")
    return report["exit_code"]


if __name__ == "__main__":       # pragma: no cover
    raise SystemExit(main())
