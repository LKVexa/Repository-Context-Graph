# Repository Context Graph for Cross-File Changes

Runtime **1.7.2** is a Python implementation of selected repository-context contracts from the accompanying 66-suite JA21/DeepML specification corpus. Its historical control-plane package is v1.3.0, with a v1.4.0 successor. These versions describe different artifacts.

The implementation indexes admitted local files, extracts static declarations and imports, builds a provenance-bearing graph, answers graph queries, retrieves lexical context, compares snapshot identities and produces bounded impact/review reports. The workflow layer provides configurable policy, review and effect mechanisms. **It remains PRODUCTION NO_GO.** Local identity examples and synthetic tests are not deployment identity or independent approval.

The September 2026 efficacy audit fixed snapshot validation, worktree freshness, Python package imports, impact limits, citation IDs, review-to-change binding, permission enforcement, rollback reporting and evaluation accounting. See [the repository audit](../AUDIT_REPORT.md). All earlier application/GO/audit reports describe their captured historical subjects.

## Boundaries of the name

- Collection reads the supplied directory. Use an immutable checkout for a coherent multi-file snapshot; a revision label alone does not freeze a live worktree.
- Python support is static AST declaration/import analysis, with repository-relative module layout. Dynamic imports, runtime path changes, call graphs and full language semantics are not modeled. JA-family analysis uses lexical rules; it does not execute or certify the provisional language specifications.
- Retrieval is lexical BM25-style search. Changed snapshots are fully rebuilt; only unchanged snapshots reuse the index. Reported work counts now reflect that.
- Build/test/ownership/ADR connectors admit evidence bytes, but do not implement every node and relation in the ontology. Pathless history and tracker records contribute to snapshot identity and retrieval, but are not corresponding graph entities.
- Rollout switches require a configured flag store; the local unconfigured demonstration path has no deployment switch. No live model provider or qualified deployment is supplied.
- The 66-suite corpus is a specification collection, not 66 implemented executable products. UMC is a traceability and observation harness with formal acceptance still open.

## Quick start

Run these commands from this `Repository Context Graph` directory, using Python 3.10 or later. Indexing prints a graph summary; persistent graph storage is exposed through the Python API rather than a CLI export command.

```sh
python -m rcg.cli index   ..                      # build the graph over the corpus
python -m rcg.cli analyze ..                      # deterministic analyzers only
python -m rcg.cli impact  .. --seed "<path>"      # impact before drafting
python -m rcg.cli review  .. -q "<question>"      # render the human review package
python -m rcg.cli selftest                        # the whole test suite
python -m rcg.cli evaluate                        # the offline evaluation corpus
python environments/ci.py                         # cross-platform CI entry point
```

Windows may also run `environments\ci.cmd`; POSIX environments may continue to
use `sh environments/ci.sh`.

No third-party runtime dependency: the `rcg` package is standard library only.

## Layout

| path | contents |
|---|---|
| `rcg/` | runtime modules and connector/parser packages |
| `registry/` | generated governance registries |
| `docs/` | DOC-01..14, generated from the live system |
| `tests/` | unit, adversarial, verification, end-to-end, governance, supply-chain, production gates, control-plane successor, qualification intake, and the graph/workflow/hardening/integrity/efficacy regressions |
| `eval/` | offline corpus, harness and performance benchmark |
| `fixtures/` | generated golden repositories |
| `environments/` | ENV-01..06 profiles and the CI entry point |
| `control-plane/` | the vendored v1.3.0 package (immutable), the v1.4.0 successor, the check registry, the runner and the run evidence |

## Historical changes: what v1.5.0 added

The executable half of R01 and R04 — the twenty-one items executed out of the
thirty-six the prompt/workflow package marks reachable without a host, a second
person, a bound model or elapsed time. Reachable is not executed: two reachable
items (ITEM-53, ITEM-26) were deliberately not run, as
[GO_PACKAGE_EXECUTION_REPORT.md](GO_PACKAGE_EXECUTION_REPORT.md) records.

| change | plan tasks | what it makes enforceable |
|---|---|---|
| `rcg/rollout.py` rewritten | GO-04-02, GO-04-03 | Exact boolean types (the string `"false"` no longer enables the system), thirteen refusal cases all failing closed to disabled, authenticated `Principal` writes, compare-and-set on a revision, an exclusive lock, and an emergency path that needs no revision so it cannot lose a race. |
| `rcg/pipeline.py` wired to the flag store | GO-04-01, GO-04-04, GO-04-06, GO-04-07 | **The runtime now reads the rollout store.** Before v1.5.0 nothing on the execution path did — the only importer of `rcg.rollout` was the control-plane *checker* — so `rcg.enabled = false` did not stop a run. The switch is checked at admission and four checkpoints; the model switch is independent; a mid-run disable cancels with evidence preserved. |
| `rcg/scope.py` | GO-04-05 | One `effective_permissions` intersection over environment, contract, mode, authority and surface, narrowing-only; `check_evidence_write` separates writing evidence from modifying the repository. |
| `rcg/observability.py` | GO-06-11 | Seven required measurement fields, and corpus/model/configuration drift makes a measurement read `STALE` automatically. |
| `rcg/sli.py` (new) | GO-07-01 | The qualified-answer taxonomy, denominators, exclusion authority, percentile method and clock source — and metric labels that cannot carry repository content. |
| `control-plane/successor/` (new, v1.4.0) | GO-01-01, 03, 04, 06, 07, 08, 09, 10, 12, 13 | Proof-driven validators replacing thirteen stored strings; governed non-applicability; append-only restart-safe runs with no delete method; artifact-bound results; audit and release as separate modes; a blocked promotion that exits non-zero. |
| `docs/freshness.py` (new), DOC-13, DOC-14 | GO-01-11, GO-08-09 | Four freshness states with distinct remediations — `DRIFTED` is the one that silently loses work — and operator and user runbooks generated from their registries. |

**The product remains PRODUCTION NO_GO.** All thirteen original blockers are
open, and none of the forty-four evidence records under `production-evidence/`
carries an independent review disposition, because no second accountable person
has been named.

## What v1.4.0 added

The RCG Production GO Plan v1.1.0 remediation. Four runtime defects and six
qualification-tooling gaps, each with its own negative tests:

| module | plan task | what it makes enforceable |
|---|---|---|
| `rcg/scope.py` | GO-02-13 | Mutating and privileged are separate sets, so `network_read` is admissible in `read_only`/`draft_only` against a **named** allowlist without widening either mode. `reconcile_environments` refuses a declared profile no contract could hold. |
| `rcg/pipeline.py` | GO-04-11 | A policy `DENY` stops the run **before** retrieval and the provider call, with zero provider calls and no payload disclosed. `DENIED` is its own terminal workflow state, not an abstention. |
| `rcg/effects.py` | GO-08-11, GO-08-12 | A run with no change payload reports `NO_OP` instead of echoing its declared paths. A real change is preimage-bound, written atomically, and restored precisely with before/after digests if anything fails. |
| `rcg/evidence.py` | GO-01-15 | Duplicate keys, non-finite numbers, bad UTF-8, oversize documents and non-`sha256:` references are refused; a skipped optional check cannot satisfy a mandatory one. |
| `rcg/trustroot.py` | GO-01-16 | The verification anchor lives outside the package; algorithms are registered by the deployment, never imported here. |
| `tests/run_all.py` | GO-01-17 | Zero discovery, an import failure, a skipped required test, an unexpected success and a defaulted verdict each exit non-zero, with full diagnostics retained. |
| `rcg/observability.py` | GO-07-11 | Every rate carries its denominator; availability over no traffic or all-refusal traffic is `INSUFFICIENT_DATA`, never a pass. |
| `rcg/promotion.py` | GO-07-12, GO-09-09, GO-11-11 | The qualification subject is frozen before a window opens; drift, clock rollback, telemetry gaps and expired authority invalidate it; and no planning PASS, package-integrity PASS or green test suite can be consumed as a release GO. |

**The product remains PRODUCTION NO_GO.** See
[`GO_PLAN_APPLICATION_REPORT.md`](GO_PLAN_APPLICATION_REPORT.md) for what moved
and what did not, and [DOC-12](docs/DOC-12-known-limitations-non-goals.md) for
the standing limitations.

## Documentation index

| document | file |
|---|---|
| DOC-01 — Architecture | [DOC-01-architecture.md](docs/DOC-01-architecture.md) |
| DOC-02 — Data flow and trust boundaries | [DOC-02-dataflow-trust-boundaries.md](docs/DOC-02-dataflow-trust-boundaries.md) |
| DOC-03 — Source and connector inventory | [DOC-03-connector-inventory.md](docs/DOC-03-connector-inventory.md) |
| DOC-04 — Permission matrix | [DOC-04-permission-matrix.md](docs/DOC-04-permission-matrix.md) |
| DOC-05 — Threat model | [DOC-05-threat-model.md](docs/DOC-05-threat-model.md) |
| DOC-06 — Model and tool inventory | [DOC-06-model-tool-inventory.md](docs/DOC-06-model-tool-inventory.md) |
| DOC-07 — Provenance schema | [DOC-07-provenance-schema.md](docs/DOC-07-provenance-schema.md) |
| DOC-08 — Run-state schema | [DOC-08-run-state-schema.md](docs/DOC-08-run-state-schema.md) |
| DOC-09 — Human approval policy | [DOC-09-human-approval-policy.md](docs/DOC-09-human-approval-policy.md) |
| DOC-10 — Evaluation plan and benchmark corpus | [DOC-10-evaluation-plan.md](docs/DOC-10-evaluation-plan.md) |
| DOC-11 — Incident and rollback runbook | [DOC-11-incident-rollback-runbook.md](docs/DOC-11-incident-rollback-runbook.md) |
| DOC-12 — Known limitations and non-goals | [DOC-12-known-limitations-non-goals.md](docs/DOC-12-known-limitations-non-goals.md) |
| DOC-13 — Operator runbook | [DOC-13-operator-runbook.md](docs/DOC-13-operator-runbook.md) |
| DOC-14 — User guide | [DOC-14-user-guide.md](docs/DOC-14-user-guide.md) |
| Changelog | [CHANGELOG.md](docs/CHANGELOG.md) |
| Requirement traceability | [TRACEABILITY.md](docs/TRACEABILITY.md) |

## Registries

| file | requirement |
|---|---|
| [`registry/BUDGETS.json`](registry/BUDGETS.json) | AUD-014 |
| [`registry/CONTROLS.json`](registry/CONTROLS.json) | IMPL-06 |
| [`registry/LANGUAGE_TIERS.json`](registry/LANGUAGE_TIERS.json) | AUD-005 |
| [`registry/LIFECYCLE.json`](registry/LIFECYCLE.json) | AUD-011 |
| [`registry/MIGRATIONS.json`](registry/MIGRATIONS.json) | AUD-009 |
| [`registry/ONTOLOGY.json`](registry/ONTOLOGY.json) | AUD-004 |
| [`registry/OWNERS.json`](registry/OWNERS.json) | AUD-003 |
| [`registry/RELEASE_POLICY.json`](registry/RELEASE_POLICY.json) | AUD-018 |
| [`registry/REQUIREMENTS.json`](registry/REQUIREMENTS.json) | AUD-001 |
| [`registry/ROLLOUT.json`](registry/ROLLOUT.json) | AUD-015 |
| [`registry/RTM.json`](registry/RTM.json) | AUD-002 |
| [`registry/SLO.json`](registry/SLO.json) | AUD-006 |
| [`registry/SUPPLY_CHAIN.json`](registry/SUPPLY_CHAIN.json) | AUD-013 |
| [`registry/THRESHOLDS.json`](registry/THRESHOLDS.json) | AUD-012 |

## Honest status

This delivery is **not** production-ready and does not claim to be. Phase 12 is
BLOCKED because release requires an external human-signed approval that was
never given; encryption at rest and in transit (XSEC-04) is not implemented;
staging, production and the privileged execution path are declared but not
provisioned; and no model provider is bound, so the reasoning layer abstains on
every call and its grounding is measured as *not exercised* rather than as
passing. See [docs/DOC-12-known-limitations-non-goals.md](docs/DOC-12-known-limitations-non-goals.md)
and `control-plane/run/*/RUN_SUMMARY.json` for the per-task verdicts.

The post-application v1.3.1 hardening audit repaired snapshot-identity,
determinism, scope-enforcement, connector-input and CLI fail-closed defects not
covered by the original test suite. See
[AUDIT_FIX_REPORT_v1.3.1.md](AUDIT_FIX_REPORT_v1.3.1.md). The historical
`APPLICATION_REPORT.md` remains evidence for the original v1.3.0 application
run only; it is not release evidence for this patched runtime.
