"""Performance and scale benchmark with numeric thresholds (AUD-006, AUD-014, IMPL-10).

Every objective in ``registry/SLO.json`` that this environment can measure is
measured here and compared against its numeric target. The report is
machine-readable and exits non-zero on a miss, so CI gates on it.

Small-corpus timings are observations, not evidence that a larger scale target
was met. Estimates are labeled separately and unexercised targets cannot pass.
"""
from __future__ import annotations

import copy
import dataclasses
import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Sequence

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE.parent))

from rcg.connectors import SourceCodeConnector                    # noqa: E402
from rcg.canonical import sha256_of
from rcg.governance import BUDGETS, SLO                           # noqa: E402
from rcg.impact import ImpactBudget, compute_impact               # noqa: E402
from rcg.incremental import incremental_update                    # noqa: E402
from rcg.indexer import bind_snapshot, build_graph                # noqa: E402
from rcg.query import GraphQuery                                  # noqa: E402
from rcg.scope import ScopeContract                               # noqa: E402

__all__ = ["Measurement", "BenchmarkReport", "run_benchmark"]


@dataclass
class Measurement:
    objective_id: str
    metric: str
    target: str
    observed: float
    unit: str
    passed: bool
    detail: str = ""
    target_exercised: bool = True
    within_sample_threshold: bool = field(init=False)

    def __post_init__(self):
        self.within_sample_threshold = self.passed
        self.passed = self.passed and self.target_exercised

    def as_document(self) -> dict[str, Any]:
        return {"objective_id": self.objective_id, "metric": self.metric, "target": self.target,
                "observed": round(self.observed, 4), "unit": self.unit, "passed": self.passed,
                "detail": self.detail, "target_exercised": self.target_exercised,
                "within_sample_threshold": self.within_sample_threshold,
                "target_result": ("INSUFFICIENT_DATA" if not self.target_exercised else
                                  "PASS" if self.passed else "FAIL")}


@dataclass
class BenchmarkReport:
    measurements: list[Measurement] = field(default_factory=list)
    corpus_files: int = 0
    corpus_root: str = ""
    not_measured: list[dict[str, str]] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return (bool(self.measurements) and self.corpus_files > 0
                and all(m.passed and m.target_exercised for m in self.measurements))

    def as_document(self) -> dict[str, Any]:
        return {
            "benchmark_version": "1.1.0",
            "corpus_root": self.corpus_root, "corpus_files": self.corpus_files,
            "passed": self.passed,
            "measurements": [m.as_document() for m in self.measurements],
            "not_measured": self.not_measured,
            "scaling_note": (
                f"Observed values are actual timings on {self.corpus_files} admitted files. "
                "Any linear build estimate is detail only. Larger file/node targets remain "
                "INSUFFICIENT_DATA until exercised at their declared scale."),
        }


def _scope(root: Path) -> ScopeContract:
    return ScopeContract.from_document({
        "schema_id": "rcg.scope_contract/1", "run_id": "BENCH", "target_root": str(root),
        "repository_id": "benchmark", "worktree_id": "bench", "baseline_revision": "bench",
        "permissions": ["read", "analyze"], "authorized_paths": ["."], "denied_paths": [],
        "authorized_source_systems": ["source_code"], "authorized_external_systems": [],
        "data_handling_profile": "default-deny-secrets",
        "issued_at": "2026-01-01T00:00:00Z", "expires_at": "2099-01-01T00:00:00Z",
        "issuer_ref": "benchmark", "human_authority_ref": "benchmark", "mode": "read_only",
    })


def _timed(function: Callable[[], Any]) -> tuple[Any, float]:
    start = time.perf_counter()
    value = function()
    return value, (time.perf_counter() - start) * 1000.0


def run_benchmark(root: Path) -> BenchmarkReport:
    root = Path(root).resolve()
    scope = _scope(root)
    report = BenchmarkReport(corpus_root=str(root))

    collected, collect_ms = _timed(
        lambda: SourceCodeConnector(scope).collect(root=root, revision="bench"))
    binding = bind_snapshot(collected, repository_id="benchmark", worktree_id="bench",
                            root=root, revision="bench")
    report.corpus_files = binding.file_count
    scale = 10_000 / max(binding.file_count, 1)

    index, build_ms = _timed(lambda: build_graph([collected], binding=binding))
    build_scaled = (collect_ms + build_ms) * scale / 1000.0
    report.measurements.append(Measurement(
        "SLO-BUILD-01", "full graph build wall clock", "<= 120 s per 10k files",
        (collect_ms + build_ms) / 1000.0, "s", build_scaled <= 120.0,
        f"{binding.file_count} files; linear estimate {build_scaled:.3f} s/10k (not a scale measurement)",
        target_exercised=binding.file_count >= 10_000))

    changed = copy.deepcopy(collected)
    changed_count = 0
    for offset in range(min(50, len(changed.artifacts))):
        artifact = changed.artifacts[offset]
        if artifact.content is None:
            continue
        content = artifact.content + b"\n# benchmark change\n"
        changed.artifacts[offset] = dataclasses.replace(
            artifact, source_hash=sha256_of(content), content=content)
        changed_count += 1
    _, incremental_ms = _timed(lambda: incremental_update(
        previous_result=collected, previous_index=index, current_result=changed,
        repository_id="benchmark", worktree_id="bench", root=root, revision="bench2"))
    incremental_s = incremental_ms / 1000.0
    report.measurements.append(Measurement(
        "SLO-INCR-01", "incremental update wall clock", "<= 5 s for <= 50 changed files",
        incremental_s, "s", incremental_s <= 5.0,
        f"{changed_count} files changed; current updater fully rebuilds changed snapshots",
        target_exercised=changed_count > 0))

    query = GraphQuery(index.graph, scope=scope)
    timings = []
    for _ in range(20):
        _, ms = _timed(lambda: query.symbols(name="Record"))
        timings.append(ms)
    p95 = sorted(timings)[int(0.95 * (len(timings) - 1))]
    report.measurements.append(Measurement(
        "SLO-QUERY-01", "symbol query p95", "<= 250 ms at 100k nodes", p95, "ms", p95 <= 250.0,
        f"{len(index.graph.nodes)} nodes in this corpus",
        target_exercised=len(index.graph.nodes) >= 100_000))

    seeds = [n.node_id for n in index.graph.nodes[:5]]
    impact_times = []
    for _ in range(5):
        _, ms = _timed(lambda: compute_impact(index.graph, seeds, run_id="BENCH",
                                              budget=ImpactBudget(max_depth=8)))
        impact_times.append(ms)
    impact_p95 = sorted(impact_times)[-1] / 1000.0
    report.measurements.append(Measurement(
        "SLO-IMPACT-01", "impact report p95", "<= 2 s at depth 8", impact_p95, "s",
        impact_p95 <= 2.0, "depth 8, 5 seeds"))

    budget = BUDGETS["indexing"]
    within = binding.file_count <= budget["max_files"]
    report.measurements.append(Measurement(
        "BUDGET-INDEX-01", "admitted files within the indexing budget",
        f"<= {budget['max_files']} files", float(binding.file_count), "files", within,
        "AUD-014 indexing budget"))

    for objective in SLO["objectives"]:
        measurement = next((m for m in report.measurements if m.objective_id == objective["id"]), None)
        if measurement is not None and not measurement.target_exercised:
            report.not_measured.append({"objective_id": objective["id"], "metric": objective["metric"],
                                        "reason": "declared target scale was not exercised; local timing only"})
        elif measurement is None:
            report.not_measured.append({
                "objective_id": objective["id"], "metric": objective["metric"],
                "reason": ("requires a live deployment window; not measurable from a single "
                           "offline run")})
    return report


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else _HERE.parent.parent
    result = run_benchmark(target)
    print(json.dumps(result.as_document(), indent=2, sort_keys=True))
    raise SystemExit(0 if result.passed else 1)
