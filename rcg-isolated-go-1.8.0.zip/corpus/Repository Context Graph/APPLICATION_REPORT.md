# Repository Context Graph — Application Report

> **Historical evidence notice (v1.3.1 audit).** This report records the
> original v1.3.0 application run. The implementation was subsequently
> hardened to runtime v1.3.1 after an independent defect audit. This report is
> intentionally preserved rather than rewritten; it is **not** release
> evidence for the patched runtime. See `AUDIT_FIX_REPORT_v1.3.1.md` for the
> post-application findings, repairs and fresh verification evidence.

Applying the **Repository Context Graph for Cross-File Changes — Prompt/Workflow
Master v1.3.0** (217 tasks, 13 phases) to the generic project repository.

## Verdict

| | |
|---|---|
| Run id | `RCG-885dcf0010579251` |
| Baseline revision | `c98de63660a6474d96c4e3c2a948dbbe…` |
| Authority scope digest | `260834b73cee57e8010f7a31856c589e…` |
| Package integrity | **PASS** — PASS: package v1.3.0; 217 immutable-source-bound tasks; 13 phases; manifest/source/schema/ |
| Authority contract | **valid** (validated by the package's own runtime validator) |
| Tasks COMPLETE | **204 / 217** |
| Tasks BLOCKED | **13** — every one a declared, reasoned blocker |
| Checks executed | 467, of which **454 passed** |
| Task evidence runtime-invalid | **0** |
| Run-ledger revisions | 219, chain **valid** |
| Phase gates runtime-valid | **13 / 13** |
| Phase gates PASS | **9 / 13** |
| Wall clock | 31.9 s |

**Production readiness: NO-GO.** Phase 12 is BLOCKED and that is the gate working,
not failing — release requires an external human-signed approval that was never
given. Nothing in this delivery claims otherwise.

## Phase results

| phase | title | status | green | blocked |
|---|---|---|---|---|
| 00 | Audit hardening and requirements control | **PASS** | 18 | 0 |
| 01 | Authority, scope, identity & workflow state | **PASS** | 15 | 0 |
| 02 | Connectors, artifact identity & provenance | **PASS** | 25 | 0 |
| 03 | Graph ingestion & persistent state | **PASS** | 7 | 0 |
| 04 | Historical context, retrieval & query | **PASS** | 5 | 0 |
| 05 | Incremental updates & impact analysis | **PASS** | 4 | 0 |
| 06 | Deterministic analysis, model reasoning & uncertainty | **PASS** | 25 | 0 |
| 07 | Human review, policy & approval control | **PASS** | 22 | 0 |
| 08 | Security, privacy & sandboxing | **BLOCKED** | 18 | 1 |
| 09 | Observability, audit & reproducibility | **PASS** | 21 | 0 |
| 10 | Verification, testing & evaluation | **BLOCKED** | 28 | 1 |
| 11 | Deployment environments & documentation | **BLOCKED** | 15 | 3 |
| 12 | Production readiness & release gate | **BLOCKED** | 1 | 8 |

Every gate above was validated by `tools/validate_runtime.py phase-gate` against
the real run-ledger bytes and the real task-evidence bytes — key coverage alone
was not accepted.

## The 13 blocked tasks, and why

### PROD-01, PROD-02, PROD-03, PROD-04, PROD-05, PROD-06, PROD-07, PROD-08

Release-gate tasks require an external, human-signed RELEASE approval bound to the phase-gate candidate digest. No such approval was given for this run: the owner authorized implementation, not release. The gate is therefore BLOCKED, which is the gate working correctly, not a defect.

### ENV-03

No staging/pre-production host exists in this delivery. The profile is declared in environments/ENVIRONMENTS.json with its contract ceiling, but nothing has been provisioned, so its designated smoke/security/isolation checks cannot run.

### ENV-04

No production integration exists in this delivery. Read-only production access is declared and bounded but not provisioned, so no smoke check can be executed.

### ENV-05

The privileged execution path is declared and enforced by the contract ceiling, but it is not provisioned as a distinct host, so its isolation checks cannot run here.

### XEVAL-06

No pilot deployment has been run. The read-only/draft-only rollout stages are declared in registry/ROLLOUT.json and enforced by rcg.rollout, but stage 2 (canary) has not been executed, so there is no pilot evidence to record.

### XSEC-04

Encryption in transit and at rest is not implemented. This package stores plaintext on the local filesystem and makes no network calls; the control is delegated to the host and is not satisfied by anything in this delivery. The data-flow half of the acceptance (prevent/redact before model access) IS implemented and tested, but the requirement itself is encryption, so this is reported BLOCKED rathe

No blocked task was argued into a green state, given a partial credit, or
re-scoped so its acceptance criterion became reachable.

## What was built

| area | contents |
|---|---|
| `rcg/` | 26 modules, 7,422 lines, standard library only |
| `registry/` | 14 generated governance registries (AUD-001..018) |
| `docs/` | DOC-01..12 plus CHANGELOG and TRACEABILITY, generated from the live system |
| `tests/` | 175 tests across unit, adversarial, verification, end-to-end, governance and supply chain |
| `eval/` | 20-case offline corpus, harness and performance benchmark |
| `fixtures/` | 9 generated golden repositories, one per property under test |
| `environments/` | ENV-01..06 profiles and the CI entry point |
| `control-plane/` | the vendored v1.3.0 package, the check registry, the runner and 219 ledger revisions of run evidence |

## Measured behaviour

| measurement | result |
|---|---|
| Test suite | 175 / 175 pass |
| Evaluation corpus | 20 / 20 cases pass; abstention accuracy 1.00 (10 TP, 10 TN, 0 FP, 0 FN) |
| Grounding rate | 1.00; forbidden-claim leaks 0 |
| Guardrails | fail closed on all 10 adversarial / out-of-scope / oversized cases |
| Graph over the corpus | 2,969 nodes and 2,930 edges from 533 admitted files, built in ~0.4 s |
| Determinism | logical digest identical across runs for a pinned revision |
| Incremental update | 2,961 nodes reused, 9 rebuilt for a one-file change |
| Benchmark | 5 / 5 objectives within target; 3 objectives reported as not measurable offline |
| Corpus integrity | 612 / 612 specification files byte-identical to the baseline |

## Honest limitations

1. **No model provider is bound.** The reasoning layer abstains on every call.
   Its mechanisms — labeled context, schema validation, evidence requirements,
   the refusal to accept an unsupported high-impact claim — are exercised with
   stub providers and real tests. Model *grounding* is reported as **not
   measured**, not as passing.
2. **Encryption is absent** (XSEC-04, BLOCKED). Plaintext on the local
   filesystem; no network calls; delegated to the host.
3. **Three environments are declared but not provisioned** (ENV-03/04/05,
   BLOCKED). Their contract ceilings are enforced; their smoke checks cannot run.
4. **No pilot has been run** (XEVAL-06, BLOCKED).
5. **The sandbox is process-level** on this host. `SandboxResult.enforcement`
   reports exactly what was applied and claims no kernel sandbox.
6. **Calibration is unpopulated**, so numeric confidence is withheld rather than
   displayed — which is the implemented behaviour, not a gap in it.
7. **SLO targets are measured at 612 files**, scaled to the 10k-file target. That
   is evidence at this scale, not proof at 100k.

Full detail: `control-plane/run/<RUN_ID>/RUN_SUMMARY.json`, the per-task
`TASK_RESULT.md` and `TASK_EVIDENCE.json` under each attempt directory, and
`docs/DOC-12-known-limitations-non-goals.md`.
