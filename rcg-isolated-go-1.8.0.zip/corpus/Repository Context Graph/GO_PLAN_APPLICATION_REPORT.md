# RCG Production GO Plan v1.1.0 — application report

**Applied:** 2026-09-05 · **Runtime:** 1.3.1 → **1.4.0** · **Verdict: PRODUCTION NO_GO.**

The plan's own sentence governs this report: *a valid plan is not a valid release.* What follows is
what changed, what it proves, and — at greater length, because it matters more — what it does not.

## Subject binding

| | |
|---|---|
| Audited baseline | `Project_Repository_Context_Graph_v1.3.1_FIXED11.zip`, 1,752 files |
| Baseline SHA-256 | `4b226bab6548a96fbd3dfcc5dee3372f3d46a7496a09ff250e6185d9d48400dd` |
| Plan `input_sha256` | identical — the plan is bound to this exact subject |
| Plan package | RCG Production GO Plan v1.1.0, 524 files, `sha256:811e765ca8d874ede15d76abdd38000f42f93a537b7dd3e6c0b09d857be7905a` |
| Plan validation of this archive | `verdict: PASS`, `candidate_archive_check: PASS` over all 1,752 member bytes, `production_verdict: NO_GO` |

Per the plan's change rules, implementation changes the product, so v1.4.0 carries a **new** candidate
digest and retains the baseline link above. The v1.3.1 baseline remains the audited subject; it is not
superseded as *the thing that was audited*.

## What was implemented

Ten items. Four were runtime defects the audit proved against this tree; six were missing qualification
machinery. Each is covered by negative tests, because every one of these findings was something passing
that should not have.

| Plan task | Finding | Change | Proof |
|---|---|---|---|
| GO-02-13 | A13 — ENV-03/ENV-04 ceilings could not instantiate | `rcg/scope.py` splits *mutating* from *privileged*; `network_read` is admissible in `read_only`/`draft_only` only against a non-empty named allowlist and never with `credential_use`; `check` refuses a system-bound permission without a named system; `reconcile_environments` refuses a profile no contract could hold | all six ENV profiles instantiate; a real contract builds from the ENV-04 ceiling and still refuses `modify`; every mutating permission is refused in both modes |
| GO-04-11 | A14 — DENY did not prevent the provider call | `rcg/pipeline.py` refuses at the policy decision, before retrieval and before the provider; re-checks immediately before the provider call for mid-run revocation; `DENIED` is a terminal workflow state | an instrumented provider records **0** calls on the Delete-Alpha probe; the denial record carries the decision and subject digest and `payload_disclosed: false`; no review package, no model output |
| GO-08-11 | A15 — declared paths reported as applied | `RunResult` separates `declared_paths` from `applied_paths` and names the effect `NO_OP` / `SIMULATED` / `APPLIED` / `ROLLED_BACK` / `DENIED` | a run with no payload reports `NO_OP`, empty `applied_paths`, and says in the record that nothing was written |
| GO-08-12 | — | `rcg/effects.py`: preimage-bound `ChangeSet`, atomic writes, bounded rollback restoring every already-written file with before/after digests | permitted change writes exactly the approved bytes; denied writes none; stale preimage refused before any write; interrupted 2-file apply restores both, digests equal |
| GO-01-15 | — | `rcg/evidence.py`: strict bounded UTF-8 JSON, duplicate keys / non-finite / oversize / bad references refused; `require_coverage` refuses a skipped optional check as mandatory coverage | seven negative cases |
| GO-01-16 | — | `rcg/trustroot.py`: root loaded from outside the package, issuer/audience/expiry/revocation-freshness/subject binding; signature algorithms **registered by the deployment**, never imported here | positive fixture accepted; fabricated trust boolean, changed subject, wrong audience, untrusted root, tampered signature, stale revocation list, revoked id, expired attestation, in-package root and no-root-configured all refused |
| GO-01-17 | A12 — runner was not evidence-grade | `tests/run_all.py` rewritten: full diagnostics retained, exact counts, JSON report, honest platform record | zero discovery, import failure, failing test, unexpected success each exit **1**; a good suite exits 0 |
| GO-06-13 | — | `RunResult.outcome_class` and `model_quality_admissible`: an abstention and a never-called provider both fail model-quality admissibility | a denied run and an abstaining run are both inadmissible; a real answer is admissible |
| GO-07-11 | — | `rcg.observability.Rate` carries its denominator; `availability()` returns `INSUFFICIENT_DATA` over zero traffic and over all-refusal traffic; `slo_report()` types all fifteen metrics | 7 SLOs + 8 thresholds reported; verdict `INSUFFICIENT_DATA`, because none is measured |
| GO-07-12, GO-09-09, GO-11-11 | — | `rcg/promotion.py`: `freeze_subject` before any window; windows invalidated by subject drift, clock rollback, telemetry gap, expired authority; the gate collects receipts by id **and** binding hash and fails closed | subject drift, rollback and gaps each invalidate; the gate returns NO_GO; **all eight** planning-only evidence kinds are refused as promotion credentials |

## What was verified

| Check | Result |
|---|---|
| `tests/run_all.py` (strict runner, Python 3.11.15, Linux) | **250 tests PASS** — 187 pre-existing, 63 new — 0 failures, 0 errors, 0 skips |
| Strict runner's own five failure modes | each exits non-zero |
| `environments/ci.py` — all five stages | **CI: PASS** |
| Control-plane package verifier | PASS; package v1.3.0, 217 immutable-source-bound tasks, 13 phases |
| Registry and documentation regeneration | clean |
| License gate over `THIRD-PARTY-NOTICES.md` | 6 entries, all permissive, `promotable: true` |
| Third-party runtime dependencies | still **zero**; `test_supply_chain` enforces it |
| 612-file JA21/DeepML corpus | **byte-identical**; nothing outside this overlay was touched |
| Plan package | untouched; no execution artifact was written into it |

## What did NOT move

**All thirteen original blockers remain open.** The promotion gate says so executably:

```
PROMOTION DECISION: NO_GO
  PROD-01..08  ABSENT: no receipt was offered for this condition
  OBSERVATION  no observation window has been opened over the frozen subject
```

- **PROD-01..08** — no authenticated human release authority exists, none has approved anything, and
  this session cannot create one. The gate now refuses to accept a substitute; that is the whole of the
  progress.
- **XSEC-04** — encryption in transit and at rest is still delegated to the host. Unchanged.
- **ENV-03 / ENV-04 / ENV-05** — now *instantiable* and reconciled with the permission lattice. Still
  **not provisioned**: no staging host, no production integration, no privileged host exists. A ceiling
  that could hold is not a host that does.
- **XEVAL-06** — no pilot has run. No canary, no read-only deployment, no elapsed day.

**The 150 plan tasks remain `NOT_STARTED` in the issued package**, and the package was not edited —
that is the plan's rule, not an oversight. Implementing a mechanism is not the same as producing the
task's evidence, which the plan requires to carry an assigned accountable owner, an independent
reviewer, positive/negative/regression records, artifact digests and an applicability disposition, all
under separately granted authority. None of that was available here. This report and its work order are
the external execution record the plan asks for; they record implementation, not acceptance.

**The seven SLOs and eight acceptance thresholds are all `INSUFFICIENT_DATA`** — typed, reported, and
unmeasured. That is now what the report says instead of a silent pass.

**Not established by anything here:** real signer identity, any provisioned environment,
native-Windows qualification, live model quality, real elapsed observation, modification against
production data, or promotion authority.

## The honest summary

Before v1.4.0 this candidate reported a denial after calling the provider, reported files as changed
that it never wrote, declared two environments that could not be built, and had a test runner under
which three different non-results printed OK. Those four things are fixed and tested. Six pieces of
qualification machinery that did not exist now exist and refuse correctly.

None of that is a release. The product is **PRODUCTION NO_GO**, and the most useful thing v1.4.0 added
is a gate that will keep saying so until real evidence arrives.
