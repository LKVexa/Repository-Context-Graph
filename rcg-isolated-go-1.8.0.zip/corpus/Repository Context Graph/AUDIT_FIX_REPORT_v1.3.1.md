# Repository Context Graph — Audit, Defect Parse, Hardening and Fix Report v1.3.1

**Audit execution:** 2026-09-04 America/Los_Angeles (2026-09-05 UTC)  
**Input:** `Project_Repository_Context_Graph.zip`  
**Baseline implementation runtime:** 1.3.0  
**Patched implementation runtime:** 1.3.1  
**Vendored Prompt/Workflow control-plane package:** 1.3.0, intentionally immutable  
**Graph schema:** 1.3.0, unchanged  
**Connector surface:** 1.0.0 → 1.0.1  
**Indexer identity algorithm:** 1.0.0 → 1.1.0

## 1. Executive verdict

The repository was structurally complete enough to run: the shipped functional
suite passed before modification, the control-plane package verified, the
offline evaluation passed, and the measured benchmark objectives were green.
However, that baseline test suite missed several correctness and authorization
defects in snapshot identity, multi-connector determinism, query/retrieval
scope enforcement, CLI fail-closed behavior, runtime-root confinement and
external evidence handling.

Those reproducible code defects are repaired in runtime v1.3.1 and covered by
new regression tests. The patched implementation passes 187/187 functional
checks plus the package verifier, verifier/runtime negative self-tests,
cross-platform CI, offline evaluation and all measured benchmark objectives.

**This audit does not change the existing production-readiness verdict.** The
product remains NO-GO for production release for the already-declared reasons:
no external human-signed release approval, no in-package encryption-at-rest or
in-transit implementation, no provisioned staging/production/privileged hosts,
and no bound production model provider.

## 2. Audit method

The audit did not rely on the prior application report as proof. It separately:

1. inspected the archive for traversal/symlink/path hazards and extracted it to
   a clean working tree;
2. enumerated the implementation, tests, registries, fixtures, evaluation
   harness, control plane and executable entry points;
3. ran the shipped tests, CI, package verifier, verifier self-test, runtime
   self-test, evaluation harness and benchmark;
4. constructed adversarial reproductions around multi-source snapshots,
   connector ordering, narrower query scopes, unknown CLI sources, runtime-root
   substitution and external/pathless records;
5. patched only the Repository Context Graph overlay and preserved the 66-suite
   baseline corpus;
6. added regressions for every repaired behavior and reran the full validation
   stack.

The intentionally invalid fixture `fixtures/golden/partial_metadata_repo/broken.py`
is adversarial parser input. A blanket compilation of fixtures reports it as a
syntax error by design; it is not an implementation defect. Targeted compilation
of runtime/test/evaluation/tooling Python sources passes.

## 3. Findings and repairs

| ID | Severity | Problem reproduced | Root cause | v1.3.1 repair | Status |
|---|---|---|---|---|---|
| RCG-AUD-001 | High | Changing an admitted `package.json` changed the graph but left `context_id` unchanged. | Snapshot binding covered only the first/source-code connector. | `bind_snapshot` now accepts and hashes the full connector-result set, including coverage state. Pipeline and CLI bind exactly what they index. | FIXED |
| RCG-AUD-002 | High | Reversing `source_code` and `tests` connector order changed the logical graph/provenance for the same bytes. | First connector to add a duplicate path won. | Canonical per-path observations are de-duplicated using a fixed source priority; conflicting hashes/revisions fail closed. | FIXED |
| RCG-AUD-003 | Critical | Graph queries and retrieval could return data under a contract that had `analyze` but no `read`. | Callers used `check_path`, which confines paths but does not grant/check permission. | Query and retrieval now call `ScopeContract.check("read", ...)` at time of use. | FIXED |
| RCG-AUD-004 | Critical | Dependency/unresolved/neighbourhood queries could reveal a denied target node. | Visibility was checked incompletely or only on the source endpoint. | Both endpoints and neighbourhood start/visited nodes are visibility-gated; unresolved output is gated too. | FIXED |
| RCG-AUD-005 | High | A narrower query scope could still see nodes from a source system it did not authorize. | Query visibility checked path but not provenance source-system authority. | Query visibility now enforces path, source-system and external-system authority from node provenance. Retrieval applies the same rule to passages. | FIXED |
| RCG-AUD-006 | High | A misspelled CLI source could return exit 0 with an empty graph. | Unknown names were silently skipped and an unauthorized fallback connector could be constructed. | `--sources` requires at least one declared local connector; unknown/unsupported connector names are rejected. No implicit source fallback remains. | FIXED |
| RCG-AUD-007 | Critical | Filesystem/Git collection trusted the runtime `root` before fully confining it to the scope target, and per-file reads did not re-check contract permission/expiry. | Source authorization happened before collection but root/path time-of-use checks were incomplete. | Pipeline requires the runtime root to equal the scope target; filesystem root is authorized before `os.walk`; each file is re-authorized before read; Git root is authorized before subprocess execution. Time-of-use denials are normalized as denied connector results. | FIXED |
| RCG-AUD-008 | High | Git accepted a revision beginning with `-`, allowing option-like input to reach the subprocess. | Revision was passed directly to `git log` without an option-injection guard. | Revisions beginning with `-` are rejected before Git execution. | FIXED |
| RCG-AUD-009 | High | Authorized pathless history/external evidence was omitted from context identity and lexical retrieval. | Binding/retrieval skipped artifacts whose `path` was `None`. | Pathless evidence is now identity-bound and indexed under an explicit virtual evidence label; scope checks do not pretend the virtual label is a repository path. | FIXED |
| RCG-AUD-010 | High | External records without IDs collide, and `repr(...)` serialization can vary with nested mapping order/non-JSON objects. | External artifact identity used `id` even when empty and content used Python representation rather than canonical evidence bytes. | Non-empty stable IDs are required; records are canonical-JSON serialized; non-canonical records are rejected as partial failures. | FIXED |
| RCG-AUD-011 | Medium | The main governed pipeline could authorize external connectors but had no API to supply their records. | `_collect` passed only `root` and `revision`. | `Pipeline.run(connector_inputs=...)` accepts per-connector explicit inputs, refuses inputs for unauthorized sources and prevents overriding pinned `root`/`revision`. | FIXED |
| RCG-AUD-012 | Medium | The CLI exposed external connectors although it had no external authorization/record-ingestion interface. | CLI choices were the full connector registry. | CLI choices are now limited to local/repository connectors; external records use the explicit governed Pipeline API. | FIXED |
| RCG-AUD-013 | Medium | CI required a POSIX shell despite the implementation being standard-library Python. | Only `environments/ci.sh` existed. | Added `environments/ci.py` and `environments/ci.cmd`; the original shell entry point remains. | FIXED |

## 4. Snapshot and determinism behavior after the fix

`context_id` is now a digest of the complete admitted evidence set used by the
run, not just source-code files. Local path observations are checked for both
hash and revision agreement across connectors. Pathless records are also bound
by source system, artifact identity, revision and source hash. If two
connectors claim different bytes/revisions for one repository path, or a
pathless connector emits conflicting bytes for one artifact identity, binding
fails closed rather than creating an ambiguous context.

The graph builder separately canonicalizes overlapping path observations. Equal
observations are de-duplicated deterministically; unequal observations are
rejected. This makes connector enumeration order irrelevant to the logical
graph.

## 5. Authorization behavior after the fix

The effective read boundary is now checked on all of the following dimensions:

- active, unexpired `read` permission;
- repository path under the contract target and authorized path set;
- provenance source system in `authorized_source_systems`;
- external evidence source in `authorized_external_systems` when applicable;
- exact pipeline runtime root matching the scope contract target.

These checks are applied at time of use for query/retrieval and repository
collection. A narrower query contract can therefore hide paths, sources and
external evidence that were present in a graph/index built under a broader
contract.

## 6. External/history evidence behavior

Pathless Git-history, pull-request, issue and discussion records are now usable
as reproducible retrieval/rationale evidence and affect context identity.
External records must have a stable ID and canonical JSON representation.

One architecture limitation remains explicit rather than guessed: the current
connector record contract does not normalize enough relation metadata to
safely project every history/tracker record into `commit`, `pull_request`,
`issue`, `discussion`, `modifies`, `reviews` and `motivates` graph nodes/edges.
The implementation therefore exposes the evidence to retrieval/rationale but
does not manufacture graph relations it cannot prove.

## 7. Validation evidence for v1.3.1

### Functional suites

| suite | result |
|---|---:|
| unit | 46 / 46 PASS |
| adversarial | 34 / 34 PASS |
| verification | 27 / 27 PASS |
| end-to-end / integration | 19 / 19 PASS |
| governance | 55 / 55 PASS |
| supply chain | 6 / 6 PASS |
| **total** | **187 / 187 PASS** |

The baseline had 175 tests; twelve targeted regressions were added by this
audit.

### Control-plane and CI

- `verify_package.py`: **PASS** — package v1.3.0, 217 immutable-source-bound
  tasks, 13 phases, manifest/source/schema/examples/scheduler/RTM/phase/archive
  controls valid.
- `self_test_verifier.py`: **PASS** — negative verifier self-tests.
- `self_test_runtime.py`: **PASS** — runtime negative/positive self-tests.
- `python environments/ci.py`: **PASS**.
- targeted `compileall` over `rcg`, tests, eval, docs, environments and
  control-plane tools: **PASS**.

### Offline evaluation

- cases: **20 / 20 PASS**;
- forbidden claim leaks: **0**;
- guardrail failures: **0**;
- abstention accuracy: **1.0**;
- model exercised: **false** — the configured default provider abstains, so
  model grounding remains explicitly unmeasured.

### Offline benchmark

Measured on the repaired package corpus (617 files):

| objective | observed | target | result |
|---|---:|---:|---|
| full graph build, scaled to 10k files | 10.9762 s | ≤ 120 s | PASS |
| incremental update, 50 files | 0.6476 s | ≤ 5 s | PASS |
| symbol query p95 | 11.9067 ms | ≤ 250 ms | PASS |
| impact report p95, depth 8 | 0.0137 s | ≤ 2 s | PASS |
| indexing file budget | 617 files | ≤ 100,000 | PASS |

The benchmark itself correctly notes that scaling from this corpus is evidence
at this scale, not proof of 100k-file production behavior. Freshness latency,
availability and maximum supported repository size remain live-deployment
measurements and are not claimed by this offline run.

## 8. Files intentionally versioned by the repair

Core runtime changes are concentrated in:

- `rcg/indexer.py`
- `rcg/query.py`
- `rcg/retrieval.py`
- `rcg/pipeline.py`
- `rcg/cli.py`
- `rcg/connectors/base.py`
- `rcg/connectors/filesystem.py`
- `rcg/connectors/history.py`
- `rcg/governance.py`
- `rcg/__init__.py`

Regression coverage is in `tests/test_adversarial.py`, `tests/test_verify.py`
and `tests/test_e2e.py`. Cross-platform validation is added in
`environments/ci.py` and `environments/ci.cmd`. Documentation/version records
are updated in README, the changelog, known limitations, generated architecture
and the release-policy registry.

## 9. Remaining release blockers / non-goals

The v1.3.1 code hardening does not waive or fake completion of the original
blocked controls. Before a production release, the project still needs, at
minimum:

1. external human-signed release approval bound to the patched candidate;
2. an actual encryption-at-rest/in-transit implementation or a formally
   verified deployment control that satisfies XSEC-04;
3. provisioned staging, production and privileged execution environments with
   their required isolation/security evidence;
4. canary/pilot evidence where required;
5. a bound production model provider plus real grounding/calibration evidence
   if the model path is to be claimed as operational;
6. live SLO measurements at intended repository scale;
7. normalized relationship metadata if historical/external records are to be
   materialized as first-class graph relations without inference.

## 10. Release recommendation

**Accept v1.3.1 as the corrected development/audit candidate. Do not label it a
production release.** Treat the immutable v1.3.0 control-plane application
report as historical baseline evidence, rerun affected release evidence against
v1.3.1, and obtain the required human release approval only after the remaining
blocked controls are actually satisfied.
