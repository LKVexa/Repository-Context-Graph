# RCG GO prompt/workflow package — execution report

**Executed:** 2026-09-06 · **Runtime:** 1.4.0 → **1.5.0** · **Verdict: PRODUCTION NO_GO.**

The owner asked the chop shop to use `COVERAGE.md` and
`RCG_GO_Prompt_Workflow_Package_v1.0.0` to finish the candidate. This report says what "finish" could
honestly mean, what was executed, and what was not.

## What could be executed

The package classifies its 62 items by what each one needs. 36 items covering 49 of the 150 plan tasks
need no host, no second accountable person, no bound model and no elapsed time. Those were the scope.
The other 26 items — 101 tasks — need three provisioned environments, a KMS and an IdP, a real external
issuer, a second person with release authority, a bound model provider, hardware at the declared scale,
and thirty real days of observation. No session produces any of those.

## Executed — 21 items, 30 plan tasks

| item | plan tasks | what changed |
|---|---|---|
| 20 | `GO-04-02` | `rcg/rollout.py`: exact boolean types, thirteen refusal cases all failing closed to disabled, strict parsing, staleness bound |
| 51 | `GO-04-01`, `GO-04-03`, `GO-04-04` | **the runtime now reads the rollout store**; authenticated `Principal` writes with compare-and-set and an exclusive lock; the model switch made independent |
| 52 | `GO-04-06`, `GO-04-07` | disablement checked at admission and four checkpoints; time-of-use re-checks for switch, scope, authority and mode ceiling; cancellation preserves partial evidence |
| 21 | `GO-04-05` | one `effective_permissions` intersection, narrowing-only, plus `check_evidence_write` |
| 22 | `GO-06-11` | seven required measurement fields; corpus/model/configuration drift makes a measurement `STALE` automatically |
| 23 | `GO-07-01` | `rcg/sli.py`: qualified-answer taxonomy, denominators, exclusion authority, percentile method, content-safe labels |
| 11 | `GO-01-01` | thirteen stored blocker strings became evidence validators; entries kept, verdicts computed |
| 12 | `GO-01-03` | `prepare-candidate` / `finalize-with-approvals` split |
| 13 | `GO-01-04` | task-ID-bound approvals enforced in the phase walk, composing with the untouched vendored validator |
| 14 | `GO-01-06` | governed non-applicability: authenticated, profile-bound, expiring, with disabled-path evidence |
| 15 | `GO-01-07` | append-only hash-chained runs; monotonic attempts; `shutil.rmtree` on a run directory removed |
| 16 | `GO-01-10` | a blocked promotion exits non-zero; reporting-only mode cannot exit 0 on a non-GO gate |
| 49 | `GO-01-08` | audit mode and release mode separated; upstream digests and authority freshness validated first |
| 50 | `GO-01-09` | results bound to re-hashed artifacts; self-referential proof refused |
| 18 | `GO-01-12` | 51 release-path regression tests, every negative asserting its reason |
| 19 | `GO-01-13` | control-plane successor v1.4.0 published with its own manifest and 14 self-tests |
| 17 | `GO-01-11` | four freshness states with distinct remediations; CI diffs into a temp tree instead of rewriting |
| 24 | `GO-08-09` | DOC-13 operator runbook and DOC-14 user guide, generated from their registries |
| 25 | `GO-10-08` (partial) | DOC-12 updated for v1.5.0; release-scope facts still pending measurement |
| 01, 02 | `GO-00-01`, `GO-00-02` | subject registered with its baseline link; historical 204/217 imported as history, not proof |
| 54–57 | `GO-01-15/16/17`, `GO-02-13`, `GO-04-11`, `GO-06-13`, `GO-07-11/12`, `GO-08-11/12` | evidence records for the mechanisms v1.4.0 built |

**32 evidence records** are under `production-evidence/RCG-20260906T0030-chopshop/`, each with all eight
required fields.

## The finding worth reading

`rcg/pipeline.py` never read the rollout store. Search v1.4.0's pipeline for `rollout`, `FlagStore` or
`flag`: no hits. The only importer of `rcg.rollout` in the whole tree was `control-plane/checks.py` —
the *checker* consulted the flag store; the *runtime* did not.

So `rcg.enabled = false` did not stop a run. `emergency_disable()` wrote a file nothing on the execution
path read. The 60-second propagation bound in `ROLLOUT.json` was measuring a switch connected to nothing.
Alongside it, `bool("false")` is `True` in Python, so a flag file containing the *string* `"false"` —
which is what a template or a YAML round-trip eventually produces — would have enabled the system.

Both are fixed and both are proven by probes rather than asserted: a disabled store now refuses at
admission with zero provider calls and no index built, and a mid-run disable cancels at the next
checkpoint with the partial evidence preserved.

## Verification

| check | result |
|---|---|
| `tests/run_all.py` (strict runner, Python 3.11.15, Linux) | **304 tests PASS** — 253 pre-existing + 51 new; 0 failures, 0 errors, 0 skips |
| `environments/ci.py`, all six stages | **CI: PASS** |
| Vendored control-plane package v1.3.0 | **byte-identical**, all 261 manifest entries verified by a test |
| Control-plane successor self-test | **14/14** |
| Documentation freshness | 14/14 `CURRENT`; planted hand-edit detected as `DRIFTED`; planted source change reported `STALE` |
| Licence gate | 7 entries, all permissive, `promotable: true` |
| Third-party runtime imports | still **zero** |
| 612-file JA21/DeepML corpus | **byte-identical** |
| `promotion_gate` | **NO_GO**, 9 blockers; bypass probe refuses 8/8 planning-only vectors |
| `python -m successor release` | exit **1** |
| `run_control_plane.py` on a blocked run | exit **1** (was **0**) |

## What did NOT move

**All thirteen original blockers remain open.** Nothing here provisions a host, authenticates a signer,
binds a model or elapses a day.

**None of the 32 evidence records carries an independent review disposition.** Every one reads
`UNASSIGNED`, because `GO-00-04` — binding the thirteen roles to real people — has not been executed, and
that is a decision only the owner can make. Their `completion_class` is
`MECHANISM_IMPLEMENTED_QUALIFICATION_PENDING`, and their status is `IMPLEMENTED_PENDING_REVIEW`. **None
of them is an accepted task.**

**The 150 issued plan tasks remain `NOT_STARTED` in the plan package, which was not edited.** That is the
plan's own rule.

Three partials worth naming rather than burying:

- `GO-02-13` is three-of-four. Schemas, docs and registry agree; deployed-host enforcement is pending
  `GO-03-02`/`GO-03-04`.
- `GO-04-07` re-checks four authority classes at time of use, but **cached graph and retrieval
  visibility is not invalidated on narrowing**. That half is open.
- `GO-08-12` is proven in a temporary directory; host qualification is pending `GO-03-05`.

Not executed at all from the reachable set: **ITEM-53** (`GO-05-04`…`GO-05-08`), because its acceptance
asks for representative *real* repositories rather than fixtures, and **ITEM-26** (`GO-03-08`), which
needs a real Windows host — the runner already reports `native_windows_tested: false` honestly.

## The honest summary

The runtime now enforces the two things it previously only described: the kill switch actually stops
runs, and the thirteen blockers compute their refusals from evidence instead of reading strings. The
control plane can no longer report a blocked promotion as success, delete its own audit trail on retry,
or validate a phase as though its approvals were optional.

That is a real improvement in what this system can prove about itself. It is not a release, it is not an
approval, and the gate will keep saying **NO_GO** until a host, a signer, a model and thirty days say
otherwise.
