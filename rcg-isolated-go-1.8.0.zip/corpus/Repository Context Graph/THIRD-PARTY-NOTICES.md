# Third-party notices

Every part in this overlay that was pulled from another repository, with its
donor, the path it landed at, and the donor's license. The license gate in
`rcg/licensing.py` reads this table (`parse_notices`) and refuses promotion on
a copyleft or unlicensed entry (AUD-013).

| Donor | Part | License | How it was used |
|---|---|---|---|
| `_YARDOFFICE/spb` (Scoped PR Builder, owner's own work, vendored in junkyard-chop-shop v0.7.3) | `rcg/parsers/extractors.py`, `rcg/indexer.py` | MIT | The JA21 declaration table, the `use`/`dmk`/`Suite_` dependency rules, the `(kind, qualified_name, line)` symbol shape and the Suite 40 snapshot-envelope fields are adapted from `adapters/repository_context_adapter.py` and `adapters/local_git_adapter.py`. Adapted, not copied verbatim: extraction was decoupled from git so it binds a directory snapshot as well as a revision; every result carries its tier and any fallback reason; block declarations get real end lines; unresolved and ambiguous outcomes are returned rather than dropped. |
| `vscode-anycode` | `rcg/incremental.py` | MIT | PATTERN ONLY — no code copied. The file-keyed invalidation idea (`symbolIndex.ts`: the unit of invalidation is the file, so a rename is delete+add at the index level) informed the change-set update. The donor is TypeScript over tree-sitter and shares no code with this implementation. |
| CPython standard library | runtime | PSF-2.0 | `ast`, `re`, `json`, `hashlib`, `subprocess`, `resource`, `unittest`. No third-party runtime dependency exists; `tests/test_supply_chain.py` asserts it. |
| `jsonschema` 4.x | `control-plane/package/tools/validate_runtime.py` | MIT | Used only by the vendored control-plane validator, pre-provisioned in the execution environment. It is never installed on demand, and the scope contract denies the `install` permission by default. |
| `_YARDOFFICE/spb` (Scoped PR Builder, owner's own work) | `rcg/effects.py`, `rcg/trustroot.py`, `rcg/promotion.py`, `rcg/observability.py`, `tests/run_all.py` | MIT | **v1.4.0.** Adapted, not copied: `adapters/approval_adapter.apply_isolated` (revalidate everything, apply, then prove the source is exactly as expected; signing key outside the run directory; receipts bound to subject digests with nonce and expiry) → `rcg/effects.py` and `rcg/trustroot.py`; `adapters/patch_generator.verify_candidate_hash` (payload bound to its own hash) → `ChangeSet.changeset_digest`; `adapters/verification_runner.JobRecord`/`VerificationReport` → the qualification report shape in `tests/run_all.py`; `adapters/qualification.require_pass` (an indeterminate or skipped mandatory scenario is never a pass) → the runner's required-suite rule; `adapters/release_gate` (receipts selected by immutable id **and** binding hash, `classify` over absent/stale/conflicting/waived, `bypass_attempt`/`assert_no_bypass`) → `rcg/promotion.py`; `adapters/observability._rate` (a rate names its denominator and is `None` over zero) → `rcg.observability.Rate`; `adapters/hard_limits.effective_caps` (composition may only narrow) → `rcg.scope.reconcile_environment`. The donor is git-worktree based and imports its own adapter stack, so the logic travelled and the code did not. |
| `_YARDOFFICE/spb` (Scoped PR Builder, owner's own work) | `control-plane/successor/runs.py`, `control-plane/successor/qualify.py`, `rcg/rollout.py` | MIT | **v1.5.0.** Adapted, not copied: `adapters/archive_adapter.py`'s hash-chained append-only ledger — chaining, genesis link and verification walk, and the property that **no update or delete method exists** — became `successor/runs.py`; `adapters/store.py`'s `_append_durable(..., expected_head=...)` compare-and-set and `_locked` serialization became the flag store's revision check and exclusive lock; `adapters/release_gate.py`'s `gate()` versus `require_go()` split became audit mode versus release mode; `adapters/documentation.py`'s generated-from-registries documents with embedded source hashes and four-state freshness became `docs/freshness.py`, DOC-13 and DOC-14, including its rule that a known gap phrased as an operational claim is refused. |
| `amplifier-bundle-attractor` (Microsoft) | `tests/run_all.py`, `rcg/pipeline.py` | MIT | **v1.4.0. PATTERN ONLY — no code copied.** `modules/loop-pipeline/amplifier_module_loop_pipeline/outcome.py`: `Outcome.is_explicit` (a `goal_gate` node whose verdict was *defaulted* rather than asserted cannot satisfy its own gate) became the runner's `verdict_explicit` rule and `RunResult.classify_outcome`; `Outcome.failed_step` (command, exit code, duration, capped stdout/stderr tails, explicit truncation flag) became the runner's diagnostics record in place of one traceback line. |

## Donor license texts

The Scoped PR Builder overlay is the owner's own work; its own
`THIRD-PARTY-NOTICES.md` in `_YARDOFFICE/spb/Scoped PR Builder/` records the
grafts it in turn carries. `vscode-anycode` ships the MIT license at its
repository root in the GitHub Junkyard; no code from it is present here, so no
license text needs to travel with this overlay.

`amplifier-bundle-attractor` is MIT (Copyright (c) Microsoft Corporation); its
LICENSE is at the repository root in the GitHub Junkyard and a copy is retained
with the work order that pulled it
(`_YARDOFFICE/work-orders/Project_Repository_Context_Graph-20260905-2045/donor-parts/`).
No code from it is present here — only the two design rules named above — so no
license text needs to travel with this overlay.

## Nothing else was pulled

The 40 top-level modules of `rcg/` (47 including the `parsers/` and
`connectors/` subpackages), the control-plane successor, the schema registry,
the ontology, the policy controls, the review surface, the evidence ledger, the
version store, the retrieval index, the evaluation corpus and the 534 tests were
written for this program. Where the yard had no part for a need, it was built new; those cases
are recorded in the work order's `build-new:` notes.
