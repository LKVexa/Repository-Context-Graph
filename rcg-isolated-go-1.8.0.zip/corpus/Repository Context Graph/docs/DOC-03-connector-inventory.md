<!-- generated-from: {"document":"DOC-03-connector-inventory.md","sources":{"registry/SUPPLY_CHAIN.json":"86e4de2695f7591b64ba4b21c65b7ca85dd6fb7036ef16dd524b22a4d0136136"}} -->
# DOC-03 — Source and connector inventory

Generated from `rcg.connectors.REGISTRY`; adding a connector updates this file.

| source system | requirement | external | permission | description |
|---|---|---|---|---|
| adrs | DATA-06 | no | read | Architecture decision records and design notes. |
| build_metadata | DATA-02 | no | read | Build and dependency manifests. |
| code_owners | DATA-08 | no | read | Code ownership declarations. |
| design_discussions | DATA-09 | yes | read | Explicitly approved design discussions. Optional; denied by default. |
| git_history | DATA-04 | no | read | Commit history for the pinned revision, when the snapshot is a git repository. |
| issue_tracker | DATA-07 | yes | read | Bug and issue records from an authorized tracker. |
| pull_requests | DATA-05 | yes | read | Change proposals and review comments from an authorized forge. |
| source_code | DATA-01 | no | read | Source files and their declared symbols, from the pinned snapshot. |
| tests | DATA-03 | no | read | Test suites, matrices and validation declarations. |

## Connector resilience mechanisms and declared gaps (AUD-010)

| rule | mechanism |
|---|---|
| pagination | `ResiliencePolicy.page_size` with a hard `max_pages`; exceeding it sets `truncated` |
| rate limits | `rate_limit_per_second` is declared configuration only; no rate limiter enforces it |
| retries | `max_retries` with exponential backoff; a credential error never retries |
| partial failures | recorded in `partial_failures`; `fail_on_partial` can propagate a collection failure |
| freshness | truncation/failure downgrades state; `freshness_max_age_seconds` is not an enforced age limit |
| tombstones | complete collection and confirmed authorized absence are required; partial/excluded paths are not deletions |
| credential expiry | detected and reported as `credential_expired`, not retried |

## Language and build-system tiers (AUD-005)

| language | profile | tier | extensions | parser | fallback | symbol confidence |
|---|---|---|---|---|---|---|
| python | python | full | .py | cpython.ast | metadata | known |
| json | json | full | .json | cpython.json | metadata | known |
| ja21 | ja.core | lexical | .ja | rcg.ja_declaration_rules | metadata | supported |
| ja21 | ja.agent | lexical | .jaa | rcg.ja_declaration_rules | metadata | supported |
| ja21 | ja.data | lexical | .jad | rcg.ja_declaration_rules | metadata | supported |
| ja21 | ja.operations | lexical | .jaops | rcg.ja_declaration_rules | metadata | supported |
| ja21 | ja.security | lexical | .jasec | rcg.ja_declaration_rules | metadata | supported |
| ja21 | ja.service | lexical | .jasp | rcg.ja_declaration_rules | metadata | supported |
| ja21 | ja.training | lexical | .jate | rcg.ja_declaration_rules | metadata | supported |
| ja21 | ja.interface | lexical | .jaui | rcg.ja_declaration_rules | metadata | supported |
| deepml | deepml | lexical | .deepml | rcg.ja_declaration_rules | metadata | supported |
| deepml_kernel | deepml.kernel | lexical | .dmk | rcg.ja_declaration_rules | metadata | supported |
| ebnf | ebnf | lexical | .ebnf | rcg.ebnf_rules | metadata | supported |
| markdown | markdown | metadata | .md | rcg.metadata_only | - | missing |
| text | text | metadata | .txt .csv | rcg.metadata_only | - | missing |
