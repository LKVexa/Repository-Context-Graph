<!-- generated-from: {"document":"DOC-14-user-guide.md","sources":{"registry/LANGUAGE_TIERS.json":"7586f76de4f451479a5f4fbc578fc9384cd645350958ce3beaa7ff8a7c4ba967","registry/SLO.json":"1991a64d23dfe984d8fa02c6e28eb515090a828efa8332498cb3d6767b679174"}} -->
# DOC-14 — User guide

Generated from `registry/LANGUAGE_TIERS.json` and `registry/SLO.json`. Do not
edit this file; edit the generator.

## What this answers

Questions about one pinned snapshot of one repository: which symbols exist, what
depends on what, what a change would touch, and what evidence supports each
answer. Every material output names the snapshot it came from.

## What it does not answer

It does not browse, fetch, or reach a network. It does not modify your
repository unless you supply a change set on an explicitly authorized privileged
path. It does not guess: two candidate identities stay two candidates, and a file
whose imports could not be parsed is reported as having an *unknown* blast
radius, never an empty one.

## Coverage

Declared language tiers: `python`, `json`, `ja21`, `ja21`, `ja21`, `ja21`, `ja21`, `ja21`, `ja21`, `ja21`, `deepml`, `deepml_kernel`.
Retrieval is lexical — BM25 over an identifier-expanded index. There is no
embedding model, so a purely semantic paraphrase may not match. That is a
property of the design, not a defect to work around.

## When it abstains

An abstention is the system declining to answer with a named missing input. It
is correct behaviour, and it is **not** a measure of answer quality: a run whose
model abstained is reported as `MODEL_ABSTAINED` and is inadmissible as
model-quality evidence.

## What you should not rely on yet

No model provider is bound; the default provider abstains on every call.
Confidence scores are withheld rather than shown, because calibration has not
been measured. No performance figure in `registry/SLO.json` has an observed
value. The system is **not production qualified** — see
[DOC-12](DOC-12-known-limitations-non-goals.md).
