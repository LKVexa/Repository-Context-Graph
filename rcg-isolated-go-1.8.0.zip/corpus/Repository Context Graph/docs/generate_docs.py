"""Generate DOC-01..14 from the live system, so documentation cannot drift.

Anything that can be read off the code -- the connector inventory, the
permission matrix, the control list, the provenance and run-state schemas, the
model/tool inventory -- is generated here rather than written by hand. What
remains hand-written (the threat model's reasoning, the runbook's judgement
calls, the non-goals) is kept in this file next to the generator so the two
stay in one place.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))

from rcg import __version__                                            # noqa: E402
from rcg.connectors import connector_inventory                         # noqa: E402
from rcg.governance import (budgets_document, lifecycle_document,      # noqa: E402
                            migrations_document, release_policy_document,
                            rollout_document, slo_document, supply_chain_document,
                            thresholds_document)
from rcg.ontology import ontology_document                             # noqa: E402
from rcg.parsers import tiers_document                                 # noqa: E402
from rcg.policy import CONTROLS, controls_document                     # noqa: E402
from rcg.reasoning import PROMPTS                                      # noqa: E402
from rcg.schemas import REGISTRY                                       # noqa: E402
from rcg.scope import MUTATING, PERMISSIONS, PRIVILEGED                          # noqa: E402
from rcg.security import RETENTION_CLASSES, Classification             # noqa: E402
from rcg.workflow import STATE_MACHINE_VERSION, TERMINAL_STATES, TRANSITIONS  # noqa: E402


def _table(headers: list[str], rows: list[list[str]]) -> str:
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join("---" for _ in headers) + "|"]
    out += ["| " + " | ".join(str(c).replace("|", r"\|") for c in row) + " |" for row in rows]
    return "\n".join(out)


def doc01_architecture() -> str:
    return f"""# DOC-01 — Architecture

Repository Context Graph for Cross-File Changes, version {__version__}.

## Layers, bottom up

```
                         +-----------------------------+
                         |  rcg.cli / rcg.pipeline     |   one governed run
                         +--------------+--------------+
                                        |
      +-----------------+---------------+---------------+------------------+
      |                 |               |               |                  |
+-----v------+   +------v-----+  +------v------+ +------v-------+  +-------v------+
| connectors |   |  parsers   |  |  analysis   | |  reasoning   |  |    review    |
| ARCH-01    |   |  COMP-01   |  |  ARCH-05    | |  ARCH-06     |  |  ARCH-09     |
| DATA-01..09|   |  AUD-005   |  |  XTOOL-01   | |  MODEL-01..07|  |  HUMAN-01..07|
+-----+------+   +------+-----+  +------+------+ +------+-------+  +-------+------+
      |                 |               |               |                  |
      +--------+--------+               |               |                  |
               |                        |               |                  |
        +------v-------+                |               |                  |
        |   indexer    |                |               |                  |
        |  PAPER-CAP-01|                |               |                  |
        +------+-------+                |               |                  |
               |                        |               |                  |
        +------v-------+   +------------v----+  +-------v--------+ +-------v------+
        |    graph     |-->|  query / impact |  |  uncertainty   | |    policy    |
        |  COMP-02/04  |   |  COMP-07/09     |  |  XUNC-01..06   | |  ARCH-07     |
        +------+-------+   +--------+--------+  +-------+--------+ +-------+------+
               |                    |                   |                 |
        +------v--------------------v-------------------v-----------------v------+
        |   scope (IMPL-01, XAUTH-*)  |  provenance ledger (ARCH-08, XPROV-*)     |
        |   authority (FLOW-01)       |  version store (COMP-03, ARCH-03)         |
        |   security (SEC-*, XSEC-*)  |  observability (ARCH-10, XOBS-*)          |
        +---------------------------------------------------------------------+
```

## The one-way rules

1. Nothing above the scope layer decides its own permissions. Every effect
   calls `ScopeContract.check` at the moment of the effect.
2. Deterministic analysis completes before the reasoning layer is called. The
   reasoning layer receives analyzer output as established fact.
3. No path reaches `APPLYING` without passing `APPROVED`. This is a property of
   the transition table, not a runtime check.
4. The reasoning layer has no handle on the ledger, the policy layer, or the
   scope contract's mutators.

## Modules

{_table(["module", "responsibility", "primary requirements"], [
    ["rcg.scope", "Scope contract, permission separation, path confinement", "IMPL-01, XAUTH-02..06"],
    ["rcg.authority", "Identity, authentication, credential leases, recorded authority", "FLOW-01, XAUTH-01/05/07"],
    ["rcg.schemas", "Canonical contracts and total validation", "IMPL-02, API-01..08"],
    ["rcg.workflow", "Versioned state machine", "IMPL-03, XSTATE-03"],
    ["rcg.connectors", "Authorized source ingestion with resilience", "ARCH-01, DATA-01..09, AUD-010"],
    ["rcg.parsers", "Language tiers, symbol and dependency extraction", "COMP-01, AUD-005"],
    ["rcg.indexer", "Snapshot binding and two-pass graph ingestion", "PAPER-CAP-01, FLOW-02/04"],
    ["rcg.graph", "Ontology-checked graph with entity resolution", "COMP-02, COMP-04, ARCH-02"],
    ["rcg.versionstore", "Temporal store, CAS, backup/restore, retention", "COMP-03, ARCH-03, STORE-*"],
    ["rcg.query", "Revision-aware bounded queries", "COMP-07, ARCH-04, VERIFY-05"],
    ["rcg.retrieval", "Labeled retrieval with stale demotion", "COMP-05, XTOOL-05, MODEL-03"],
    ["rcg.rationale", "Historical rationale extraction", "COMP-06, PAPER-CAP-03"],
    ["rcg.incremental", "Change-set update and freshness comparison", "COMP-08, PAPER-CAP-02, VERIFY-02"],
    ["rcg.impact", "Direct and transitive impact before drafting", "COMP-09, PAPER-CAP-04, VERIFY-03"],
    ["rcg.analysis", "Deterministic analyzers, run first", "ARCH-05, FLOW-05, XTOOL-01"],
    ["rcg.reasoning", "Bounded model orchestration", "ARCH-06, MODEL-01..07"],
    ["rcg.uncertainty", "Seven-state uncertainty, abstention, calibration", "IMPL-07, XUNC-01..06"],
    ["rcg.intent", "Deterministic request classification", "FLOW-07, XUNC-01"],
    ["rcg.policy", "Guardrails as executable controls", "ARCH-07, IMPL-06, PAPER-GRD-01..04"],
    ["rcg.review", "Review package and approval gate", "ARCH-09, IMPL-08, HUMAN-*, XHITL-*"],
    ["rcg.security", "Classification, redaction, injection defence, tenancy", "SEC-*, XSEC-*"],
    ["rcg.sandbox", "Confined execution of untrusted code", "XTOOL-03, ENV-05"],
    ["rcg.provenance", "Hash-chained evidence and audit ledger", "ARCH-08, XPROV-*, STORE-07"],
    ["rcg.observability", "Logs, metrics, traces, alerts, scoring", "ARCH-10, XOBS-*, IMPL-09"],
    ["rcg.governance", "Requirement, owner, SLO, budget, rollout registries", "AUD-001..018"],
    ["rcg.pipeline", "The end-to-end governed run", "FLOW-01..12"],
])}
"""


def doc02_dataflow() -> str:
    return f"""# DOC-02 — Data flow and trust boundaries

## Trust zones

```
  ZONE U (untrusted)                ZONE C (controlled)              ZONE T (trusted)
  ------------------                -------------------              ----------------
  repository bytes                  parsers (no eval)                scope contract
  commit messages                   retrieval index                  authority record
  PR / issue text                   graph + provenance               policy controls
  generated logs         --->       analyzers               --->     approval gate
  model output                      reasoning layer                  evidence ledger
                                    (schema-validated)               version store

  Everything in ZONE U is DATA. It is hashed, labeled and stored. It never
  becomes an instruction, a permission, or an approval.
```

## The flow, and where each boundary is enforced

{_table(["#", "step", "boundary crossed", "enforced by"], [
    ["1", "Operator states a request", "-> ZONE C", "rcg.intent.classify_request (lexical, no model)"],
    ["2", "Authority is checked", "ZONE T", "AuthorityRecord.covers + ScopeContract.check"],
    ["3", "Snapshot is pinned", "U -> C", "bind_snapshot; digests over exact bytes"],
    ["4", "Connectors read", "U -> C", "Connector.collect: scope check, then bounded read"],
    ["5", "Files are parsed", "inside C", "parsers: regex/AST only; repository code is never executed"],
    ["6", "Graph is written", "inside C", "ontology validation + mandatory provenance"],
    ["7", "Analyzers run", "inside C", "pure functions of the snapshot"],
    ["8", "Retrieval selects passages", "C -> C", "scope-filtered; every passage carries its label"],
    ["9", "Model is called", "C -> U(model) -> C", "labeled context only; output schema-validated"],
    ["10", "Policy evaluates", "ZONE T", "rcg.policy.evaluate; model output is an input, never a verdict"],
    ["11", "Review package is built", "C -> human", "subject digest binds exactly what was shown"],
    ["12", "Human decides", "human -> T", "authenticated human principal only"],
    ["13", "Apply or roll back", "T -> U(worktree)", "scope.check('modify', path=...) per path"],
])}

## What crosses, and what never crosses

- **Never leaves ZONE C:** secrets (classified and redacted at ingestion), host
  environment variables (scrubbed before sandboxed execution), the ledger
  handle.
- **Never enters ZONE T:** repository text, model output, retrieved passages.
  These can inform a human decision; they cannot be one.
- **Crosses U -> C only with a hash:** every artifact carries `source_hash`
  computed over the exact bytes read.
"""


def doc03_connectors() -> str:
    inventory = connector_inventory()
    return f"""# DOC-03 — Source and connector inventory

Generated from `rcg.connectors.REGISTRY`; adding a connector updates this file.

{_table(["source system", "requirement", "external", "permission", "description"],
        [[c["source_system"], c["requirement_id"], "yes" if c["external"] else "no",
          c["required_permission"], c["description"]] for c in inventory])}

## Connector resilience mechanisms and declared gaps (AUD-010)

{_table(["rule", "mechanism"], [
    ["pagination", "`ResiliencePolicy.page_size` with a hard `max_pages`; exceeding it sets `truncated`"],
    ["rate limits", "`rate_limit_per_second` is declared configuration only; no rate limiter enforces it"],
    ["retries", "`max_retries` with exponential backoff; a credential error never retries"],
    ["partial failures", "recorded in `partial_failures`; `fail_on_partial` can propagate a collection failure"],
    ["freshness", "truncation/failure downgrades state; `freshness_max_age_seconds` is not an enforced age limit"],
    ["tombstones", "complete collection and confirmed authorized absence are required; partial/excluded paths are not deletions"],
    ["credential expiry", "detected and reported as `credential_expired`, not retried"],
])}

## Language and build-system tiers (AUD-005)

{_table(["language", "profile", "tier", "extensions", "parser", "fallback", "symbol confidence"],
        [[t["language"], t["profile"], t["tier"], " ".join(t["extensions"]), t["parser"],
          t["fallback_tier"] or "-", t["symbol_confidence"]]
         for t in tiers_document()["languages"]])}
"""


def doc04_permissions() -> str:
    rows = [[p, "yes" if p in PRIVILEGED else "no", "yes" if p in MUTATING else "no",
             {"read": "Read authorized artifacts.",
              "analyze": "Run deterministic analyzers and queries.",
              "draft": "Produce a draft that is not written anywhere.",
              "modify": "Write inside the authorized paths of the worktree.",
              "commit": "Create a commit.", "push": "Push to a remote.",
              "approve": "Record an approval decision.", "deploy": "Deploy or release.",
              "communicate": "Send an external message.",
              "install": "Install a package.", "network_read": "Read from a named external system.",
              "network_write": "Write to a named external system.",
              "credential_use": "Use a stored credential.",
              "write_evidence": "Write this run's own evidence into the authorized evidence "
                                "root. Confined by check_evidence_write and explicitly NOT a "
                                "route to modifying the target repository."}[p]] for p in PERMISSIONS]
    return f"""# DOC-04 — Permission matrix

Permissions form a lattice with no implication: holding one never grants
another (XAUTH-03). Everything marked privileged is denied unless explicitly
granted for the run.

Since v1.4.0 the privileged set is split (GO-02-13). **Mutating** permissions
can change something outside this process -- repository bytes, a remote system,
a deployment, a human channel, installed software. `network_read` is privileged
(never implied, always explicit) but not mutating: reading a named,
pre-authorized external source changes nothing.

{_table(["permission", "privileged", "mutating", "meaning"], rows)}

`network_read` and `network_write` are *system-bound*: holding the permission is
not authority to reach anything. `ScopeContract.check` refuses either without a
named `external_system` on the contract's allowlist.

## Mode constraints

The single authority on this relationship is `rcg.scope.mode_admits`. The
contract constructor and `rcg.scope.reconcile_environments` both call it, so a
profile the environment registry declares can never be one the contract refuses
to build -- which is exactly what ENV-03 and ENV-04 were before v1.4.0.

{_table(["mode", "may hold"], [
    ["read_only", "read, analyze. `draft` and every mutating permission are rejected at construction. `network_read` only with a non-empty `authorized_external_systems` allowlist and without `credential_use`."],
    ["draft_only", "read, analyze, draft. Every mutating permission is rejected at construction. `network_read` under the same two conditions."],
    ["modify", "as granted; each privileged permission still has to be listed explicitly."],
])}

Narrowing a contract that no longer holds a mutating permission drops it to the
narrowest mode its remaining permissions justify.

## Enforceable controls (IMPL-06, PROD-01)

{_table(["control", "requirement", "stop condition"],
        [[c.control_id, c.requirement_id, c.stop_condition] for c in CONTROLS])}

## Who may do what

{_table(["actor kind", "may read", "may analyze", "may draft", "may approve", "may attest"], [
    ["human", "yes", "yes", "yes", "yes", "yes"],
    ["service", "yes", "yes", "yes", "no", "no"],
    ["model", "only labeled context", "no", "proposes only", "no", "no"],
])}
"""


def doc05_threat_model() -> str:
    return """# DOC-05 — Threat model

## Assumption

Everything the system reads is attacker-controlled. A repository file, a commit
message, an issue body, a generated log and a model completion are all
untrusted input. The defence is structural, not detective: no control anywhere
reads its verdict from text.

## Threats, controls, and residual risk

| # | Threat | Control | Residual risk |
|---|--------|---------|---------------|
| T1 | Prompt injection in repository content | Retrieved text enters only as labeled context; the prompt states that context is data; no code path turns text into a permission | Detection is best-effort; a novel phrasing may not be *flagged*, but still cannot *act* |
| T2 | Model fabricates an approval | Approval requires an authenticated human principal; `assert_not_self_attested` rejects non-human; `CTRL-AUTH-01` denies model-asserted approval | None known within the process boundary; a compromised IdP defeats it |
| T3 | Model grants itself permissions | `CTRL-AUTH-01`; the scope contract is immutable within a run and narrowing cannot widen | None known |
| T4 | Secret exfiltration through evidence or logs | Classification before use; redaction; findings carry digests not excerpts; sandbox scrubs the environment | A secret in an unrecognized format is not matched by the pattern set |
| T5 | Path traversal / symlink escape | Canonicalize-then-contain, resolution before the containment test; denied paths win | Race between resolve and open on a hostile filesystem (TOCTOU) |
| T6 | Cross-tenant data leakage | `assert_no_cross_tenant`; repository id is an identity field on every node | A deployment that reuses one repository id for two tenants defeats it |
| T7 | Untrusted code execution during indexing | Parsers use regex and `ast` only; nothing is imported or evaluated; the sandbox is a separate process with rlimits and a scrubbed environment | Host without namespaces gets process-level isolation only, and the enforcement report says so |
| T8 | Unauthorized write | Permission separation; per-path check at the moment of the write; `ALERT-WRITE-01` | None known within the process boundary |
| T9 | Evidence tampering | Hash-chained ledger with per-event detail digests; append-only API; the model never receives a ledger handle | An attacker with filesystem write can truncate/rebuild a valid chain; detection needs a separately trusted head/count, which local chain verification alone does not supply |
| T10 | Stale context presented as current | Freshness compares identities, never timestamps; stale results are demoted and qualified; `INVALID` refuses queries outright | A consumer that ignores the `freshness` field |
| T11 | Oversized or unreviewable change | `CTRL-GRD-02` structural threshold, `CTRL-GRD-04` diff limit | Thresholds are policy, not proof |
| T12 | Supply-chain compromise of a parser | Zero third-party runtime dependencies; parser identity recorded with every derived fact | Compromise of the Python standard library or interpreter |

## Explicitly out of scope

- Publisher authenticity of the control-plane package. In-package hashes prove
  consistency against supplied bytes, not who supplied them.
- Encryption at rest and in transit. This package stores plaintext on the local
  filesystem and makes no network calls; XSEC-04 is delegated to the host and
  is **not** satisfied here.
- Denial of service against the host.
"""


def doc06_model_tool_inventory() -> str:
    prompts = [[p.prompt_id, p.version, p.digest[:23] + "…"] for p in PROMPTS.values()]
    return f"""# DOC-06 — Model and tool inventory

## Models

| model | version | provider | status |
|---|---|---|---|
| none | 0 | `rcg.abstaining` | Default. No authorized model provider is configured; every reasoning call abstains with a stated reason. |

A deployment binds a real provider by implementing `rcg.reasoning.ModelProvider`
and pinning `ModelIdentity`. The identity, prompt id/version and decoding digest
are recorded on every output (MODEL-01, XTOOL-06).

## Prompts

{_table(["prompt id", "version", "digest"], prompts)}

Prompts are pinned per run. A prompt change is a breaking version change under
`RELEASE_POLICY.json` and invalidates evidence bound to the old version.

## Deterministic analyzers

| analyzer | version | deterministic |
|---|---|---|
| index_coverage | 1.0.0 | yes |
| unresolved_dependencies | 1.0.0 | yes |
| ambiguous_symbols | 1.0.0 | yes |
| dependency_cycles | 1.0.0 | yes |
| parser_fallbacks | 1.0.0 | yes |
| orphan_declarations | 1.0.0 | yes |
| untrusted_content | 1.0.0 | yes |

## Parsers

See DOC-03. Every derived fact records `analyzer` as `<parser>/<version>`.

## Runtime dependencies

{_table(["name", "version", "source", "rationale"],
        [[d["name"], d["version"], d["source"], d["rationale"]]
         for d in supply_chain_document()["runtime_dependencies"]])}
"""


def doc07_provenance_schema() -> str:
    ontology = ontology_document()
    return f"""# DOC-07 — Provenance schema

## Mandatory fields on every node and edge

{_table(["field", "meaning"], [
    ["source_system", "Which connector admitted the fact."],
    ["artifact_id", "Stable identity of the artifact it came from."],
    ["revision", "The pinned revision the fact was read at."],
    ["source_hash", "sha256 over the exact bytes the fact came from."],
    ["derivation", "`source` | `deterministic_analyzer` | `model_inference`. Never merged."],
    ["analyzer", "Parser/model identity and version. Required when derivation is not `source`."],
    ["observed_at", "When the fact was admitted. Excluded from the logical digest."],
    ["confidence", " | ".join(ontology["confidence_states"])],
    ["evidence_refs", "At least one immutable reference. A fact with none is rejected."],
])}

## Identity rule

{ontology["identity_rule"]}

## Rename, move and delete

{_table(["event", "semantics"],
        [[k, v] for k, v in ontology["rename_move_delete_semantics"].items()])}

## Evidence ledger

Append-only JSONL. Each event binds `previous_digest` = sha256 of the previous
event object, and `detail_digest` = digest of its own detail payload. `verify()`
re-walks the chain and names the first break by sequence number. There is no
update or delete path; the model-facing surface never receives a ledger handle
(SEC-08).

## Case file (XPROV-07)

`EvidenceLedger.export_case_file` writes a self-contained bundle: chain status,
head digest, the three derivation classes separated, every event, and the scope
digest and baseline revision it was exported against.
"""


def doc08_run_state_schema() -> str:
    rows = []
    for state, table in TRANSITIONS.items():
        for event, target in sorted(table.items()):
            rows.append([state, event, target])
    return f"""# DOC-08 — Run-state schema

State machine version {STATE_MACHINE_VERSION}.

## Transitions

{_table(["from", "event", "to"], rows)}

## Terminal states

{", ".join(f"`{s}`" for s in sorted(TERMINAL_STATES))} — these have no outgoing
transitions, so a rejected or rolled-back run cannot be resurrected.

## Structural guarantees

- `APPLYING` is unreachable without firing `approve`
  (`WorkflowMachine.reachable_without('approve', 'APPLYING')` is `False`, asserted
  by `tests/test_unit.py`).
- `approve`, `reject`, `narrow_scope` and `request_more_evidence` require
  `actor_kind == "human"`.
- Every transition is recorded to the evidence ledger with the authority under
  which it occurred, so an interrupted run reconstructs from the ledger alone
  (XSTATE-03).
- `idempotency_key` makes a retried step a no-op that returns the state the
  first call produced (API-06).

## Contracts

{_table(["schema id", "version"], [[k, v.version] for k, v in sorted(REGISTRY.items())])}
"""


def doc09_approval_policy() -> str:
    return """# DOC-09 — Human approval policy

## The gate

Admitted runs that reach review enter `AWAITING_REVIEW`; denied, failed or cancelled
runs can terminate earlier. Application still requires a matching approval.
The reviewer receives a review package
that shows what was analyzed, **what was not analyzed**, every statement with
its citations, the impact report, the uncertainty state with its missing
context, the change surface, the policy verdict, and a measured review burden.

## Who may decide

Only an authenticated **human** principal. A service principal is refused by
`assert_not_self_attested`; a model has no principal at all. Final
accountability is stated on every package and every decision record and is
never represented as belonging to the system (HUMAN-07).

## What a decision binds

A decision records `subject_digest` — sha256 over the canonical bytes of the
exact package the reviewer saw — plus `approved_scope_digest` and the run id.
`ApprovalGate.authorizes` re-checks all three. Any change to the package after
approval changes its digest, and the approval stops authorizing anything
(material change invalidates approval).

## The five decisions (XHITL-03)

| decision | effect |
|---|---|
| `approve` | The only decision that authorizes the next state change. |
| `reject` | Terminal. No side effect beyond the audit record (HUMAN-04). |
| `edit` | The reviewer's edit becomes a new package with a new digest. |
| `narrow_scope` | Returns to collection under a strictly narrower contract. Narrowing can only remove; an attempt to widen raises. |
| `request_more_evidence` | Returns to collection with the reviewer's evidence request recorded. |

## What an approval never grants

An approval authorizes the state change it was bound to. It does not grant
`commit`, `push`, `deploy`, `communicate`, or any other permission the scope
contract did not already hold. Phase or release success never grants a
separately denied side effect.
"""


def doc10_evaluation_plan() -> str:
    sys.path.insert(0, str(ROOT / "eval"))
    sys.path.insert(0, str(ROOT / "fixtures"))
    from corpus import corpus_document
    from build_fixtures import FIXTURE_NAMES
    corpus = corpus_document()
    return f"""# DOC-10 — Evaluation plan and benchmark corpus

## Corpus

{corpus["case_count"]} cases across {len(corpus["families"])} families, over
{len(FIXTURE_NAMES)} generated golden repositories.

{_table(["family", "cases", "what it probes"], [
    ["golden", str(corpus["families"].get("golden", 0)), "Ordinary questions with a known correct answer."],
    ["incomplete", str(corpus["families"].get("incomplete", 0)), "Required context is absent; the system must say so."],
    ["ambiguous", str(corpus["families"].get("ambiguous", 0)), "Several valid answers; ambiguity must be preserved."],
    ["stale", str(corpus["families"].get("stale", 0)), "Context is no longer current; results must be qualified."],
    ["out_of_scope", str(corpus["families"].get("out_of_scope", 0)), "The request exceeds the contract."],
    ["oversized_scope", str(corpus["families"].get("oversized_scope", 0)), "The change exceeds the structural threshold."],
    ["adversarial", str(corpus["families"].get("adversarial", 0)), "Injection, fabricated approval, planted secrets."],
])}

{corpus["abstention_cases"]} of {corpus["case_count"]} cases have "abstain" as
the ground-truth answer, so a system that answers everything scores badly.

## Golden fixtures (AUD-016)

| fixture | property isolated |
|---|---|
| mono_repo | many suites in one root, cross-suite references |
| polyglot_repo | four languages across three parser tiers |
| generated_code_repo | generated and vendored files |
| dependency_cycle_repo | a real 3-node import cycle |
| rename_repo | a rename between two revisions |
| large_history_repo | 50 revisions over one path |
| partial_metadata_repo | broken manifest, unparseable source, missing target |
| adversarial_repo | injection, fabricated approval, three secrets |
| git_history_repo | real git history, so DATA-04 runs against actual revisions |

## Metrics

{_table(["metric", "definition", "threshold"], [
    ["grounding rate", "cases with zero uncited claims and zero forbidden claims", f"≥ {thresholds_document()['acceptance']['grounding_precision_min']}"],
    ["abstention accuracy", "abstained exactly when ground truth says abstain", "FP and FN both reported"],
    ["false positive rate", "confident answer where ground truth is abstain", f"≤ {thresholds_document()['acceptance']['false_positive_rate_max']}"],
    ["false negative rate", "abstained where a correct answer existed", f"≤ {thresholds_document()['acceptance']['false_negative_rate_max']}"],
    ["guardrail bypass", "any adversarial/out-of-scope case that got through", f"= {thresholds_document()['acceptance']['guardrail_bypass_success_max']} (no tolerance)"],
    ["review burden", "statements + missing context + policy reasons per case", f"≤ {thresholds_document()['acceptance']['review_burden_score_max']}"],
])}

## Running it

```
python3 eval/harness.py            # exits non-zero if any case fails
python3 -m rcg.cli evaluate
```

## Honest limitation

With no authorized model provider configured, the reasoning layer abstains on
every case. The harness reports `model_exercised: false` and states that model
grounding is **not** measured by such a run. Only the deterministic half of the
system is under test until a provider is bound.
"""


def doc11_runbook() -> str:
    return """# DOC-11 — Incident and rollback runbook

## Emergency disable

Use the configured rollout store's emergency-disable operation with an authorized
operator principal. With no configured store, a local run has no deployment
switch. Disabled admission and cancellation checkpoints stop further work;
revocation is also checked before application and before each write. This package
does not supply a running queue service. The 60-second propagation value is an
unmeasured deployment target, not a measured bound.

Read the actual terminal state and effect record. A refusal before writing is
DENIED or a cancellation; successful verified restoration is ROLLED_BACK; an
incomplete restoration is ABORTED with an INCOMPLETE effect. Preserve the ledger
and investigate unresolved paths. Do not infer that cancellation means rollback.

## Symptom → action

| Symptom | Immediate action | Then |
|---|---|---|
| `ALERT-WRITE-01` (denied write attempt) | Disable. The run tried something outside its contract. | Read the ledger events around the alert; the denied action and its authority are both recorded. |
| `ALERT-SELFAPP-01` (non-human approval attempt) | Disable and treat as a security incident. | Verify the IdP binding; a service principal reached an approval path. |
| `ALERT-EXT-01` (unauthorized external system) | Disable. | Check `authorized_external_systems` on the contract that was in force. |
| `ALERT-DENY-01` (denial rate > 20%) | No disable. | Usually a mis-scoped contract, not an attack. Compare the run's requests against its authorized paths. |
| Ledger `verify()` fails | Freeze the evidence directory; do not write. | The failure names the sequence number of the first break. Preserve the original bytes for investigation; a chain check alone does not establish publisher identity. |
| Store `verify()` reports problems | Restore from the most recent verified backup. | `VersionStore.restore` refuses a backup without a manifest and re-verifies after copying. |
| Query results look wrong | Check `freshness` on the result. | A `STALE` or `PARTIAL` result is not a bug; it is the contract working. |

## Rollback

The effect transaction retains preimage bytes in memory and tracks paths actually
written. On a caught failure it attempts restoration of each written path and
records verified restoration or incomplete recovery. This is in-process recovery,
not a durable transaction journal or crash-safe filesystem snapshot.

A snapshot **digest cannot reconstruct bytes**. After a process/host failure:

1. Preserve the result, effect record, ledger and current files; inspect applied,
   restored and unresolved paths before making another change.
2. Recover original bytes only from an actual verified backup or separately
   preserved checkout/preimages. Check their hashes and protect concurrent user edits.
3. Verify file contents and record the recovery outcome. A workflow transition or
   a hash alone is not proof that restoration happened.

The runtime does not implement repository reset/clean/forced checkout. The separate
fixture builder replaces only recognized disposable fixture trees; it is not a
repository recovery tool.

## Restoring the store

```
python3 -c "from rcg.versionstore import VersionStore; VersionStore.restore('<backup>', '<dest>')"
```

Restore fails closed: a backup with no manifest is refused, and the restored
store is verified before it is returned.

## What to collect for an incident report

- The case file: `EvidenceLedger.export_case_file` (chain status, every event,
  the three derivation classes separated).
- The run result document, including `metrics`, `trace` and `alerts`.
- The scope contract and its digest.
- The review package and decision record, if the run reached the gate.
"""


def doc12_limitations() -> str:
    return ("""# DOC-12 — Known limitations and non-goals

## Production status (runtime {VERSION})

**This runtime is PRODUCTION NO_GO. The {VERSION} efficacy audit repairs implementation
defects and claim accuracy; it does not supply production qualification.** `rcg.promotion.promotion_gate` is the executable statement of
it: with the evidence that exists today it returns `NO_GO` and enumerates the
blockers. All thirteen original blockers remain open — PROD-01..08 (no
authenticated human release authority has approved anything), XSEC-04
(encryption is delegated to the host), ENV-03/04/05 (declared, reconciled with
the permission lattice, **not provisioned**) and XEVAL-06 (no pilot has run).

What v1.4.0 closed was four runtime defects and six qualification-tooling gaps.
What v1.5.0 adds is the executable half of R01 and R04: the master rollout
switch is now read by the runtime (before v1.5.0 nothing on the execution path
consulted it, so `rcg.enabled = false` did not stop a run); flag writes require
an authenticated principal and a revision check; the thirteen declared blockers
dispatch to evidence validators instead of stored strings; runs and attempts are
append-only and restart-safe; and a blocked promotion exits non-zero.

All of that is *mechanism*. A mechanism that refuses correctly is not a
requirement that has been met, and none of these tasks has an independent review
disposition, because no second accountable person has been named.

Specifically **not** established by anything in this package: real signer
identity, a provisioned environment of any kind, native-Windows qualification,
live model quality, actual elapsed observation windows, real repository
modification against production data, or promotion authority.

## Limitations of this implementation

1. **No model provider is bound.** The default provider abstains on every call.
   Local tests exercise selected deterministic paths; they are not exhaustive. The model
   half is not exercised, and its grounding rate is unmeasured.
2. **Encryption is not implemented.** XSEC-04 (encrypt in transit and at rest)
   is delegated to the host filesystem and transport. This package writes
   plaintext locally and makes no network calls. It is not satisfied here.
3. **The sandbox is process-level.** On a host without namespace or seccomp
   support, isolation is a separate process, a scrubbed environment, rlimits
   and a wall-clock limit. `SandboxResult.enforcement` reports exactly what was
   applied; no evidence claims a kernel sandbox that was not available.
4. **Injection detection is best-effort.** The pattern set catches common
   phrasings. The guarantee is structural — text cannot act — not detective.
5. **History and tracker connectors need real sources.** Against a snapshot
   with no git history and no authorized tracker, they return zero artifacts
   and a `missing` freshness state. Rationale extraction then reports `missing`
   rather than inferring intent from the code.
6. **The trust root ships no signature algorithm.** `rcg.trustroot` verifies
   with a built-in `hmac-sha256` that exists so the negative tests have
   something to be negative about; it is marked `production_acceptable: false`
   and can never be marked otherwise. A deployment with a real asymmetric root
   registers its own verifier. Passing verification here is contract
   qualification, never production signer acceptance.
7. **Observation windows have a mechanism and no data.** `rcg.promotion`
   freezes a subject, and invalidates a window on subject drift, clock
   rollback, telemetry gap or expired authority — and no window has been
   opened. The 14-day canary and 30-day availability window are real elapsed
   time that no code can supply.
8. **Every SLO and acceptance threshold currently reads INSUFFICIENT_DATA.**
   All fifteen are typed and reported; none has a measurement. `slo_report`
   refuses to call an unmeasured metric met.
9. **Retrieval is lexical.** BM25 over an identifier-expanded inverted index.
   There is no embedding model, which keeps retrieval reproducible for a pinned
   revision but means a purely semantic paraphrase may not match.
10. **Calibration is unpopulated.** `XUNC-02` is implemented — an uncalibrated
    score is *withheld* rather than shown — but no calibration has been measured,
    so numeric confidence is never displayed.
11. **SLO targets are unmeasured.** `SLO.json` states targets; the `observed`
    column is empty until a benchmark runs against a real corpus at scale.
12. **Owners are roles, not people.** `OWNERS.json` proves every requirement has
    exactly one accountable owner and reviewer role; binding a role to a person
    is a deployment concern.
13. **The rollout bound is a target, not a measurement.** `ROLLOUT.json` declares
    a 60-second emergency-disable propagation bound. Since v1.5.0 the runtime
    honours the switch, but the bound has never been measured on a real service
    because no service exists (`GO-08-03`).
14. **Retention and deletion across derived data is not implemented.** Deleting a
    source removes it from the next index build; it does not remove derived
    artifacts from prior runs (`GO-02-10`).
15. **Publisher authenticity is out of reach.** In-package hashes establish
    consistency against supplied bytes. Who supplied them requires a signature
    mechanism this package does not provide, and `rcg.trustroot` deliberately
    anchors outside it rather than pretending otherwise.
16. **The subject digest excludes two declared things, and a reviewer should read
    both declarations.** An exclusion is a statement about what the digest does
    *not* prove. `rcg.subject.NON_REPRODUCIBLE` holds exactly one path:
    `fixtures/golden/git_history_repo/.git/index`, git's stat cache, whose bytes
    differ after every checkout and rebuild even when tracked content is
    identical. Everything else in that fixture repository — commit objects, refs,
    tree objects — stays inside the digest, so a real change to fixture history is
    still a subject change. `rcg.subject.NON_SUBJECT_TREES` holds
    `production-evidence/`, which records evidence *about* the subject: a receipt
    names the subject digest, so folding receipts into that digest would mean no
    receipt could ever match the subject it describes. That is the tree-level form
    of the self-referential proof `successor.results.bind_result` already refuses.
17. **The evidence intake exists; the evidence does not.** Before v1.6.0 nothing
    read a receipt from disk, so every condition was evaluated against a permanent
    empty set and no amount of external provisioning could have changed a verdict.
    `rcg.intake` closes that, and `rcg.bindings` declares the five external facts
    this package cannot supply — KMS, identity provider, attestation issuer, model
    provider, host — each as a slot with **no default occupant**. Every slot is
    `UNCONFIGURED` in this delivery, so the intake currently accepts nothing that
    could satisfy anything. What changed is the *reason*: a condition with no
    evidence reads `ABSENT`, and one with well-formed evidence and no trust root
    reads `UNATTESTED`. The second names the next action; the first was a dead end.
18. **The release desk is empty, and that is the honest state.**
    `rcg.release_authority` declares thirteen roles, five of them accountable, and
    enforces the two-person rule, separation of duties and expiring authority. None
    is bound, because binding a role requires an authenticated principal and
    `GO-00-04` — naming real people — is a decision only the operator can make. A
    desk that named its own approvers would be recording an approval attributed to
    someone who never held a key.

19. **Before v1.7.0 the evidence path could be satisfied by a synthetic signer.**
    The v1.3.0 prompt/workflow package's contract probes showed it: a nonproduction
    HMAC root with the right audience string took `successor.qualify.release` to
    GO; one subject-level attestation stood for 47 receipts; a zero-duration,
    zero-sample window read valid; two approvals satisfied a five-role desk and a
    later unrelated approval cleared a privacy REJECT. All four are reproduced as
    negative tests in `tests/test_wg_hardening.py` and now refuse. What is
    enforced: the verifier registry is a sealed `frozenset` and any change after
    sealing revokes all acceptance; an attestation binds receipt id, condition,
    kind and verdict inside the signed bytes; windows cannot be constructed below
    the 14-day canary / 30-day availability floors and need continuous samples;
    every accountable role must approve and a refusal persists until that same
    role resolves it; a PASS label needs a substantive per-kind payload naming
    its raw artifact. The genuine positive still exists — with every input real
    the gate says GO — and a truth table proves each single omission is NO_GO.
20. **Sixteen inherited evidence records are quarantined.** `successor/requalify.py`
    found 15 records whose named artifacts have since changed and one naming
    none. They are not deleted or edited; `production-evidence/QUARANTINE.json`
    lists them and each carries a `REQUALIFICATION.json`. They describe history,
    not the current tree, and nothing in the release path reads them as receipts.


## Efficacy boundaries confirmed by the {VERSION} audit

- The collector reads the live directory. A revision label does not make collection atomic; use an immutable checkout when coherent multi-file snapshots are required.
- Python uses static AST declarations/imports and repository-relative module names. Dynamic import paths, runtime dispatch, re-exports, call graphs and complete language semantics are outside current coverage. JA-family extraction is lexical, not a compiler.
- The updater fully rebuilds changed snapshots. Only an unchanged snapshot reuses its index; work counters disclose this. Selective reparsing and automatic rename continuity are not implemented.
- The ontology is larger than graph ingestion. Build/test/ADR/ownership connectors mostly admit file bytes; complete build dependencies, coverage, ownership and governance relations are not supplied. Pathless history and tracker evidence contributes to snapshot identity and retrieval, not corresponding graph entities.
- Cycle output contains bounded representative DFS witnesses, not every elementary cycle.
- Connector rate-limit and freshness-age fields are declarations, not enforced controls. Truncation/failure signals do downgrade coverage, and tombstones require confirmed absence.
- The rollout store is optional for local demonstrations. Deployment switch enforcement requires configuring it. Synthetic/local identity helpers do not prove deployment identity.
- The offline evaluation exercises selected components, not every `Pipeline.run` path. Empty or missing-fixture evaluations fail; no-provider grounding remains unmeasured. Small-corpus benchmark timings cannot qualify larger scale targets.

## Non-goals

- The system does not commit, push, open pull requests, deploy, release,
  publish, or communicate. Those permissions exist in the lattice so they can be
  **denied**; nothing in this package implements them.
- It does not mutate repository state during indexing: no fetch, pull,
  checkout, merge, reset, or configuration change.
- It does not resolve ambiguity by heuristic. Two candidates stay two
  candidates.
- It does not replace human review. It makes review cheaper and more honest;
  the decision, and the accountability, stay with a person.
- It is not a general code-search engine. Everything is scoped to one pinned
  snapshot under one contract.
""").replace("{VERSION}", __version__)


def doc13_operator_runbook() -> str:
    """GO-08-09: an operator runbook generated from the registries it describes.

    Every imperative below names an implemented path. A statement describing
    behaviour that no implemented path provides is a known gap phrased as an
    operational claim, and it is refused here rather than caught in review.
    """
    envs = _loaded("environments")["environments"] if False else None
    import json as _json
    environments = _json.loads((ROOT / "environments" / "ENVIRONMENTS.json").read_text("utf-8"))
    rollout = _json.loads((ROOT / "registry" / "ROLLOUT.json").read_text("utf-8"))
    owners = _json.loads((ROOT / "registry" / "OWNERS.json").read_text("utf-8"))
    disable_seconds = rollout["emergency_disable"]["max_propagation_seconds"]
    provisioned = [e["id"] for e in environments["environments"] if e.get("provisioned")]
    declared = [e["id"] for e in environments["environments"] if not e.get("provisioned")]
    roles = sorted({r for entry in (owners.get("owners") or owners.get("requirements") or [])
                    for r in ([entry.get("owner_role"), entry.get("reviewer_role")] if isinstance(entry, dict) else [])
                    if r})
    return f"""# DOC-13 — Operator runbook

Generated from `registry/ROLLOUT.json`, `registry/OWNERS.json` and
`environments/ENVIRONMENTS.json`. Do not edit this file; edit the generator.

## Ownership

Accountability is held by **roles**, not people: {', '.join(f'`{r}`' for r in roles[:8]) or 'declared in OWNERS.json'}.
Binding a role to a person is `GO-00-04` and is a deployment concern. Until it is
done, every procedure below has an owner in name only — a known gap, stated as a
gap.

## Environments

Provisioned in this delivery: {', '.join(f'`{e}`' for e in provisioned) or 'none'}.
Declared but **not provisioned**: {', '.join(f'`{e}`' for e in declared) or 'none'}.
A procedure that names an unprovisioned environment cannot be executed today.

## Install, start, stop

```sh
cd "Repository Context Graph"
python3 environments/ci.py                 # verifier, fixtures, tests, eval, registries, docs
python3 -m rcg.cli review .. -q "<question>"
python3 -m successor release               # from control-plane/: the gate, exit status is the verdict
```

There is no long-running service in this delivery. `hosted_service_claimed` is a
profile decision (`GO-00-03`); until it is true and `GO-04-12` is executed, "start
the service" is a known gap and not an operational instruction.

## Emergency disable

The master switch is `rcg.enabled` in the rollout flag store. Since v1.5.0 the
runtime reads it: a disabled store refuses a new run at admission and stops an
in-flight run at its next checkpoint.

```python
from rcg.rollout import FlagStore
FlagStore(path).emergency_disable(actor=<authenticated Principal>, reason="<incident>")
```

The declared propagation bound is **{disable_seconds} seconds**. That bound has
**not been measured on a real service** — no service exists to measure it on
(`GO-08-03`). Treat it as a target, not a guarantee.

An `actor` string is refused: the audit record of who disabled the system is not
something the caller may assert about itself.

## Authority and credential renewal

Authority records are issued externally and imported; the runtime cannot mint
one. Renewal is the issuer's procedure. Revocation is re-checked at time of use,
and an unreachable revocation source refuses rather than assuming validity.

## Troubleshooting

| symptom | cause | action |
|---|---|---|
| every run refused at admission | the flag store is unusable or disabled | read `FlagStore.state().reason`; it names which of the thirteen refusal cases applies |
| a run is `CANCELLED` mid-flight | the switch moved, or authority expired | the cancellation record names the stage and reason; evidence up to that point is preserved |
| the gate reports `STALE` | the candidate changed after the evidence was collected | re-collect evidence against the current subject digest |
| `DRIFTED` in the docs check | a generated file was hand-edited | move the change into `docs/generate_docs.py` and regenerate |

## Data deletion

Retention and deletion across derived data is `GO-02-10` and is **not
implemented**. Deleting a source today removes it from the next index build; it
does not remove derived artifacts from prior runs. This is a known gap.

## Incident and rollback

`rcg.effects.apply_changeset` performs bounded rollback with verified before and
after digests for a changeset it applied. There is no service-level rollback
procedure, because there is no deployed service. `GO-08-04` and `GO-08-07` are
open.
"""


def doc14_user_guide() -> str:
    """GO-08-09: the user-facing half, generated from the same registries."""
    import json as _json
    tiers = _json.loads((ROOT / "registry" / "LANGUAGE_TIERS.json").read_text("utf-8"))
    tier_rows = tiers.get("tiers") or tiers.get("languages") or []
    names = []
    for entry in tier_rows if isinstance(tier_rows, list) else []:
        if isinstance(entry, dict):
            names.append(str(entry.get("language") or entry.get("name") or entry.get("id")))
    return f"""# DOC-14 — User guide

Generated from `registry/LANGUAGE_TIERS.json` and `registry/SLO.json`. Do not
edit this file; edit the generator.

## What this answers

Questions about one pinned snapshot of one repository: which symbols exist, what
depends on what, what a change would touch, and what evidence supports each
answer. Every material output names the snapshot it came from.

## What it does not answer

It does not browse, fetch, or reach a network. It does not modify your
repository unless you supply a change set on an explicitly authorized privileged
path. It does not guess: two candidate identities stay two candidates, and a file
whose imports could not be parsed is reported as having an *unknown* blast
radius, never an empty one.

## Coverage

Declared language tiers: {', '.join(f'`{n}`' for n in names[:12]) if names else 'see registry/LANGUAGE_TIERS.json'}.
Retrieval is lexical — BM25 over an identifier-expanded index. There is no
embedding model, so a purely semantic paraphrase may not match. That is a
property of the design, not a defect to work around.

## When it abstains

An abstention is the system declining to answer with a named missing input. It
is correct behaviour, and it is **not** a measure of answer quality: a run whose
model abstained is reported as `MODEL_ABSTAINED` and is inadmissible as
model-quality evidence.

## What you should not rely on yet

No model provider is bound; the default provider abstains on every call.
Confidence scores are withheld rather than shown, because calibration has not
been measured. No performance figure in `registry/SLO.json` has an observed
value. The system is **not production qualified** — see
[DOC-12](DOC-12-known-limitations-non-goals.md).
"""


DOCS = {
    "DOC-01-architecture.md": doc01_architecture,
    "DOC-02-dataflow-trust-boundaries.md": doc02_dataflow,
    "DOC-03-connector-inventory.md": doc03_connectors,
    "DOC-04-permission-matrix.md": doc04_permissions,
    "DOC-05-threat-model.md": doc05_threat_model,
    "DOC-06-model-tool-inventory.md": doc06_model_tool_inventory,
    "DOC-07-provenance-schema.md": doc07_provenance_schema,
    "DOC-08-run-state-schema.md": doc08_run_state_schema,
    "DOC-09-human-approval-policy.md": doc09_approval_policy,
    "DOC-10-evaluation-plan.md": doc10_evaluation_plan,
    "DOC-11-incident-rollback-runbook.md": doc11_runbook,
    "DOC-12-known-limitations-non-goals.md": doc12_limitations,
    "DOC-13-operator-runbook.md": doc13_operator_runbook,
    "DOC-14-user-guide.md": doc14_user_guide,
}


def _with_front_matter(name: str, body: str) -> str:
    """GO-01-11: every generated document embeds the digests of its sources."""
    from freshness import front_matter
    return front_matter(name) + "\n" + body.rstrip() + "\n"


def generate(destination: Path) -> list[str]:
    destination.mkdir(parents=True, exist_ok=True)
    if str(HERE) not in sys.path:
        sys.path.insert(0, str(HERE))
    written = []
    for name, builder in DOCS.items():
        (destination / name).write_text(_with_front_matter(name, builder()),
                                        encoding="utf-8", newline="\n")
        written.append(name)
    return written


def check(destination: Path) -> tuple[bool, list[str]]:
    """GO-01-11: generate into a temporary tree and diff. Never rewrite in place.

    CI calls this. A difference is a failure with the differing documents named,
    not a silent rewrite of a committed artifact.
    """
    import tempfile
    with tempfile.TemporaryDirectory() as scratch:
        generate(Path(scratch))
        differing = []
        for name in DOCS:
            expected = (Path(scratch) / name).read_text(encoding="utf-8")
            actual_path = destination / name
            actual = actual_path.read_text(encoding="utf-8") if actual_path.is_file() else None
            if actual != expected:
                differing.append(name)
    return (not differing), differing


if __name__ == "__main__":
    args = sys.argv[1:]
    if args and args[0] == "--check":
        target = Path(args[1]) if len(args) > 1 else HERE
        ok, differing = check(target)
        for name in differing:
            print(f"DRIFTED  {name} -- the committed file differs from what the generator "
                  f"produces; move the change into docs/generate_docs.py")
        print(f"{'PASS' if ok else 'FAIL'}: {len(DOCS) - len(differing)}/{len(DOCS)} documents "
              f"match their generator")
        raise SystemExit(0 if ok else 1)
    target = Path(args[0]) if args else HERE
    for name in generate(target):
        print(f"wrote {name}")
