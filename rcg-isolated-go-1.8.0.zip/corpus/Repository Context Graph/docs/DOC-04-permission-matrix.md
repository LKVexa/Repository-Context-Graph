<!-- generated-from: {"document":"DOC-04-permission-matrix.md","sources":{"environments/ENVIRONMENTS.json":"2bd5c422873e2b3bc90704770c1ef3b979e1493362ea635b9f679a1c02ef2966","registry/CONTROLS.json":"b2c37662ebc466de2d6297e129eb4442f6740f1c6411188129ed823a6a7a9690"}} -->
# DOC-04 — Permission matrix

Permissions form a lattice with no implication: holding one never grants
another (XAUTH-03). Everything marked privileged is denied unless explicitly
granted for the run.

Since v1.4.0 the privileged set is split (GO-02-13). **Mutating** permissions
can change something outside this process -- repository bytes, a remote system,
a deployment, a human channel, installed software. `network_read` is privileged
(never implied, always explicit) but not mutating: reading a named,
pre-authorized external source changes nothing.

| permission | privileged | mutating | meaning |
|---|---|---|---|
| read | no | no | Read authorized artifacts. |
| analyze | no | no | Run deterministic analyzers and queries. |
| draft | no | no | Produce a draft that is not written anywhere. |
| modify | yes | yes | Write inside the authorized paths of the worktree. |
| commit | yes | yes | Create a commit. |
| push | yes | yes | Push to a remote. |
| approve | yes | yes | Record an approval decision. |
| deploy | yes | yes | Deploy or release. |
| communicate | yes | yes | Send an external message. |
| install | yes | yes | Install a package. |
| network_read | yes | no | Read from a named external system. |
| network_write | yes | yes | Write to a named external system. |
| credential_use | yes | yes | Use a stored credential. |
| write_evidence | no | no | Write this run's own evidence into the authorized evidence root. Confined by check_evidence_write and explicitly NOT a route to modifying the target repository. |

`network_read` and `network_write` are *system-bound*: holding the permission is
not authority to reach anything. `ScopeContract.check` refuses either without a
named `external_system` on the contract's allowlist.

## Mode constraints

The single authority on this relationship is `rcg.scope.mode_admits`. The
contract constructor and `rcg.scope.reconcile_environments` both call it, so a
profile the environment registry declares can never be one the contract refuses
to build -- which is exactly what ENV-03 and ENV-04 were before v1.4.0.

| mode | may hold |
|---|---|
| read_only | read, analyze. `draft` and every mutating permission are rejected at construction. `network_read` only with a non-empty `authorized_external_systems` allowlist and without `credential_use`. |
| draft_only | read, analyze, draft. Every mutating permission is rejected at construction. `network_read` under the same two conditions. |
| modify | as granted; each privileged permission still has to be listed explicitly. |

Narrowing a contract that no longer holds a mutating permission drops it to the
narrowest mode its remaining permissions justify.

## Enforceable controls (IMPL-06, PROD-01)

| control | requirement | stop condition |
|---|---|---|
| CTRL-GRD-01 | PAPER-GRD-01 | Any target path outside the approved scope or declared change surface. |
| CTRL-GRD-02 | PAPER-GRD-02 | A structural change, or a change over the file threshold, without a scoping record. |
| CTRL-GRD-03 | PAPER-GRD-03 | A declared convention divergence with no approval reference. |
| CTRL-GRD-04 | PAPER-GRD-04 | A diff larger than the reviewable limit, or containing binary changes. |
| CTRL-AUTH-01 | MODEL-06 | Model-requested permission beyond the contract, or a model-asserted approval. |
| CTRL-AUTH-02 | XAUTH-03 | The declared permission is absent, expired, or not granted. |
| CTRL-PROV-01 | PROD-04 | A material output with an empty evidence reference set. |

## Who may do what

| actor kind | may read | may analyze | may draft | may approve | may attest |
|---|---|---|---|---|---|
| human | yes | yes | yes | yes | yes |
| service | yes | yes | yes | no | no |
| model | only labeled context | no | proposes only | no | no |
