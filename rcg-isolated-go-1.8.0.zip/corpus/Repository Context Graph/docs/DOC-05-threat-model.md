<!-- generated-from: {"document":"DOC-05-threat-model.md","sources":{"registry/CONTROLS.json":"b2c37662ebc466de2d6297e129eb4442f6740f1c6411188129ed823a6a7a9690"}} -->
# DOC-05 — Threat model

## Assumption

Everything the system reads is attacker-controlled. A repository file, a commit
message, an issue body, a generated log and a model completion are all
untrusted input. The defence is structural, not detective: no control anywhere
reads its verdict from text.

## Threats, controls, and residual risk

| # | Threat | Control | Residual risk |
|---|--------|---------|---------------|
| T1 | Prompt injection in repository content | Retrieved text enters only as labeled context; the prompt states that context is data; no code path turns text into a permission | Detection is best-effort; a novel phrasing may not be *flagged*, but still cannot *act* |
| T2 | Model fabricates an approval | Approval requires an authenticated human principal; `assert_not_self_attested` rejects non-human; `CTRL-AUTH-01` denies model-asserted approval | None known within the process boundary; a compromised IdP defeats it |
| T3 | Model grants itself permissions | `CTRL-AUTH-01`; the scope contract is immutable within a run and narrowing cannot widen | None known |
| T4 | Secret exfiltration through evidence or logs | Classification before use; redaction; findings carry digests not excerpts; sandbox scrubs the environment | A secret in an unrecognized format is not matched by the pattern set |
| T5 | Path traversal / symlink escape | Canonicalize-then-contain, resolution before the containment test; denied paths win | Race between resolve and open on a hostile filesystem (TOCTOU) |
| T6 | Cross-tenant data leakage | `assert_no_cross_tenant`; repository id is an identity field on every node | A deployment that reuses one repository id for two tenants defeats it |
| T7 | Untrusted code execution during indexing | Parsers use regex and `ast` only; nothing is imported or evaluated; the sandbox is a separate process with rlimits and a scrubbed environment | Host without namespaces gets process-level isolation only, and the enforcement report says so |
| T8 | Unauthorized write | Permission separation; per-path check at the moment of the write; `ALERT-WRITE-01` | None known within the process boundary |
| T9 | Evidence tampering | Hash-chained ledger with per-event detail digests; append-only API; the model never receives a ledger handle | An attacker with filesystem write can truncate/rebuild a valid chain; detection needs a separately trusted head/count, which local chain verification alone does not supply |
| T10 | Stale context presented as current | Freshness compares identities, never timestamps; stale results are demoted and qualified; `INVALID` refuses queries outright | A consumer that ignores the `freshness` field |
| T11 | Oversized or unreviewable change | `CTRL-GRD-02` structural threshold, `CTRL-GRD-04` diff limit | Thresholds are policy, not proof |
| T12 | Supply-chain compromise of a parser | Zero third-party runtime dependencies; parser identity recorded with every derived fact | Compromise of the Python standard library or interpreter |

## Explicitly out of scope

- Publisher authenticity of the control-plane package. In-package hashes prove
  consistency against supplied bytes, not who supplied them.
- Encryption at rest and in transit. This package stores plaintext on the local
  filesystem and makes no network calls; XSEC-04 is delegated to the host and
  is **not** satisfied here.
- Denial of service against the host.
