<!-- generated-from: {"document":"DOC-01-architecture.md","sources":{"registry/CONTROLS.json":"b2c37662ebc466de2d6297e129eb4442f6740f1c6411188129ed823a6a7a9690","registry/REQUIREMENTS.json":"be254d08de5f9949a16064cf167349b96985450ab264e429d4c5c5d83905bc3e"}} -->
# DOC-01 — Architecture

Repository Context Graph for Cross-File Changes, version 1.7.2.

## Layers, bottom up

```
                         +-----------------------------+
                         |  rcg.cli / rcg.pipeline     |   one governed run
                         +--------------+--------------+
                                        |
      +-----------------+---------------+---------------+------------------+
      |                 |               |               |                  |
+-----v------+   +------v-----+  +------v------+ +------v-------+  +-------v------+
| connectors |   |  parsers   |  |  analysis   | |  reasoning   |  |    review    |
| ARCH-01    |   |  COMP-01   |  |  ARCH-05    | |  ARCH-06     |  |  ARCH-09     |
| DATA-01..09|   |  AUD-005   |  |  XTOOL-01   | |  MODEL-01..07|  |  HUMAN-01..07|
+-----+------+   +------+-----+  +------+------+ +------+-------+  +-------+------+
      |                 |               |               |                  |
      +--------+--------+               |               |                  |
               |                        |               |                  |
        +------v-------+                |               |                  |
        |   indexer    |                |               |                  |
        |  PAPER-CAP-01|                |               |                  |
        +------+-------+                |               |                  |
               |                        |               |                  |
        +------v-------+   +------------v----+  +-------v--------+ +-------v------+
        |    graph     |-->|  query / impact |  |  uncertainty   | |    policy    |
        |  COMP-02/04  |   |  COMP-07/09     |  |  XUNC-01..06   | |  ARCH-07     |
        +------+-------+   +--------+--------+  +-------+--------+ +-------+------+
               |                    |                   |                 |
        +------v--------------------v-------------------v-----------------v------+
        |   scope (IMPL-01, XAUTH-*)  |  provenance ledger (ARCH-08, XPROV-*)     |
        |   authority (FLOW-01)       |  version store (COMP-03, ARCH-03)         |
        |   security (SEC-*, XSEC-*)  |  observability (ARCH-10, XOBS-*)          |
        +---------------------------------------------------------------------+
```

## The one-way rules

1. Nothing above the scope layer decides its own permissions. Every effect
   calls `ScopeContract.check` at the moment of the effect.
2. Deterministic analysis completes before the reasoning layer is called. The
   reasoning layer receives analyzer output as established fact.
3. No path reaches `APPLYING` without passing `APPROVED`. This is a property of
   the transition table, not a runtime check.
4. The reasoning layer has no handle on the ledger, the policy layer, or the
   scope contract's mutators.

## Modules

| module | responsibility | primary requirements |
|---|---|---|
| rcg.scope | Scope contract, permission separation, path confinement | IMPL-01, XAUTH-02..06 |
| rcg.authority | Identity, authentication, credential leases, recorded authority | FLOW-01, XAUTH-01/05/07 |
| rcg.schemas | Canonical contracts and total validation | IMPL-02, API-01..08 |
| rcg.workflow | Versioned state machine | IMPL-03, XSTATE-03 |
| rcg.connectors | Authorized source ingestion with resilience | ARCH-01, DATA-01..09, AUD-010 |
| rcg.parsers | Language tiers, symbol and dependency extraction | COMP-01, AUD-005 |
| rcg.indexer | Snapshot binding and two-pass graph ingestion | PAPER-CAP-01, FLOW-02/04 |
| rcg.graph | Ontology-checked graph with entity resolution | COMP-02, COMP-04, ARCH-02 |
| rcg.versionstore | Temporal store, CAS, backup/restore, retention | COMP-03, ARCH-03, STORE-* |
| rcg.query | Revision-aware bounded queries | COMP-07, ARCH-04, VERIFY-05 |
| rcg.retrieval | Labeled retrieval with stale demotion | COMP-05, XTOOL-05, MODEL-03 |
| rcg.rationale | Historical rationale extraction | COMP-06, PAPER-CAP-03 |
| rcg.incremental | Change-set update and freshness comparison | COMP-08, PAPER-CAP-02, VERIFY-02 |
| rcg.impact | Direct and transitive impact before drafting | COMP-09, PAPER-CAP-04, VERIFY-03 |
| rcg.analysis | Deterministic analyzers, run first | ARCH-05, FLOW-05, XTOOL-01 |
| rcg.reasoning | Bounded model orchestration | ARCH-06, MODEL-01..07 |
| rcg.uncertainty | Seven-state uncertainty, abstention, calibration | IMPL-07, XUNC-01..06 |
| rcg.intent | Deterministic request classification | FLOW-07, XUNC-01 |
| rcg.policy | Guardrails as executable controls | ARCH-07, IMPL-06, PAPER-GRD-01..04 |
| rcg.review | Review package and approval gate | ARCH-09, IMPL-08, HUMAN-*, XHITL-* |
| rcg.security | Classification, redaction, injection defence, tenancy | SEC-*, XSEC-* |
| rcg.sandbox | Confined execution of untrusted code | XTOOL-03, ENV-05 |
| rcg.provenance | Hash-chained evidence and audit ledger | ARCH-08, XPROV-*, STORE-07 |
| rcg.observability | Logs, metrics, traces, alerts, scoring | ARCH-10, XOBS-*, IMPL-09 |
| rcg.governance | Requirement, owner, SLO, budget, rollout registries | AUD-001..018 |
| rcg.pipeline | The end-to-end governed run | FLOW-01..12 |
