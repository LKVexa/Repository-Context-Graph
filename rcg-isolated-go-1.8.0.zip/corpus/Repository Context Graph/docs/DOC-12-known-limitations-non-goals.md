<!-- generated-from: {"document":"DOC-12-known-limitations-non-goals.md","sources":{"registry/LANGUAGE_TIERS.json":"7586f76de4f451479a5f4fbc578fc9384cd645350958ce3beaa7ff8a7c4ba967","registry/SLO.json":"1991a64d23dfe984d8fa02c6e28eb515090a828efa8332498cb3d6767b679174","registry/THRESHOLDS.json":"69976bad30877b5ac9732d0d3332f993188b97f95684c9072c28daf45413ea85"}} -->
# DOC-12 — Known limitations and non-goals

## Production status (runtime 1.7.2)

**This runtime is PRODUCTION NO_GO. The 1.7.2 efficacy audit repairs implementation
defects and claim accuracy; it does not supply production qualification.** `rcg.promotion.promotion_gate` is the executable statement of
it: with the evidence that exists today it returns `NO_GO` and enumerates the
blockers. All thirteen original blockers remain open — PROD-01..08 (no
authenticated human release authority has approved anything), XSEC-04
(encryption is delegated to the host), ENV-03/04/05 (declared, reconciled with
the permission lattice, **not provisioned**) and XEVAL-06 (no pilot has run).

What v1.4.0 closed was four runtime defects and six qualification-tooling gaps.
What v1.5.0 adds is the executable half of R01 and R04: the master rollout
switch is now read by the runtime (before v1.5.0 nothing on the execution path
consulted it, so `rcg.enabled = false` did not stop a run); flag writes require
an authenticated principal and a revision check; the thirteen declared blockers
dispatch to evidence validators instead of stored strings; runs and attempts are
append-only and restart-safe; and a blocked promotion exits non-zero.

All of that is *mechanism*. A mechanism that refuses correctly is not a
requirement that has been met, and none of these tasks has an independent review
disposition, because no second accountable person has been named.

Specifically **not** established by anything in this package: real signer
identity, a provisioned environment of any kind, native-Windows qualification,
live model quality, actual elapsed observation windows, real repository
modification against production data, or promotion authority.

## Limitations of this implementation

1. **No model provider is bound.** The default provider abstains on every call.
   Local tests exercise selected deterministic paths; they are not exhaustive. The model
   half is not exercised, and its grounding rate is unmeasured.
2. **Encryption is not implemented.** XSEC-04 (encrypt in transit and at rest)
   is delegated to the host filesystem and transport. This package writes
   plaintext locally and makes no network calls. It is not satisfied here.
3. **The sandbox is process-level.** On a host without namespace or seccomp
   support, isolation is a separate process, a scrubbed environment, rlimits
   and a wall-clock limit. `SandboxResult.enforcement` reports exactly what was
   applied; no evidence claims a kernel sandbox that was not available.
4. **Injection detection is best-effort.** The pattern set catches common
   phrasings. The guarantee is structural — text cannot act — not detective.
5. **History and tracker connectors need real sources.** Against a snapshot
   with no git history and no authorized tracker, they return zero artifacts
   and a `missing` freshness state. Rationale extraction then reports `missing`
   rather than inferring intent from the code.
6. **The trust root ships no signature algorithm.** `rcg.trustroot` verifies
   with a built-in `hmac-sha256` that exists so the negative tests have
   something to be negative about; it is marked `production_acceptable: false`
   and can never be marked otherwise. A deployment with a real asymmetric root
   registers its own verifier. Passing verification here is contract
   qualification, never production signer acceptance.
7. **Observation windows have a mechanism and no data.** `rcg.promotion`
   freezes a subject, and invalidates a window on subject drift, clock
   rollback, telemetry gap or expired authority — and no window has been
   opened. The 14-day canary and 30-day availability window are real elapsed
   time that no code can supply.
8. **Every SLO and acceptance threshold currently reads INSUFFICIENT_DATA.**
   All fifteen are typed and reported; none has a measurement. `slo_report`
   refuses to call an unmeasured metric met.
9. **Retrieval is lexical.** BM25 over an identifier-expanded inverted index.
   There is no embedding model, which keeps retrieval reproducible for a pinned
   revision but means a purely semantic paraphrase may not match.
10. **Calibration is unpopulated.** `XUNC-02` is implemented — an uncalibrated
    score is *withheld* rather than shown — but no calibration has been measured,
    so numeric confidence is never displayed.
11. **SLO targets are unmeasured.** `SLO.json` states targets; the `observed`
    column is empty until a benchmark runs against a real corpus at scale.
12. **Owners are roles, not people.** `OWNERS.json` proves every requirement has
    exactly one accountable owner and reviewer role; binding a role to a person
    is a deployment concern.
13. **The rollout bound is a target, not a measurement.** `ROLLOUT.json` declares
    a 60-second emergency-disable propagation bound. Since v1.5.0 the runtime
    honours the switch, but the bound has never been measured on a real service
    because no service exists (`GO-08-03`).
14. **Retention and deletion across derived data is not implemented.** Deleting a
    source removes it from the next index build; it does not remove derived
    artifacts from prior runs (`GO-02-10`).
15. **Publisher authenticity is out of reach.** In-package hashes establish
    consistency against supplied bytes. Who supplied them requires a signature
    mechanism this package does not provide, and `rcg.trustroot` deliberately
    anchors outside it rather than pretending otherwise.
16. **The subject digest excludes two declared things, and a reviewer should read
    both declarations.** An exclusion is a statement about what the digest does
    *not* prove. `rcg.subject.NON_REPRODUCIBLE` holds exactly one path:
    `fixtures/golden/git_history_repo/.git/index`, git's stat cache, whose bytes
    differ after every checkout and rebuild even when tracked content is
    identical. Everything else in that fixture repository — commit objects, refs,
    tree objects — stays inside the digest, so a real change to fixture history is
    still a subject change. `rcg.subject.NON_SUBJECT_TREES` holds
    `production-evidence/`, which records evidence *about* the subject: a receipt
    names the subject digest, so folding receipts into that digest would mean no
    receipt could ever match the subject it describes. That is the tree-level form
    of the self-referential proof `successor.results.bind_result` already refuses.
17. **The evidence intake exists; the evidence does not.** Before v1.6.0 nothing
    read a receipt from disk, so every condition was evaluated against a permanent
    empty set and no amount of external provisioning could have changed a verdict.
    `rcg.intake` closes that, and `rcg.bindings` declares the five external facts
    this package cannot supply — KMS, identity provider, attestation issuer, model
    provider, host — each as a slot with **no default occupant**. Every slot is
    `UNCONFIGURED` in this delivery, so the intake currently accepts nothing that
    could satisfy anything. What changed is the *reason*: a condition with no
    evidence reads `ABSENT`, and one with well-formed evidence and no trust root
    reads `UNATTESTED`. The second names the next action; the first was a dead end.
18. **The release desk is empty, and that is the honest state.**
    `rcg.release_authority` declares thirteen roles, five of them accountable, and
    enforces the two-person rule, separation of duties and expiring authority. None
    is bound, because binding a role requires an authenticated principal and
    `GO-00-04` — naming real people — is a decision only the operator can make. A
    desk that named its own approvers would be recording an approval attributed to
    someone who never held a key.

19. **Before v1.7.0 the evidence path could be satisfied by a synthetic signer.**
    The v1.3.0 prompt/workflow package's contract probes showed it: a nonproduction
    HMAC root with the right audience string took `successor.qualify.release` to
    GO; one subject-level attestation stood for 47 receipts; a zero-duration,
    zero-sample window read valid; two approvals satisfied a five-role desk and a
    later unrelated approval cleared a privacy REJECT. All four are reproduced as
    negative tests in `tests/test_wg_hardening.py` and now refuse. What is
    enforced: the verifier registry is a sealed `frozenset` and any change after
    sealing revokes all acceptance; an attestation binds receipt id, condition,
    kind and verdict inside the signed bytes; windows cannot be constructed below
    the 14-day canary / 30-day availability floors and need continuous samples;
    every accountable role must approve and a refusal persists until that same
    role resolves it; a PASS label needs a substantive per-kind payload naming
    its raw artifact. The genuine positive still exists — with every input real
    the gate says GO — and a truth table proves each single omission is NO_GO.
20. **Sixteen inherited evidence records are quarantined.** `successor/requalify.py`
    found 15 records whose named artifacts have since changed and one naming
    none. They are not deleted or edited; `production-evidence/QUARANTINE.json`
    lists them and each carries a `REQUALIFICATION.json`. They describe history,
    not the current tree, and nothing in the release path reads them as receipts.


## Efficacy boundaries confirmed by the 1.7.2 audit

- The collector reads the live directory. A revision label does not make collection atomic; use an immutable checkout when coherent multi-file snapshots are required.
- Python uses static AST declarations/imports and repository-relative module names. Dynamic import paths, runtime dispatch, re-exports, call graphs and complete language semantics are outside current coverage. JA-family extraction is lexical, not a compiler.
- The updater fully rebuilds changed snapshots. Only an unchanged snapshot reuses its index; work counters disclose this. Selective reparsing and automatic rename continuity are not implemented.
- The ontology is larger than graph ingestion. Build/test/ADR/ownership connectors mostly admit file bytes; complete build dependencies, coverage, ownership and governance relations are not supplied. Pathless history and tracker evidence contributes to snapshot identity and retrieval, not corresponding graph entities.
- Cycle output contains bounded representative DFS witnesses, not every elementary cycle.
- Connector rate-limit and freshness-age fields are declarations, not enforced controls. Truncation/failure signals do downgrade coverage, and tombstones require confirmed absence.
- The rollout store is optional for local demonstrations. Deployment switch enforcement requires configuring it. Synthetic/local identity helpers do not prove deployment identity.
- The offline evaluation exercises selected components, not every `Pipeline.run` path. Empty or missing-fixture evaluations fail; no-provider grounding remains unmeasured. Small-corpus benchmark timings cannot qualify larger scale targets.

## Non-goals

- The system does not commit, push, open pull requests, deploy, release,
  publish, or communicate. Those permissions exist in the lattice so they can be
  **denied**; nothing in this package implements them.
- It does not mutate repository state during indexing: no fetch, pull,
  checkout, merge, reset, or configuration change.
- It does not resolve ambiguity by heuristic. Two candidates stay two
  candidates.
- It does not replace human review. It makes review cheaper and more honest;
  the decision, and the accountability, stay with a person.
- It is not a general code-search engine. Everything is scoped to one pinned
  snapshot under one contract.
