<!-- generated-from: {"document":"DOC-09-human-approval-policy.md","sources":{"registry/OWNERS.json":"64cc4f4a2a859c82cbf2e0c1c8bfd0e5cf86419d2147870557b76aa107d24f9d","registry/RELEASE_POLICY.json":"f21c79cb5e4756fd5fd2f192719d85c1f207e6d5d383fc7056180c64f75c2891"}} -->
# DOC-09 — Human approval policy

## The gate

Admitted runs that reach review enter `AWAITING_REVIEW`; denied, failed or cancelled
runs can terminate earlier. Application still requires a matching approval.
The reviewer receives a review package
that shows what was analyzed, **what was not analyzed**, every statement with
its citations, the impact report, the uncertainty state with its missing
context, the change surface, the policy verdict, and a measured review burden.

## Who may decide

Only an authenticated **human** principal. A service principal is refused by
`assert_not_self_attested`; a model has no principal at all. Final
accountability is stated on every package and every decision record and is
never represented as belonging to the system (HUMAN-07).

## What a decision binds

A decision records `subject_digest` — sha256 over the canonical bytes of the
exact package the reviewer saw — plus `approved_scope_digest` and the run id.
`ApprovalGate.authorizes` re-checks all three. Any change to the package after
approval changes its digest, and the approval stops authorizing anything
(material change invalidates approval).

## The five decisions (XHITL-03)

| decision | effect |
|---|---|
| `approve` | The only decision that authorizes the next state change. |
| `reject` | Terminal. No side effect beyond the audit record (HUMAN-04). |
| `edit` | The reviewer's edit becomes a new package with a new digest. |
| `narrow_scope` | Returns to collection under a strictly narrower contract. Narrowing can only remove; an attempt to widen raises. |
| `request_more_evidence` | Returns to collection with the reviewer's evidence request recorded. |

## What an approval never grants

An approval authorizes the state change it was bound to. It does not grant
`commit`, `push`, `deploy`, `communicate`, or any other permission the scope
contract did not already hold. Phase or release success never grants a
separately denied side effect.
