<!-- generated-from: {"document":"DOC-08-run-state-schema.md","sources":{"registry/LIFECYCLE.json":"f8700374786820939144e37ce48499ba07684c9b48b4e7c86da0f5327008b108"}} -->
# DOC-08 — Run-state schema

State machine version 1.2.0.

## Transitions

| from | event | to |
|---|---|---|
| CREATED | abort | ABORTED |
| CREATED | authority_established | AUTHORIZED |
| CREATED | policy_denied | DENIED |
| AUTHORIZED | abort | ABORTED |
| AUTHORIZED | policy_denied | DENIED |
| AUTHORIZED | revisions_pinned | PINNED |
| PINNED | abort | ABORTED |
| PINNED | collect_evidence | COLLECTING |
| PINNED | policy_denied | DENIED |
| COLLECTING | abort | ABORTED |
| COLLECTING | abstain | ABSTAINED |
| COLLECTING | evidence_indexed | INDEXED |
| COLLECTING | policy_denied | DENIED |
| INDEXED | abort | ABORTED |
| INDEXED | begin_analysis | ANALYZING |
| INDEXED | policy_denied | DENIED |
| ANALYZING | abort | ABORTED |
| ANALYZING | abstain | ABSTAINED |
| ANALYZING | impact_computed | IMPACT_ASSESSED |
| ANALYZING | policy_denied | DENIED |
| IMPACT_ASSESSED | abort | ABORTED |
| IMPACT_ASSESSED | abstain | ABSTAINED |
| IMPACT_ASSESSED | draft_produced | DRAFTED |
| IMPACT_ASSESSED | policy_denied | DENIED |
| DRAFTED | abort | ABORTED |
| DRAFTED | policy_denied | DENIED |
| DRAFTED | verification_failed | ABORTED |
| DRAFTED | verification_passed | VERIFIED |
| VERIFIED | abort | ABORTED |
| VERIFIED | policy_denied | DENIED |
| VERIFIED | submit_for_review | AWAITING_REVIEW |
| AWAITING_REVIEW | abort | ABORTED |
| AWAITING_REVIEW | approve | APPROVED |
| AWAITING_REVIEW | narrow_scope | SCOPE_NARROWED |
| AWAITING_REVIEW | reject | REJECTED |
| AWAITING_REVIEW | request_more_evidence | EVIDENCE_REQUESTED |
| SCOPE_NARROWED | abort | ABORTED |
| SCOPE_NARROWED | collect_evidence | COLLECTING |
| EVIDENCE_REQUESTED | abort | ABORTED |
| EVIDENCE_REQUESTED | collect_evidence | COLLECTING |
| APPROVED | abort | ABORTED |
| APPROVED | apply | APPLYING |
| APPROVED | policy_denied | DENIED |
| APPLYING | apply_failed | ROLLED_BACK |
| APPLYING | apply_incomplete | ABORTED |
| APPLYING | apply_refused | DENIED |
| APPLYING | apply_succeeded | COMPLETED |
| APPLYING | rollback | ROLLED_BACK |

## Terminal states

`ABORTED`, `ABSTAINED`, `COMPLETED`, `DENIED`, `REJECTED`, `ROLLED_BACK` — these have no outgoing
transitions, so a rejected or rolled-back run cannot be resurrected.

## Structural guarantees

- `APPLYING` is unreachable without firing `approve`
  (`WorkflowMachine.reachable_without('approve', 'APPLYING')` is `False`, asserted
  by `tests/test_unit.py`).
- `approve`, `reject`, `narrow_scope` and `request_more_evidence` require
  `actor_kind == "human"`.
- Every transition is recorded to the evidence ledger with the authority under
  which it occurred, so an interrupted run reconstructs from the ledger alone
  (XSTATE-03).
- `idempotency_key` makes a retried step a no-op that returns the state the
  first call produced (API-06).

## Contracts

| schema id | version |
|---|---|
| rcg.audit_event/1 | 1.0.0 |
| rcg.evidence_ref/1 | 1.0.0 |
| rcg.impact_report/1 | 1.0.0 |
| rcg.model_output/1 | 1.0.0 |
| rcg.review_decision/1 | 1.0.0 |
| rcg.scope_contract/1 | 1.0.0 |
| rcg.tool_call/1 | 1.0.0 |
| rcg.tool_result/1 | 1.0.0 |
| rcg.uncertainty/1 | 1.0.0 |
