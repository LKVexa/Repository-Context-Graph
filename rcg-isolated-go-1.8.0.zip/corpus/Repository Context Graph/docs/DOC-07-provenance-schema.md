<!-- generated-from: {"document":"DOC-07-provenance-schema.md","sources":{"registry/RTM.json":"02710215f4e427e17098f1d1e5f4fb3cceabb60391d1e21186761e7c127ccb10"}} -->
# DOC-07 — Provenance schema

## Mandatory fields on every node and edge

| field | meaning |
|---|---|
| source_system | Which connector admitted the fact. |
| artifact_id | Stable identity of the artifact it came from. |
| revision | The pinned revision the fact was read at. |
| source_hash | sha256 over the exact bytes the fact came from. |
| derivation | `source` \| `deterministic_analyzer` \| `model_inference`. Never merged. |
| analyzer | Parser/model identity and version. Required when derivation is not `source`. |
| observed_at | When the fact was admitted. Excluded from the logical digest. |
| confidence | known \| supported \| inferred \| uncertain \| stale \| missing \| out_of_scope |
| evidence_refs | At least one immutable reference. A fact with none is rejected. |

## Identity rule

Node identity is definition identity (type, repository, worktree, qualified name, path). Content is bound by source_hash and never changes identity. A rename or move is recorded as a renamed_from continuity edge, never as an unexplained delete plus add.

## Rename, move and delete

| event | semantics |
|---|---|
| rename | New identity + renamed_from edge to the prior identity; prior node moves to lifecycle 'superseded'. |
| move | Same as rename; path is an identity field so the identity necessarily changes. |
| delete | Node moves to lifecycle 'deleted' and keeps its terminal provenance event. Records are never erased by deletion; they are erased only by an executed retention policy, which writes a tombstone. |
| tombstone | A tombstoned node retains identity and terminal provenance but no content-derived fields. |

## Evidence ledger

Append-only JSONL. Each event binds `previous_digest` = sha256 of the previous
event object, and `detail_digest` = digest of its own detail payload. `verify()`
re-walks the chain and names the first break by sequence number. There is no
update or delete path; the model-facing surface never receives a ledger handle
(SEC-08).

## Case file (XPROV-07)

`EvidenceLedger.export_case_file` writes a self-contained bundle: chain status,
head digest, the three derivation classes separated, every event, and the scope
digest and baseline revision it was exported against.
