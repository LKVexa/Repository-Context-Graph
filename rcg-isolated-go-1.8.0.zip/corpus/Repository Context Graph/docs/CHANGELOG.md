# Changelog

Versioning follows `registry/RELEASE_POLICY.json`: semver 2.0.0 applied
independently per surface. Every entry below records the surface, the version
move, whether it is breaking, the migration reference and the evidence
reference.

Runtime package versions 1.4.0 through 1.7.0 changed no versioned surface and
have no entry here. What each of them changed is recorded in
`../GO_PLAN_APPLICATION_REPORT.md`, `../GO_PACKAGE_EXECUTION_REPORT.md` and
`../APPLICATION_REPORT.md`; this file is not a substitute for those and does
not claim to be a complete history of the runtime package version.

## 1.8.0 — 2026-09-09

Isolated-instance qualification. Runtime package version moves from 1.7.2 to
1.8.0. The graph schema remains 1.3.0. hmac-sha256 remains the test algorithm
and is not production-acceptable. The 14-day canary and 30-day availability
windows are unchanged.

| surface | from | to | breaking | migration | evidence |
|---|---|---|---|---|---|
| runtime package | 1.7.2 | 1.8.0 | no (additive modules) | none | `rcg/__init__.py`, `tests/test_go_closure.py` |
| graph_schema | 1.3.0 | 1.3.0 | no | none | `registry/ONTOLOGY.json` |
| umc harness | 1.0.3 | 1.1.0 | no (`.V`/`.E` now execute) | none | `umc/acceptance.py`, `umc/receipts.py` |

### Added
- Versioned decision register (`rcg.decisions`) for D01–D20.
- Four-plane process separation (`rcg.identities`).
- Controlled archive extract (`rcg.archives`).
- Security-sensitive surface catalogue (`rcg.surfaces`).
- Independent tokenize reproducer (`rcg.reproducer`).
- Bound `ExtractiveProvider`.
- Patch compile/test (`rcg.patchverify`) and dual-control retention.
- Owner path, staging, eval-corpus pilot, privileged executor, incident drill.
- Isolated-instance desk (`desk/`) with two human-kind Ed25519 principals.

### Unchanged on purpose
- `promotion_gate` still requires 14-day and 30-day windows.
- Qualification `completion_claim` stays false.
- Networked production GO stays NO_GO.

## 1.7.2 — 2026-09-09

Second efficacy and truth-to-name audit. Runtime package version moves from
1.7.1 to 1.7.2; the language-tier document moves from 1.0.0 to 1.1.0 because it
now binds the extractor version. The graph schema remains 1.3.0 and no
graph-store migration is required.

| surface | from | to | breaking | migration | evidence |
|---|---|---|---|---|---|
| language_tiers document | 1.0.0 | 1.1.0 | no (additive field) | reindex; see Compatibility below | `registry/LANGUAGE_TIERS.json`, `tests/test_efficacy_audit.py` |
| graph_schema | 1.3.0 | 1.3.0 | no | none | `registry/ONTOLOGY.json` |
| api_contracts | 1.0.0 | 1.0.0 | no (additive fields only) | none | `tests/test_efficacy_audit.py` |
| policies | 1.0.0 | 1.0.0 | no (stop conditions strengthened, none weakened) | none | `tests/test_efficacy_audit.py` |
| connectors | 1.0.1 | 1.0.1 | no (audit detail only) | none | `tests/test_efficacy_audit.py` |

### Changed

- `VersionStore.verify` reads every ref head, so an unparseable head, a head
  whose payload object is missing, and a head absent from the ref log are all
  reported instead of returning `ok`.
- `VersionStore.restore` validates the manifest it already demanded: the
  manifest's own digest, its refs map and its object count are checked against
  the restored bytes.
- `incremental_update` performs the AUD-007 compare-and-swap by default and
  binds the write to the snapshot the update was computed against.
- `EvidenceLedger.verify` accepts an externally recorded head/count and
  compares the replay against the ledger's own in-memory head; without an
  external head it now states that tail length is unverified instead of
  reporting a bare `ok`.
- The XOBS-04 alert rules read whole ledger records, and the pipeline records a
  `policy.decision` event, so all five rules can fire on real runs rather than
  only on synthetic input.
- `ScopeContract.narrowed` re-runs the mode/permission admissibility rule.
- A path containing a NUL byte is a `ScopeDenied`/`EffectError`, not an
  uncaught `ValueError`.
- `apply_changeset` re-reads each postimage from disk instead of comparing a
  value with itself.
- `merkle_root` domain-separates leaves from interior nodes.
- `build_requirements_registry` computes `orphans`; `build_rtm` answers
  `bidirectional` against supplied evidence rather than tautologically.
- `EXTRACTOR_VERSION` is bound into the language profile hash.
- The CLI rejects a denied collection using the field the connector actually
  sets, and warns on an incomplete one.

An adversarial review of the above defeated six of them; the second round closed
each one:

- `snapshot_id` is recomputed for every ref head and every logged record, so a
  head cannot keep a logged id while its payload, revision and metadata are
  rewritten underneath it.
- `VersionStore.commit` performs the parent test and the ref write inside an
  `O_EXCL` lock, so two threads observing the same head can no longer both
  commit. `restore` also validates every restored snapshot id, and takes an
  optional `expected_manifest_digest` because a self-contained manifest proves
  integrity, not provenance.
- `Pipeline` catches the new refusals from `narrowed()` and from the approval
  gate, so both end the run as recorded denials instead of escaping `run`.
- The alert baseline is the effective permission intersection, `_deny` records
  the requested permission, and `ALERT-EXT-01` now says contact was attempted
  and refused rather than that it succeeded.
- `build_rtm` requires both directions and artifacts that resolve on disk, and
  `bidirectional` can no longer contradict `unlinked_requirements`.
- `export_case_file` no longer passes the ledger's own head into `verify`, and
  records whether the chain was anchored externally.
- `control-plane/checks.py::_incremental_reuses` no longer fabricates a source
  hash the snapshot binding rejects, and asserts the reuse contract the runtime
  actually implements.

### Breaking behavior

Every change above is a refusal that previously did not happen: a corrupt or
forged store, a stale-parent incremental commit, an inadmissible narrowed
contract, a NUL-byte path, and an applied file whose bytes no longer match the
reviewed postimage all now fail closed. `registry/RTM.json` reports
`bidirectional: false`, which is the truthful value for a registry in which no
requirement is linked to an implementation artifact.

### Compatibility

`merkle_root` and `language_profile_hash` produce different values, so
persisted graphs must be reindexed and any stored Merkle root recomputed.
Freshness reports `PROFILE_STALE` for graphs indexed before this version, which
is the intended signal. Historical receipts are not evidence for this subject.

### Rollback path

Retain the input archive. Restoring 1.7.1 reintroduces every defect listed
above; never reuse 1.7.2 receipts, context IDs or Merkle roots as 1.7.1
evidence.

### Validation

See `../AUDIT_REPORT.md` and the delivered verification evidence for exact
counts and host limitations. Production remains NO_GO.

## 1.7.1 — 2026-09-08

First efficacy and truth-to-name audit.

| surface | from | to | breaking | migration | evidence |
|---|---|---|---|---|---|
| graph_schema | 1.3.0 | 1.3.0 | no | reindex under indexer 1.2.0 / extractor 1.1.0 | `../AUDIT_REPORT.md`, `../audit/findings/` |

- Changed: enforce content/binding correspondence, context freshness, graph traversal limits, source-aware Python imports, stable retrieval citations, narrowed permissions, reviewed change bytes, honest rollback and model/evaluation accounting. Repair portable fixture cleanup and verification coverage.
- Breaking behavior: mismatched source hashes or snapshot bindings are rejected; stale or incomplete context is no longer CURRENT; unknown/mismatched policy actions fail; changed snapshots report a full rebuild; unexercised benchmark targets do not pass. New workflow refusal/incomplete outcomes are explicit.
- Compatibility: persisted graphs require reindexing under indexer 1.2.0/extractor 1.1.0; historical receipts are not evidence for this patched subject. Regenerate current observations without granting acceptance.
- Rollback path: retain the original input ZIP and historical evidence. Restoring the old runtime reintroduces the documented defects; never reuse newer receipts against older code.
- Validation: see `../AUDIT_REPORT.md` at repository root and the delivered verification evidence for exact counts and host limitations. Production remains NO_GO.

## 1.3.1 — 2026-09-05

Post-application hardening patch. Runtime package version moves from 1.3.0 to
1.3.1 and the internal indexer identity algorithm moves from 1.0.0 to 1.1.0.
The graph schema remains 1.3.0 and no graph-store migration is required.

| surface | from | to | breaking | migration | evidence |
|---|---|---|---|---|---|
| connectors | 1.0.0 | 1.0.1 | no | none | `tests/test_adversarial.py`, `tests/test_verify.py`, `tests/test_e2e.py`, `AUDIT_FIX_REPORT_v1.3.1.md` |

### Compatibility impact

No node/edge type or identity field changed. Context IDs intentionally change
when any admitted connector evidence changes, including pathless authorized
history/external records. Unknown or unsupported CLI connectors now fail
closed rather than yielding an empty-success result. External records supplied
through the Python pipeline must have a non-empty stable `id` and be
canonical-JSON serializable.

### Security and integrity fixes

- bound all admitted connector evidence into context identity;
- made overlapping connector ingestion independent of connector order;
- enforced read permission, path scope, source-system scope and external-source
  scope at query/retrieval time;
- confined runtime roots before filesystem enumeration or Git execution and
  repeated authorization at time of use;
- rejected Git option-like revisions and unstable external record identities;
- added explicit external connector inputs to the governed pipeline;
- added a cross-platform Python CI runner and Windows launcher.

### Rollback path

Restore the v1.3.0 runtime files while leaving the immutable v1.3.0
control-plane package untouched. Because v1.3.1 changes connector/indexer
identity behavior, do not reuse v1.3.1 context IDs or evidence as v1.3.0
evidence after rollback.

## 1.3.0 — 2026-09-05

Initial implementation of the Repository Context Graph for Cross-File Changes
against the JA21/DeepML specification corpus.

| surface | from | to | breaking | migration | evidence |
|---|---|---|---|---|---|
| graph_schema | — | 1.3.0 | n/a (initial) | `registry/MIGRATIONS.json` stores.graph v1→v3 | `registry/ONTOLOGY.json`, `tests/test_unit.py::TestGraph` |
| api_contracts | — | 1.0.0 | n/a (initial) | none | `rcg/schemas.py` (9 contracts), `tests/test_unit.py::TestSchemas` |
| prompts | — | 1.0.0 | n/a (initial) | none | `docs/DOC-06-model-tool-inventory.md` prompt digests |
| policies | — | 1.0.0 | n/a (initial) | none | `registry/CONTROLS.json` (7 controls), `tests/test_adversarial.py` |
| connectors | — | 1.0.0 | n/a (initial) | none | `registry/`/`docs/DOC-03-connector-inventory.md` (9 connectors) |
| models | — | pinned per run | n/a | none | No production provider bound; the default provider abstains |
| benchmark_baselines | — | 1.0.0 | n/a (initial) | none | `eval/benchmark.py`, `eval/corpus.py` (20 cases) |

### Compatibility impact

None: this is the first version of every surface.

### Benchmark deltas

No prior baseline. The first measured values are recorded by
`python3 eval/benchmark.py` and gate CI from this version forward.

### Rollback path

The overlay lives entirely under `Repository Context Graph/`. The 66 suite
folders of the specification corpus are byte-identical to the baseline, so
rollback is the removal of the overlay directory; nothing else was touched.
See `docs/DOC-11-incident-rollback-runbook.md`.
