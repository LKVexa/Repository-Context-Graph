# Requirement traceability

Requirement → implementation → verification, for all **217** tasks of the
Repository Context Graph Prompt/Workflow Master v1.3.0. Generated from the
scheduler and the control-plane check registry, so a requirement whose check
disappears also disappears from this table.

Live per-task verdicts, with the evidence digest for each, are in
`control-plane/run/<RUN_ID>/RUN_SUMMARY.json` and the immutable attempt
directories beside it.

## Phase 0 — Audit hardening and requirements control

| task | requirement | verification evidence |
|---|---|---|
| `AUD-001` | Assign stable IDs to every currently anonymous checklist requirement. | `registry/REQUIREMENTS.json`, `test_governance.TestAud001And002RegistryAndRtm` |
| `AUD-002` | Create a bidirectional requirements traceability matrix from source requirement → implementation | `registry/RTM.json`, `test_governance.TestAud001And002RegistryAndRtm` |
| `AUD-003` | Define owners and accountable reviewers for every requirement and phase. | `registry/OWNERS.json`, `test_governance.TestAud003Owners` |
| `AUD-004` | Formalize the repository graph ontology, including node/edge types, stable identity, rename/move | `registry/ONTOLOGY.json`, `test_governance.TestAud004OntologyRoundTrip` |
| `AUD-005` | Define language/build-system support tiers and parser fallback behavior. | `registry/LANGUAGE_TIERS.json`, `test_governance.TestAud005LanguageTiers` |
| `AUD-006` | Define performance, scale, freshness, and availability objectives for graph build, incremental u | `eval/benchmark.py ..`, `registry/SLO.json`, `test_governance.TestAud006And014BenchmarksAndBudgets` |
| `AUD-007` | Define consistency, concurrency, event-ordering, and recovery semantics for incremental graph up | `test_governance.TestAud007ConcurrencyAndConvergence` |
| `AUD-008` | Add backup, restore, disaster-recovery, and corruption-recovery requirements for persistent grap | `test_governance.TestAud008BackupRestore`, `Restoring the store`, `docs/DOC-11-incident-rollback-runbook.md` |
| `AUD-009` | Define schema/data migrations for graph, provenance, workflow state, and storage—not only API co | `test_governance.TestAud009Migrations`, `registry/MIGRATIONS.json` |
| `AUD-010` | Define connector resilience rules: pagination, rate limits, retries, backoff, partial failures,  | `test_governance.TestAud010ConnectorResilience`, `tombstone credential expiry`, `docs/DOC-03-connector-inventory.md` |
| `AUD-011` | Add graph lifecycle and garbage-collection rules for deleted branches, removed files, closed PRs | `test_governance.TestAud011Lifecycle`, `registry/LIFECYCLE.json` |
| `AUD-012` | Define quantitative acceptance thresholds for grounding, false positives/negatives, abstention,  | `registry/THRESHOLDS.json`, `test_governance.TestAud018ReleasePolicy` |
| `AUD-013` | Add software-supply-chain controls for dependencies, parser/tool binaries, containers, and build | `registry/SUPPLY_CHAIN.json`, `test_governance.TestAud013SupplyChain`, `test_supply_chain.TestSupplyChain` |
| `AUD-014` | Define cost/resource budgets for indexing, storage, retrieval, model calls, and impact analysis. | `registry/BUDGETS.json`, `test_governance.TestAud006And014BenchmarksAndBudgets` |
| `AUD-015` | Define rollout controls for feature flags, staged enablement, read-only/draft-only modes, canary | `registry/ROLLOUT.json`, `test_governance.TestAud015Rollout` |
| `AUD-016` | Create representative golden repositories and synthetic fixtures covering mono-repos, polyglot r | `test_governance.TestAud016Fixtures` |
| `AUD-017` | Define review-UI usability/accessibility criteria for evidence inspection, scope narrowing, unce | `test_governance.TestAud017ReviewSurface`, `docs/DOC-09-human-approval-policy.md` |
| `AUD-018` | Define release/versioning/changelog policy for graph schema, APIs, prompts, policies, connectors | `test_governance.TestAud018ReleasePolicy`, `Rollback path breaking`, `docs/CHANGELOG.md`, `registry/RELEASE_POLICY.json` |

## Phase 1 — Authority, scope, identity & workflow state

| task | requirement | verification evidence |
|---|---|---|
| `IMPL-01` | Define a machine-readable scope contract for the Repository Context Graph for Cross-File Changes | `test_unit.TestScope` |
| `IMPL-02` | Define canonical input/output schemas and validate all connector/tool payloads. | `test_unit.TestSchemas` |
| `IMPL-03` | Create a versioned workflow state machine with explicit start, analysis, review, approval, and t | `test_unit.TestWorkflow` |
| `FLOW-01` | Authenticate and establish authority. | `test_e2e.TestE2E06RollbackAbort` |
| `FLOW-02` | Pin the target artifacts and revisions. | `test_verify.TestVerify05ReproducibleForAPinnedRevision` |
| `API-01` | Versioned API contracts for all inbound and outbound integrations. | `test_unit.TestSchemas`, `docs/DOC-08-run-state-schema.md` |
| `API-02` | Explicit schema for scope/authority. | `test_unit.TestScope` |
| `API-05` | Explicit schema for human review decision and approver identity. | `test_adversarial.TestAdv07FalseHumanApprovalClaims` |
| `XAUTH-01` | Authenticate human users and service identities. | `test_unit.TestScope`, `test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls` |
| `XAUTH-02` | Authorize every data source and action independently. | `test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls` |
| `XAUTH-03` | Separate read, analyze, draft, modify, commit, approve, deploy, and communicate permissions. | `test_unit.TestScope`, `privileged`, `docs/DOC-04-permission-matrix.md` |
| `XAUTH-04` | Default to read-only access where the paper requires it. | `test_unit.TestScope`, `read_only draft_only`, `docs/DOC-04-permission-matrix.md` |
| `XAUTH-05` | Use narrowly scoped, short-lived credentials where execution is unavoidable. | `test_unit.TestScope` |
| `XAUTH-06` | Enforce repository/service/data boundaries in infrastructure, not only in model prompts. | `test_adversarial.TestAdv01MaliciousRepositoryInstructions` |
| `XAUTH-07` | Record the human authority under which every privileged action occurs. | `test_e2e.TestInt01Integration` |

## Phase 2 — Connectors, artifact identity & provenance

| task | requirement | verification evidence |
|---|---|---|
| `DATA-01` | Source code and symbols | `test_governance.TestDataConnectorFixtures` |
| `DATA-02` | Build/dependency metadata | `test_governance.TestDataConnectorFixtures` |
| `DATA-03` | Tests | `test_governance.TestDataConnectorFixtures` |
| `DATA-04` | Git history | `test_governance.TestDataConnectorFixtures` |
| `DATA-05` | PRs and review comments | `test_governance.TestDataConnectorFixtures` |
| `DATA-06` | ADRs | `test_governance.TestDataConnectorFixtures` |
| `DATA-07` | Bug/issue tracker | `test_governance.TestDataConnectorFixtures` |
| `DATA-08` | Code owners | `test_governance.TestDataConnectorFixtures` |
| `DATA-09` | Optional approved design discussions | `test_governance.TestDataConnectorFixtures` |
| `COMP-04` | Artifact linker/entity resolver | `test_verify.TestVerify04StaleAndMissingMarked` |
| `COMP-10` | Provenance service | _family checks_ |
| `ARCH-01` | Connector/adaptor layer for authorized source systems | `docs/DOC-03-connector-inventory.md`, `test_governance.TestAud010ConnectorResilience` |
| `ARCH-02` | Canonical artifact and identity layer | `test_unit.TestCanonical` |
| `IMPL-04` | Create a provenance model linking generated outputs to source artifacts, analyzer results, and h | `test_unit.TestProvenance`, `docs/DOC-07-provenance-schema.md` |
| `FLOW-03` | Collect only authorized evidence. | `test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls` |
| `FLOW-04` | Normalize and index the evidence. | `test_verify.TestVerify01EdgesTraceToSource` |
| `API-03` | Explicit schema for evidence/provenance references. | `test_unit.TestSchemas` |
| `STORE-03` | Evidence/provenance records. | `test_unit.TestProvenance` |
| `XPROV-01` | Assign stable identity/version metadata to every source artifact. | `test_verify.TestVerify01EdgesTraceToSource` |
| `XPROV-02` | Preserve source revision, timestamp, and freshness metadata. | `test_verify.TestVerify02IncrementalAndRevisionAware` |
| `XPROV-03` | Link every material AI finding to supporting evidence. | `test_adversarial.TestAdv06HallucinatedProvenance` |
| `XPROV-04` | Distinguish source-derived facts from model inference. | `test_unit.TestProvenance` |
| `XPROV-05` | Preserve deterministic analyzer output separately from model synthesis. | `test_unit.TestProvenance` |
| `XPROV-06` | Maintain an immutable or append-only activity/evidence log. | `test_unit.TestProvenance` |
| `XPROV-07` | Support export of an auditable case file for human review. | `test_e2e.TestInt01Integration` |

## Phase 3 — Graph ingestion & persistent state

| task | requirement | verification evidence |
|---|---|---|
| `PAPER-CAP-01` | Parse source and build metadata into a persistent code graph. | `test_e2e.TestE2E01GoldenPath` |
| `COMP-01` | Language parsers and symbol extractors | `test_unit.TestParsers` |
| `COMP-02` | AST/symbol/dependency graph builder | `test_unit.TestGraph`, `test_verify.TestVerify01EdgesTraceToSource` |
| `COMP-03` | Temporal graph/version store | `test_unit.TestVersionStore` |
| `ARCH-03` | Persistent state/context store | `test_unit.TestVersionStore` |
| `STORE-01` | Persistent workflow/run state. | `test_unit.TestWorkflow` |
| `STORE-02` | Versioned artifact metadata and source pointers. | `test_verify.TestVerify02IncrementalAndRevisionAware`, `test_unit.TestVersionStore` |

## Phase 4 — Historical context, retrieval & query

| task | requirement | verification evidence |
|---|---|---|
| `PAPER-CAP-03` | Attach rationale from PR discussions, ADRs, and linked bugs. | `test_governance.TestDataConnectorFixtures` |
| `COMP-05` | Semantic retrieval index | `test_adversarial.TestAdv02MissingStaleConflictingEvidence` |
| `COMP-06` | Historical-rationale extractor | _family checks_ |
| `COMP-07` | Graph query layer | `test_verify.TestVerify05ReproducibleForAPinnedRevision` |
| `ARCH-04` | Retrieval/graph/query layer as appropriate | `test_verify.TestVerify04StaleAndMissingMarked` |

## Phase 5 — Incremental updates & impact analysis

| task | requirement | verification evidence |
|---|---|---|
| `PAPER-CAP-02` | Update the graph as code changes. | `test_verify.TestVerify02IncrementalAndRevisionAware` |
| `PAPER-CAP-04` | Compute an impact report before drafting a patch. | `test_verify.TestVerify03ImpactDirectAndTransitive` |
| `COMP-08` | Incremental graph updater | `test_governance.TestAud007ConcurrencyAndConvergence` |
| `COMP-09` | Impact analysis engine | `test_verify.TestVerify03ImpactDirectAndTransitive` |

## Phase 6 — Deterministic analysis, model reasoning & uncertainty

| task | requirement | verification evidence |
|---|---|---|
| `PAPER-CAP-05` | Flag missing context rather than guessing. | `test_e2e.TestE2E05MissingContextAbstention` |
| `ARCH-05` | Deterministic analysis/tool layer | `test_e2e.TestInt01Integration` |
| `ARCH-06` | Model reasoning/orchestration layer | `test_adversarial.TestAdv06HallucinatedProvenance` |
| `IMPL-07` | Implement an uncertainty/abstention mechanism for insufficient evidence and out-of-scope request | `test_unit.TestUncertainty` |
| `FLOW-05` | Run deterministic analysis first where applicable. | `test_e2e.TestInt01Integration` |
| `FLOW-06` | Run model reasoning only over authorized, provenance-bearing context. | `test_adversarial.TestAdv01MaliciousRepositoryInstructions` |
| `FLOW-07` | Generate a bounded draft/recommendation/artifact. | `test_e2e.TestE2E01GoldenPath` |
| `API-04` | Explicit schema for uncertainty/confidence and abstention reason. | `test_unit.TestUncertainty`, `test_unit.TestSchemas` |
| `MODEL-01` | Model choice is version-pinned and recorded per run. | `test_adversarial.TestAdv06HallucinatedProvenance`, `prompt id abstain`, `docs/DOC-06-model-tool-inventory.md` |
| `MODEL-02` | System prompts encode scope, evidence, uncertainty, and abstention rules. | `test_adversarial.TestAdv06HallucinatedProvenance`, `prompt id abstain`, `docs/DOC-06-model-tool-inventory.md` |
| `MODEL-03` | Retrieval context is source-labeled. | `test_adversarial.TestAdv06HallucinatedProvenance`, `prompt id abstain`, `docs/DOC-06-model-tool-inventory.md` |
| `MODEL-04` | Structured outputs are schema-validated. | `test_adversarial.TestAdv06HallucinatedProvenance`, `prompt id abstain`, `docs/DOC-06-model-tool-inventory.md` |
| `MODEL-05` | High-impact conclusions require supporting evidence references. | `test_adversarial.TestAdv06HallucinatedProvenance`, `prompt id abstain`, `docs/DOC-06-model-tool-inventory.md` |
| `MODEL-06` | Model cannot directly grant itself additional permissions. | `test_adversarial.TestAdv07FalseHumanApprovalClaims` |
| `MODEL-07` | Evaluation includes hallucination, overreach, and stale-context cases. | `test_adversarial.TestAdv06HallucinatedProvenance`, `prompt id abstain`, `docs/DOC-06-model-tool-inventory.md` |
| `XUNC-01` | Represent known, supported, inferred, uncertain, stale, missing, and out-of-scope states. | `test_unit.TestUncertainty` |
| `XUNC-02` | Calibrate confidence against validation data where quantitative scores are shown. | `test_unit.TestUncertainty` |
| `XUNC-03` | Surface missing context instead of filling gaps silently. | `test_adversarial.TestAdv02MissingStaleConflictingEvidence` |
| `XUNC-04` | Define stop/abstain thresholds. | `test_unit.TestUncertainty` |
| `XUNC-05` | Route high-impact or ambiguous cases to human review. | `test_unit.TestUncertainty` |
| `XUNC-06` | Never present unsupported assumptions as facts. | `test_adversarial.TestAdv06HallucinatedProvenance` |
| `XTOOL-01` | Use deterministic analyzers before probabilistic reasoning where applicable. | `test_e2e.TestInt01Integration` |
| `XTOOL-05` | Implement retrieval/source ranking and stale-source detection. | `test_adversarial.TestAdv02MissingStaleConflictingEvidence` |
| `XTOOL-06` | Track model/tool versions for every run. | `test_e2e.TestInt01Integration` |
| `XTOOL-07` | Provide fallback behavior when a model or connector fails. | `test_e2e.TestE2E04ToolFailure` |

## Phase 7 — Human review, policy & approval control

| task | requirement | verification evidence |
|---|---|---|
| `PAPER-GRD-01` | No modifications outside the approved task. | `test_adversarial.TestAdv03OversizedScope`, `registry/CONTROLS.json` |
| `PAPER-GRD-02` | No substantial structural change without interactive scoping. | `test_adversarial.TestAdv03OversizedScope`, `registry/CONTROLS.json` |
| `PAPER-GRD-03` | Do not introduce design decisions that diverge from established conventions without approval. | `test_adversarial.TestAdv03OversizedScope`, `registry/CONTROLS.json` |
| `PAPER-GRD-04` | All diffs remain human-reviewable. | `test_adversarial.TestAdv03OversizedScope`, `registry/CONTROLS.json` |
| `ARCH-07` | Policy/authority enforcement layer | _family checks_ |
| `ARCH-09` | Human review and approval interface | `test_governance.TestAud017ReviewSurface` |
| `IMPL-06` | Create a policy layer that converts paper guardrails into enforceable permissions and stop condi | `test_adversarial.TestAdv03OversizedScope` |
| `IMPL-08` | Provide a human review surface that exposes evidence, rationale, changed artifacts, uncertainty, | `test_governance.TestAud017ReviewSurface`, `test_e2e.TestE2E01GoldenPath` |
| `FLOW-09` | Expose evidence, uncertainty, scope, and verification results to the human reviewer. | `test_e2e.TestE2E01GoldenPath`, `test_governance.TestAud017ReviewSurface` |
| `FLOW-10` | Require the paper-specified human decision/approval before any subsequent state change. | `test_unit.TestWorkflow`, `test_adversarial.TestAdv07FalseHumanApprovalClaims` |
| `HUMAN-01` | Reviewer can inspect original evidence. | `test_e2e.TestE2E01GoldenPath` |
| `HUMAN-02` | Reviewer can see exactly what the system did and did not analyze. | `test_e2e.TestE2E01GoldenPath` |
| `HUMAN-03` | Reviewer can narrow scope and rerun. | `test_e2e.TestE2E03ScopeNarrowing` |
| `HUMAN-04` | Reviewer can reject without side effects. | `test_e2e.TestE2E02HumanRejection` |
| `HUMAN-05` | Reviewer can require additional evidence. | `test_governance.TestAud017ReviewSurface` |
| `HUMAN-06` | Approval identity, timestamp, and approved scope are recorded. | `test_adversarial.TestAdv07FalseHumanApprovalClaims` |
| `HUMAN-07` | Final accountability is never represented as belonging to the AI. | `test_governance.TestAud017ReviewSurface` |
| `XHITL-01` | Provide preview before state-changing actions. | `test_e2e.TestE2E01GoldenPath` |
| `XHITL-02` | Require explicit approval at the paper-specified human gates. | `test_unit.TestWorkflow` |
| `XHITL-03` | Support approve, reject, edit, narrow scope, and request-more-evidence operations. | `test_e2e.TestE2E03ScopeNarrowing` |
| `XHITL-04` | Keep final accountability visible in the UI and audit record. | `test_governance.TestAud017ReviewSurface` |
| `XHITL-05` | Prevent the AI from approving or attesting to its own work where prohibited. | `test_adversarial.TestAdv07FalseHumanApprovalClaims` |

## Phase 8 — Security, privacy & sandboxing

| task | requirement | verification evidence |
|---|---|---|
| `STORE-06` | Retention, deletion, and privacy controls. | `test_governance.TestAud011Lifecycle` |
| `SEC-01` | Prompt injection from repository/docs/tickets/logs is treated as untrusted input. | `test_adversarial.TestAdv01MaliciousRepositoryInstructions` |
| `SEC-02` | Tool-call argument validation blocks command/path/scope injection. | `test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls` |
| `SEC-03` | Secrets are never copied into model context unless explicitly required and protected. | `test_adversarial.TestAdv05SensitiveDataLeakage` |
| `SEC-04` | Cross-project/tenant data leakage tests exist. | `test_adversarial.TestAdv05SensitiveDataLeakage` |
| `SEC-05` | Unauthorized write attempts fail closed. | `test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls` |
| `SEC-06` | Sensitive generated output is classified before display/export. | `test_adversarial.TestAdv05SensitiveDataLeakage` |
| `SEC-07` | Human approval tokens cannot be fabricated by model output. | `test_adversarial.TestAdv07FalseHumanApprovalClaims` |
| `SEC-08` | Audit records cannot be modified by the model. | `test_unit.TestProvenance` |
| `XSEC-01` | Classify data before model/tool access. | `test_adversarial.TestAdv05SensitiveDataLeakage`, `Residual risk`, `docs/DOC-05-threat-model.md` |
| `XSEC-02` | Redact or exclude sensitive data where not required. | `test_adversarial.TestAdv05SensitiveDataLeakage`, `Residual risk`, `docs/DOC-05-threat-model.md` |
| `XSEC-03` | Prevent cross-tenant/project leakage. | `test_adversarial.TestAdv05SensitiveDataLeakage`, `Residual risk`, `docs/DOC-05-threat-model.md` |
| `XSEC-04` | Encrypt data in transit and at rest. | _declared blocker — see status reason_ |
| `XSEC-05` | Keep secrets out of prompts, logs, generated artifacts, and model context. | `test_adversarial.TestAdv05SensitiveDataLeakage`, `Residual risk`, `docs/DOC-05-threat-model.md` |
| `XSEC-06` | Maintain configurable retention and deletion policies. | `test_governance.TestAud011Lifecycle`, `Residual risk`, `docs/DOC-05-threat-model.md` |
| `XSEC-07` | Threat-model prompt injection and malicious repository/artifact content. | `test_adversarial.TestAdv01MaliciousRepositoryInstructions`, `Residual risk`, `docs/DOC-05-threat-model.md` |
| `XTOOL-02` | Validate tool inputs and outputs against schemas. | `test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls`, `test_unit.TestSchemas` |
| `XTOOL-03` | Sandbox code execution and untrusted artifact processing. | _family checks_ |
| `XTOOL-04` | Bound token/context retrieval to authorized material. | `test_verify.TestVerify04StaleAndMissingMarked`, `test_unit.TestScope` |

## Phase 9 — Observability, audit & reproducibility

| task | requirement | verification evidence |
|---|---|---|
| `ARCH-08` | Provenance/evidence ledger | `test_unit.TestProvenance` |
| `ARCH-10` | Observability/evaluation subsystem | _family checks_ |
| `IMPL-05` | Implement source freshness and revision pinning so analyses can be reproduced. | `test_verify.TestVerify02IncrementalAndRevisionAware` |
| `IMPL-09` | Implement audit logging for retrievals, model/tool calls, generated artifacts, approvals, overri | `test_e2e.TestInt01Integration` |
| `FLOW-11` | Record the full evidence and decision trail. | `test_e2e.TestInt01Integration` |
| `API-06` | Idempotency support for retried workflow steps. | `test_unit.TestWorkflow`, `test_unit.TestSchemas` |
| `API-07` | Immutable run ID and artifact IDs. | `test_unit.TestCanonical` |
| `API-08` | Backward-compatible versioning or migration plan. | `test_governance.TestAud009Migrations`, `registry/RELEASE_POLICY.json` |
| `STORE-04` | Human approval/rejection history. | `test_adversarial.TestAdv07FalseHumanApprovalClaims` |
| `STORE-05` | Model/tool version metadata. | `test_e2e.TestInt01Integration` |
| `STORE-07` | Append-only audit trail for privileged actions. | `test_unit.TestProvenance` |
| `XSTATE-01` | Pin repository/data revisions used for analysis. | `test_verify.TestVerify05ReproducibleForAPinnedRevision` |
| `XSTATE-02` | Version prompts, models, tools, policies, and schemas. | `test_e2e.TestInt01Integration` |
| `XSTATE-03` | Store workflow state so an interrupted run can be reconstructed. | `test_unit.TestWorkflow` |
| `XSTATE-04` | Make generated artifacts reproducible from recorded inputs where feasible. | `test_verify.TestVerify05ReproducibleForAPinnedRevision` |
| `XSTATE-05` | Use deterministic IDs for runs, artifacts, findings, and approvals. | `test_unit.TestCanonical` |
| `XOBS-01` | Emit structured logs for workflow state transitions. | `test_e2e.TestInt01Integration` |
| `XOBS-02` | Measure latency, cost, tool failures, abstention, approval, and override rates. | `test_e2e.TestInt01Integration` |
| `XOBS-03` | Track false-positive/false-negative rates where ground truth exists. | `test_e2e.TestInt01Integration` |
| `XOBS-04` | Alert on abnormal permission use or unexpected write attempts. | `test_e2e.TestInt01Integration` |
| `XOBS-05` | Provide run-level tracing across retrieval, tools, model calls, and approvals. | `test_e2e.TestInt01Integration` |

## Phase 10 — Verification, testing & evaluation

| task | requirement | verification evidence |
|---|---|---|
| `IMPL-10` | Define an offline benchmark and regression suite before enabling production use. | `eval/benchmark.py ..` |
| `FLOW-08` | Verify the output using independent tools or checks. | `test_e2e.TestE2E01GoldenPath` |
| `VERIFY-01` | Graph edges are traceable to source artifacts | `test_verify.TestVerify01EdgesTraceToSource` |
| `VERIFY-02` | Graph updates are incremental and revision-aware | `test_verify.TestVerify02IncrementalAndRevisionAware` |
| `VERIFY-03` | Impact reports identify direct and transitive dependents | `test_verify.TestVerify03ImpactDirectAndTransitive` |
| `VERIFY-04` | Stale/missing source context is marked | `test_verify.TestVerify04StaleAndMissingMarked` |
| `VERIFY-05` | Queries reproduce consistent results for a pinned repository revision | `test_verify.TestVerify05ReproducibleForAPinnedRevision` |
| `TEST-UNIT-01` | Parsers, schema validators, policy checks, scoring logic, provenance links, and state transition | `test_unit` |
| `TEST-INT-01` | Connectors, retrieval, deterministic analyzers, model orchestration, review UI, and audit storag | `test_e2e.TestInt01Integration` |
| `TEST-ADV-01` | Malicious repository/document instructions. | `test_adversarial.TestAdv01MaliciousRepositoryInstructions` |
| `TEST-ADV-02` | Missing/stale/conflicting evidence. | `test_adversarial.TestAdv02MissingStaleConflictingEvidence` |
| `TEST-ADV-03` | Oversized scope requests. | `test_adversarial.TestAdv03OversizedScope` |
| `TEST-ADV-04` | Unauthorized write/tool calls. | `test_adversarial.TestAdv04UnauthorizedWriteAndToolCalls` |
| `TEST-ADV-05` | Sensitive-data leakage. | `test_adversarial.TestAdv05SensitiveDataLeakage` |
| `TEST-ADV-06` | Hallucinated provenance. | `test_adversarial.TestAdv06HallucinatedProvenance` |
| `TEST-ADV-07` | False human-approval claims. | `test_adversarial.TestAdv07FalseHumanApprovalClaims` |
| `TEST-E2E-01` | Golden-path scenario. | `test_e2e.TestE2E01GoldenPath`, `sh environments/ci.sh` |
| `TEST-E2E-02` | Human rejection scenario. | `test_e2e.TestE2E02HumanRejection`, `sh environments/ci.sh` |
| `TEST-E2E-03` | Human scope-narrowing scenario. | `test_e2e.TestE2E03ScopeNarrowing`, `sh environments/ci.sh` |
| `TEST-E2E-04` | Tool failure scenario. | `test_e2e.TestE2E04ToolFailure`, `sh environments/ci.sh` |
| `TEST-E2E-05` | Missing-context abstention scenario. | `test_e2e.TestE2E05MissingContextAbstention`, `sh environments/ci.sh` |
| `TEST-E2E-06` | Rollback/abort scenario. | `test_e2e.TestE2E06RollbackAbort`, `sh environments/ci.sh` |
| `XEVAL-01` | Build a representative offline evaluation corpus. | `docs/DOC-10-evaluation-plan.md` |
| `XEVAL-02` | Include adversarial, ambiguous, stale, incomplete, and out-of-scope cases. | _family checks_ |
| `XEVAL-03` | Measure grounding/provenance correctness. | `registry/THRESHOLDS.json`, `test_verify.TestVerify01EdgesTraceToSource` |
| `XEVAL-04` | Measure human review burden, not only task completion. | `test_governance.TestAud017ReviewSurface` |
| `XEVAL-05` | Validate that guardrails fail closed. | `test_adversarial.TestAdv03OversizedScope` |
| `XEVAL-06` | Run pilot deployment under read-only/draft-only permissions before broader rollout. | _declared blocker — see status reason_ |
| `XEVAL-07` | Require documented acceptance criteria and rollback procedure before production use. | `registry/THRESHOLDS.json`, `Rollback`, `docs/DOC-11-incident-rollback-runbook.md`, `test_governance.TestAud018ReleasePolicy` |

## Phase 11 — Deployment environments & documentation

| task | requirement | verification evidence |
|---|---|---|
| `ENV-01` | Developer/local sandbox. | `developer_local_sandbox`, `environments/ENVIRONMENTS.json` |
| `ENV-02` | CI validation environment. | `environments/ci.sh`, `sh environments/ci.sh` |
| `ENV-03` | Staging/pre-production environment. | _declared blocker — see status reason_ |
| `ENV-04` | Production read-only integration where applicable. | _declared blocker — see status reason_ |
| `ENV-05` | Separate privileged execution path only where explicitly authorized. | _declared blocker — see status reason_ |
| `ENV-06` | Isolated test tenant/data set for privacy/security validation. | `isolated_test_tenant`, `environments/ENVIRONMENTS.json`, `test_adversarial.TestAdv05SensitiveDataLeakage` |
| `DOC-01` | Architecture diagram. | `docs/DOC-01-architecture.md`, `DOC-01-architecture.md` |
| `DOC-02` | Data-flow and trust-boundary diagram. | `docs/DOC-02-dataflow-trust-boundaries.md`, `DOC-02-dataflow-trust-boundaries.md` |
| `DOC-03` | Source/connector inventory. | `docs/DOC-03-connector-inventory.md`, `DOC-03-connector-inventory.md` |
| `DOC-04` | Permission matrix. | `docs/DOC-04-permission-matrix.md`, `DOC-04-permission-matrix.md` |
| `DOC-05` | Threat model. | `docs/DOC-05-threat-model.md`, `DOC-05-threat-model.md` |
| `DOC-06` | Model/tool inventory. | `docs/DOC-06-model-tool-inventory.md`, `DOC-06-model-tool-inventory.md` |
| `DOC-07` | Provenance schema. | `docs/DOC-07-provenance-schema.md`, `DOC-07-provenance-schema.md` |
| `DOC-08` | Run-state schema. | `docs/DOC-08-run-state-schema.md`, `DOC-08-run-state-schema.md` |
| `DOC-09` | Human approval policy. | `docs/DOC-09-human-approval-policy.md`, `DOC-09-human-approval-policy.md` |
| `DOC-10` | Evaluation plan and benchmark corpus description. | `docs/DOC-10-evaluation-plan.md`, `DOC-10-evaluation-plan.md` |
| `DOC-11` | Incident/rollback runbook. | `docs/DOC-11-incident-rollback-runbook.md`, `DOC-11-incident-rollback-runbook.md` |
| `DOC-12` | Known limitations and non-goals. | `docs/DOC-12-known-limitations-non-goals.md`, `DOC-12-known-limitations-non-goals.md` |

## Phase 12 — Production readiness & release gate

| task | requirement | verification evidence |
|---|---|---|
| `FLOW-12` | Rollback/abort cleanly if scope, evidence, authorization, or verification conditions fail. | `test_e2e.TestE2E06RollbackAbort`, `test_unit.TestWorkflow`, `Rollback`, `docs/DOC-11-incident-rollback-runbook.md` |
| `PROD-01` | All paper-stated guardrails are implemented as enforceable controls. | _declared blocker — see status reason_ |
| `PROD-02` | Evaluation demonstrates acceptable grounding and false-positive behavior. | _declared blocker — see status reason_ |
| `PROD-03` | No hidden write authority exists outside approved workflows. | _declared blocker — see status reason_ |
| `PROD-04` | Every material output is traceable to evidence. | _declared blocker — see status reason_ |
| `PROD-05` | Human approval gates have been tested for bypass resistance. | _declared blocker — see status reason_ |
| `PROD-06` | Rollback and incident procedures are documented and exercised. | _declared blocker — see status reason_ |
| `PROD-07` | Security/privacy review is complete. | _declared blocker — see status reason_ |
| `PROD-08` | Known limitations and non-goals are published. | _declared blocker — see status reason_ |
