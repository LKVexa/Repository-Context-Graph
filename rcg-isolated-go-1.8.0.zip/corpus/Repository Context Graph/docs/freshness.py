#!/usr/bin/env python3
"""Generated-artifact freshness with four distinct states (GO-01-11).

There is a trap in this repository that v1.4.0 walked into and had to back out
of: ``DOC-04`` and ``DOC-12`` were edited directly, and the next
``generate_docs.py`` run silently reverted both. The generator is the source of
truth; the file is an output. Editing the output looks like it worked, right up
until CI regenerates.

Four states, four different remediations, because "out of date" is not one
problem:

``CURRENT``    the artifact matches its declared sources.
``ABSENT``     the artifact does not exist -- regenerate.
``STALE``      a declared source moved -- regenerate, and review the diff.
``DRIFTED``    the artifact was edited by hand -- **the edit will be lost**;
               move the change into the generator first.
``UNREADABLE`` the artifact exists but cannot be parsed -- restore it.

``DRIFTED`` is the one that matters. It is the failure mode that silently loses
work, and it is the reason each artifact embeds the digests of the sources it
was generated from.

Adapted from the Scoped PR Builder's ``adapters/documentation.py``, whose
freshness receipt distinguishes exactly these states and makes a stale document
block the release gate.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

HERE = Path(__file__).resolve().parent
OVERLAY = HERE.parent
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

CURRENT, ABSENT, STALE, DRIFTED, UNREADABLE = "CURRENT", "ABSENT", "STALE", "DRIFTED", "UNREADABLE"

REMEDIATION = {
    CURRENT: "nothing to do",
    ABSENT: "run docs/generate_docs.py to create it",
    STALE: "a declared source changed; regenerate and review the diff",
    DRIFTED: ("this generated file was edited by hand and the edit WILL be lost on the next "
              "regeneration; move the change into docs/generate_docs.py, then regenerate"),
    UNREADABLE: "the file exists but its front matter cannot be read; restore it from the generator",
}

#: Which registries each generated document is derived from. A document that
#: declares no sources is hand-written prose wearing a generated document's
#: front matter.
DECLARED_SOURCES: dict[str, tuple[str, ...]] = {
    "DOC-01-architecture.md": ("registry/CONTROLS.json", "registry/REQUIREMENTS.json"),
    "DOC-02-dataflow-trust-boundaries.md": ("registry/CONTROLS.json",),
    "DOC-03-connector-inventory.md": ("registry/SUPPLY_CHAIN.json",),
    "DOC-04-permission-matrix.md": ("registry/CONTROLS.json", "environments/ENVIRONMENTS.json"),
    "DOC-05-threat-model.md": ("registry/CONTROLS.json",),
    "DOC-06-model-tool-inventory.md": ("registry/THRESHOLDS.json",),
    "DOC-07-provenance-schema.md": ("registry/RTM.json",),
    "DOC-08-run-state-schema.md": ("registry/LIFECYCLE.json",),
    "DOC-09-human-approval-policy.md": ("registry/OWNERS.json", "registry/RELEASE_POLICY.json"),
    "DOC-10-evaluation-plan.md": ("registry/THRESHOLDS.json", "registry/SLO.json"),
    "DOC-11-incident-rollback-runbook.md": ("registry/ROLLOUT.json", "registry/SLO.json"),
    "DOC-12-known-limitations-non-goals.md": ("registry/SLO.json", "registry/THRESHOLDS.json",
                                              "registry/LANGUAGE_TIERS.json"),
    "DOC-13-operator-runbook.md": ("registry/ROLLOUT.json", "registry/OWNERS.json",
                                   "environments/ENVIRONMENTS.json"),
    "DOC-14-user-guide.md": ("registry/LANGUAGE_TIERS.json", "registry/SLO.json"),
}

FRONT_MATTER_START = "<!-- generated-from:"
FRONT_MATTER_END = "-->"


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_digests(name: str, *, root: Path = OVERLAY) -> dict[str, str]:
    return {source: (_digest(root / source) if (root / source).is_file() else "MISSING")
            for source in DECLARED_SOURCES.get(name, ())}


def front_matter(name: str, *, root: Path = OVERLAY) -> str:
    """The comment block every generated document carries."""
    payload = {"document": name, "sources": source_digests(name, root=root)}
    return (f"{FRONT_MATTER_START} "
            + json.dumps(payload, sort_keys=True, separators=(",", ":"))
            + f" {FRONT_MATTER_END}")


def _read_front_matter(text: str) -> dict[str, Any] | None:
    for line in text.splitlines():
        if line.startswith(FRONT_MATTER_START):
            body = line[len(FRONT_MATTER_START):].rstrip()
            if body.endswith(FRONT_MATTER_END):
                body = body[: -len(FRONT_MATTER_END)]
            try:
                return json.loads(body.strip())
            except json.JSONDecodeError:
                return None
    return None


def evaluate(name: str, *, docs_dir: Path = HERE, root: Path = OVERLAY) -> dict[str, Any]:
    """Classify one generated artifact."""
    path = docs_dir / name
    if not path.is_file():
        return {"document": name, "state": ABSENT, "remediation": REMEDIATION[ABSENT]}
    text = path.read_text(encoding="utf-8")
    declared = _read_front_matter(text)
    if declared is None:
        return {"document": name, "state": UNREADABLE, "remediation": REMEDIATION[UNREADABLE]}

    actual_sources = source_digests(name, root=root)
    if declared.get("sources") != actual_sources:
        moved = [s for s, d in actual_sources.items() if declared.get("sources", {}).get(s) != d]
        return {"document": name, "state": STALE, "moved_sources": moved,
                "remediation": REMEDIATION[STALE]}

    # DRIFTED: the sources agree, so the only way the body can differ from what
    # the generator produces is a hand edit.
    if str(HERE) not in sys.path:
        sys.path.insert(0, str(HERE))
    from generate_docs import DOCS, _with_front_matter   # local import: generation is optional
    builder = DOCS.get(name)
    if builder is None:
        return {"document": name, "state": UNREADABLE,
                "remediation": f"no generator is registered for {name}"}
    expected = _with_front_matter(name, builder())
    if expected != text:
        return {"document": name, "state": DRIFTED, "remediation": REMEDIATION[DRIFTED]}
    return {"document": name, "state": CURRENT, "remediation": REMEDIATION[CURRENT]}


def evaluate_all(*, docs_dir: Path = HERE, root: Path = OVERLAY) -> dict[str, Any]:
    rows = [evaluate(name, docs_dir=docs_dir, root=root) for name in DECLARED_SOURCES]
    bad = [r for r in rows if r["state"] != CURRENT]
    return {"schema_id": "rcg.documentation_freshness/1", "documents": rows,
            "current": [r["document"] for r in rows if r["state"] == CURRENT],
            "not_current": [{"document": r["document"], "state": r["state"]} for r in bad],
            "verdict": "PASS" if not bad else "FAIL"}


def main(argv: Sequence[str] | None = None) -> int:
    """CI entry point: generate into a temp tree and diff; never rewrite in place."""
    report = evaluate_all()
    for row in report["documents"]:
        print(f"  {row['state']:<10} {row['document']}")
        if row["state"] != CURRENT:
            print(f"             -> {row['remediation']}")
    print(f"\n{len(report['current'])}/{len(report['documents'])} documents current")
    return 0 if report["verdict"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
