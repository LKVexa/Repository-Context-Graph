<!-- generated-from: {"document":"DOC-02-dataflow-trust-boundaries.md","sources":{"registry/CONTROLS.json":"b2c37662ebc466de2d6297e129eb4442f6740f1c6411188129ed823a6a7a9690"}} -->
# DOC-02 — Data flow and trust boundaries

## Trust zones

```
  ZONE U (untrusted)                ZONE C (controlled)              ZONE T (trusted)
  ------------------                -------------------              ----------------
  repository bytes                  parsers (no eval)                scope contract
  commit messages                   retrieval index                  authority record
  PR / issue text                   graph + provenance               policy controls
  generated logs         --->       analyzers               --->     approval gate
  model output                      reasoning layer                  evidence ledger
                                    (schema-validated)               version store

  Everything in ZONE U is DATA. It is hashed, labeled and stored. It never
  becomes an instruction, a permission, or an approval.
```

## The flow, and where each boundary is enforced

| # | step | boundary crossed | enforced by |
|---|---|---|---|
| 1 | Operator states a request | -> ZONE C | rcg.intent.classify_request (lexical, no model) |
| 2 | Authority is checked | ZONE T | AuthorityRecord.covers + ScopeContract.check |
| 3 | Snapshot is pinned | U -> C | bind_snapshot; digests over exact bytes |
| 4 | Connectors read | U -> C | Connector.collect: scope check, then bounded read |
| 5 | Files are parsed | inside C | parsers: regex/AST only; repository code is never executed |
| 6 | Graph is written | inside C | ontology validation + mandatory provenance |
| 7 | Analyzers run | inside C | pure functions of the snapshot |
| 8 | Retrieval selects passages | C -> C | scope-filtered; every passage carries its label |
| 9 | Model is called | C -> U(model) -> C | labeled context only; output schema-validated |
| 10 | Policy evaluates | ZONE T | rcg.policy.evaluate; model output is an input, never a verdict |
| 11 | Review package is built | C -> human | subject digest binds exactly what was shown |
| 12 | Human decides | human -> T | authenticated human principal only |
| 13 | Apply or roll back | T -> U(worktree) | scope.check('modify', path=...) per path |

## What crosses, and what never crosses

- **Never leaves ZONE C:** secrets (classified and redacted at ingestion), host
  environment variables (scrubbed before sandboxed execution), the ledger
  handle.
- **Never enters ZONE T:** repository text, model output, retrieved passages.
  These can inform a human decision; they cannot be one.
- **Crosses U -> C only with a hash:** every artifact carries `source_hash`
  computed over the exact bytes read.
