<!-- generated-from: {"document":"DOC-06-model-tool-inventory.md","sources":{"registry/THRESHOLDS.json":"69976bad30877b5ac9732d0d3332f993188b97f95684c9072c28daf45413ea85"}} -->
# DOC-06 — Model and tool inventory

## Models

| model | version | provider | status |
|---|---|---|---|
| none | 0 | `rcg.abstaining` | Default. No authorized model provider is configured; every reasoning call abstains with a stated reason. |

A deployment binds a real provider by implementing `rcg.reasoning.ModelProvider`
and pinning `ModelIdentity`. The identity, prompt id/version and decoding digest
are recorded on every output (MODEL-01, XTOOL-06).

## Prompts

| prompt id | version | digest |
|---|---|---|
| context_summary | 1.0.0 | sha256:a76f8724121db2f0… |
| impact_explanation | 1.0.0 | sha256:08c508f799ead3a6… |
| change_draft | 1.0.0 | sha256:a6b4d63b3aa28085… |

Prompts are pinned per run. A prompt change is a breaking version change under
`RELEASE_POLICY.json` and invalidates evidence bound to the old version.

## Deterministic analyzers

| analyzer | version | deterministic |
|---|---|---|
| index_coverage | 1.0.0 | yes |
| unresolved_dependencies | 1.0.0 | yes |
| ambiguous_symbols | 1.0.0 | yes |
| dependency_cycles | 1.0.0 | yes |
| parser_fallbacks | 1.0.0 | yes |
| orphan_declarations | 1.0.0 | yes |
| untrusted_content | 1.0.0 | yes |

## Parsers

See DOC-03. Every derived fact records `analyzer` as `<parser>/<version>`.

## Runtime dependencies

| name | version | source | rationale |
|---|---|---|---|
| python | >=3.10 | host | Standard library only; no third-party runtime dependency. |
