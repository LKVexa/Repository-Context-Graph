<!-- generated-from: {"document":"DOC-11-incident-rollback-runbook.md","sources":{"registry/ROLLOUT.json":"5129f094fdad7df7dc8bb36cc2d6d34bea059a7f6cfdfc4ce8fb40ae5f415f5f","registry/SLO.json":"1991a64d23dfe984d8fa02c6e28eb515090a828efa8332498cb3d6767b679174"}} -->
# DOC-11 — Incident and rollback runbook

## Emergency disable

Use the configured rollout store's emergency-disable operation with an authorized
operator principal. With no configured store, a local run has no deployment
switch. Disabled admission and cancellation checkpoints stop further work;
revocation is also checked before application and before each write. This package
does not supply a running queue service. The 60-second propagation value is an
unmeasured deployment target, not a measured bound.

Read the actual terminal state and effect record. A refusal before writing is
DENIED or a cancellation; successful verified restoration is ROLLED_BACK; an
incomplete restoration is ABORTED with an INCOMPLETE effect. Preserve the ledger
and investigate unresolved paths. Do not infer that cancellation means rollback.

## Symptom → action

| Symptom | Immediate action | Then |
|---|---|---|
| `ALERT-WRITE-01` (denied write attempt) | Disable. The run tried something outside its contract. | Read the ledger events around the alert; the denied action and its authority are both recorded. |
| `ALERT-SELFAPP-01` (non-human approval attempt) | Disable and treat as a security incident. | Verify the IdP binding; a service principal reached an approval path. |
| `ALERT-EXT-01` (unauthorized external system) | Disable. | Check `authorized_external_systems` on the contract that was in force. |
| `ALERT-DENY-01` (denial rate > 20%) | No disable. | Usually a mis-scoped contract, not an attack. Compare the run's requests against its authorized paths. |
| Ledger `verify()` fails | Freeze the evidence directory; do not write. | The failure names the sequence number of the first break. Preserve the original bytes for investigation; a chain check alone does not establish publisher identity. |
| Store `verify()` reports problems | Restore from the most recent verified backup. | `VersionStore.restore` refuses a backup without a manifest and re-verifies after copying. |
| Query results look wrong | Check `freshness` on the result. | A `STALE` or `PARTIAL` result is not a bug; it is the contract working. |

## Rollback

The effect transaction retains preimage bytes in memory and tracks paths actually
written. On a caught failure it attempts restoration of each written path and
records verified restoration or incomplete recovery. This is in-process recovery,
not a durable transaction journal or crash-safe filesystem snapshot.

A snapshot **digest cannot reconstruct bytes**. After a process/host failure:

1. Preserve the result, effect record, ledger and current files; inspect applied,
   restored and unresolved paths before making another change.
2. Recover original bytes only from an actual verified backup or separately
   preserved checkout/preimages. Check their hashes and protect concurrent user edits.
3. Verify file contents and record the recovery outcome. A workflow transition or
   a hash alone is not proof that restoration happened.

The runtime does not implement repository reset/clean/forced checkout. The separate
fixture builder replaces only recognized disposable fixture trees; it is not a
repository recovery tool.

## Restoring the store

```
python3 -c "from rcg.versionstore import VersionStore; VersionStore.restore('<backup>', '<dest>')"
```

Restore fails closed: a backup with no manifest is refused, and the restored
store is verified before it is returned.

## What to collect for an incident report

- The case file: `EvidenceLedger.export_case_file` (chain status, every event,
  the three derivation classes separated).
- The run result document, including `metrics`, `trace` and `alerts`.
- The scope contract and its digest.
- The review package and decision record, if the run reached the gate.
