#!/usr/bin/env python3
"""Validate the source, UMC application, and RCG regression path together.

This entry point never declares any UMC control complete or production ready.
Reports must be stored outside this project so they cannot change the subject.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
UMC = ROOT / 'Unified Master Checklist'

def verify_manifest(root: Path) -> tuple[list[str], str | None]:
    """Errors, plus the manifest's own digest so the check record is anchored.

    Compiled bytecode is not excluded from the unlisted-file test. Excluding
    `__pycache__` meant an unlisted, unhashed, importable `.pyc` could sit in a
    delivered tree and the manifest check would still pass; delivered trees
    carry no bytecode, so its presence is reported rather than ignored.
    """
    manifest = root / 'MANIFEST.sha256'
    if not manifest.is_file():
        return ['missing manifest'], None
    expected = {}
    errors = []
    for number, line in enumerate(manifest.read_text(encoding='utf-8').splitlines(), 1):
        try:
            digest, relative = line.split(None, 1)
            relative = relative.lstrip('* ')
            path = (root / relative).resolve()
            path.relative_to(root.resolve())
            if len(digest) != 64 or relative in expected:
                raise ValueError('bad or repeated manifest entry')
            expected[relative] = digest
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                errors.append(f'digest mismatch or missing: {relative}')
        except (ValueError, OSError) as exc:
            errors.append(f'manifest line {number}: {exc}')
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
              if p.is_file() and p != manifest}
    bytecode = {p for p in actual
                if '__pycache__' in Path(p).parts or p.endswith(('.pyc', '.pyo'))}
    errors.extend(f'compiled bytecode must not be present: {p}' for p in sorted(bytecode))
    errors.extend(f'unlisted file: {p}' for p in sorted(actual - set(expected) - bytecode))
    return errors, hashlib.sha256(manifest.read_bytes()).hexdigest()

def find_bytecode(root: Path) -> list[str]:
    """Compiled bytecode anywhere in the delivery.

    The manifest check covers the UMC tree only. The `.pyc` this audit found in
    the input archive was under `Repository Context Graph/eval/__pycache__/`,
    which no delivered check looked at: unlisted, unhashed, importable, and
    outside every manifest.
    """
    return sorted(p.relative_to(root).as_posix() for p in root.rglob('*')
                  if p.is_file() and ('__pycache__' in p.parts
                                      or p.suffix in ('.pyc', '.pyo')))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report-dir', type=Path, required=True)
    parser.add_argument('--umc-only', action='store_true', help='explicitly omit RCG regression checks')
    args = parser.parse_args()
    output = args.report_dir.resolve()
    if output == ROOT or ROOT in output.parents:
        parser.error('--report-dir must be outside the project')
    output.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
    checks = []
    bytecode = find_bytecode(ROOT)
    checks.append({'name':'no-delivered-bytecode','exit_code':1 if bytecode else 0,
                   'errors':[f'compiled bytecode in the delivery: {p}' for p in bytecode]})
    print(f"no-delivered-bytecode: {'PASS' if not bytecode else 'FAIL'}", flush=True)
    errors, manifest_digest = verify_manifest(UMC)
    checks.append({'name':'umc-delivery-manifest','exit_code':1 if errors else 0,'errors':errors,
                   'manifest_sha256':manifest_digest})
    print(f"umc-delivery-manifest: {'PASS' if not errors else 'FAIL'}", flush=True)
    jobs = [
        ('source-package', UMC/'source'/'umc-agent-v1.1.0', ['scripts/validate.py','--json']),
        ('source-coverage', UMC, ['-m','umc.coverage','--validate']),
        ('receipt-integrity', UMC, ['-m','umc.cli','validate']),
        ('umc-regression', UMC, ['-m','umc.cli','verify']),
    ]
    if not args.umc_only:
        rcg = ROOT/'Repository Context Graph'
        jobs.extend([
            ('rcg-package', rcg, ['control-plane/package/tools/verify_package.py', 'control-plane/package']),
            ('rcg-regression', rcg, ['tests/run_all.py', '--report', str(output/'rcg-regression.json')]),
            ('rcg-evaluation', rcg, ['eval/harness.py']),
            ('rcg-docs', rcg, ['docs/generate_docs.py', '--check', 'docs']),
            ('rcg-freshness', rcg, ['docs/freshness.py']),
            ('rcg-successor', rcg, ['control-plane/successor/self_test.py']),
        ])
    for name, cwd, argv in jobs:
        command = [sys.executable, '-B', *argv]
        log = output / f'{name}.log'
        try:
            completed = subprocess.run(command, cwd=cwd, env=env, capture_output=True,
                                       text=True, encoding='utf-8', errors='replace', timeout=900)
            log.write_text(completed.stdout + completed.stderr, encoding='utf-8')
            record = {'name':name,'argv':command,'cwd':str(cwd),'exit_code':completed.returncode,
                      'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
        except (OSError, subprocess.TimeoutExpired) as exc:
            record = {'name':name,'argv':command,'exit_code':1,'error':str(exc)}
        checks.append(record)
        print(f"{name}: {'PASS' if record['exit_code'] == 0 else 'FAIL'}", flush=True)
    document = {
        'schema':'umc.repository-verification/1',
        'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'UMC only' if args.umc_only else 'UMC and RCG',
        'checks':checks,
        'result':'PASS' if all(c['exit_code']==0 for c in checks) else 'FAIL',
        'host_temp_adapter':env.get('UMC_TEST_TEMP_ROOT') is not None,
        'boundary':'Local application integrity and regression only; no control completion, independent approval, OS isolation qualification, or production grant.',
    }
    (output/'verification.json').write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8')
    print(document['result'])
    return 0 if document['result']=='PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
