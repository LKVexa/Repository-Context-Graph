# Project Repository Context Graph — efficacy audit and repairs

This package combines a **66-suite specification corpus**, the **Repository Context Graph runtime 1.7.2**, and the **Unified Master Checklist harness 1.0.3**. The runtime builds a static, provenance-bearing context graph and supports lexical retrieval, freshness comparison and impact/review workflows. It implements only part of the broader specification.

**Production remains NO_GO. UMC formal acceptance remains unrun.** Green local tests do not establish production readiness, live model quality or independent approval.

The current audit is the second efficacy pass. It repairs a specific class of defect: mechanisms that reported success for a condition they never tested — a store verifier that skipped ref heads, a restore that ignored the manifest it demanded, a hash chain blind to a removed last record, alert rules keyed on fields the schema does not have, and a traceability flag computed from the rows it was checking. Read [AUDIT_REPORT.md](AUDIT_REPORT.md) for findings, verification and remaining limitations. Earlier audit, application and GO reports are historical evidence for their named subjects, not current acceptance.

| Path | Purpose |
|---|---|
| 66 suite folders | Provisional specifications and sample data; not 66 deployed applications |
| `Repository Context Graph/` | Patched graph runtime, fixtures, tests, documentation and control plane |
| `Unified Master Checklist/` | Source-linked controls, limited observation probes and retained evidence |
| `audit/findings/` | Retained findings from the first efficacy pass |
| `audit/history/` | Original corpus and root metadata retained before repair |
| `verify.py` | Combined integrity, regression, evaluation and documentation verification |

Run from this directory with Python 3.10 or later and an external report directory:

```text
python -B verify.py --report-dir ../verification
```

The runtime uses the Python standard library. The historical control-plane package validator additionally requires `jsonschema`; nothing installs it on demand. `--umc-only` explicitly chooses the narrower verification path. A required skipped test remains a failure, even if other tests pass. Compiled bytecode anywhere in the delivery is now a failed check rather than an ignored file — the input archive contained one such file, and it is the only file this audit deleted. See the audit for the restricted Windows host adapter recorded by the first pass.

For runtime commands and implementation boundaries, see [runtime README](Repository%20Context%20Graph/README.md). For control observations and preserved source, see [UMC README](Unified%20Master%20Checklist/README.md). Supplied `.jad`, `.dmk` and related language artifacts remain specification/sample material; local integrity does not certify a language compiler. The 533 corpus language/specification files are byte-identical to the input archive.

MIT for the project; see [LICENSE](LICENSE). Existing source and donor provenance remains in [UMC notices](Unified%20Master%20Checklist/THIRD-PARTY-NOTICES.md) and [runtime notices](Repository%20Context%20Graph/THIRD-PARTY-NOTICES.md).
