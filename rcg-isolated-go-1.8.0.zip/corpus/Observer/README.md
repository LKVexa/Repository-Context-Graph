# JA21 Observer — Individual JA Agent Language Scripts

This package contains six standalone `.jaa` scripts for repository section `01. Observer`.

## Scripts

1. [01_observer_prompts.jaa](01_observer_prompts.jaa) — observes prompt records and prompt-integrity findings.
2. [01_observer_uploads.jaa](01_observer_uploads.jaa) — observes upload metadata, integrity, and routing.
3. [01_observer_runtime_events.jaa](01_observer_runtime_events.jaa) — observes, correlates, and validates runtime events.
4. [01_observer_decisions.jaa](01_observer_decisions.jaa) — observes decision basis, policy alignment, rationale, and approval.
5. [01_observer_errors.jaa](01_observer_errors.jaa) — observes errors, classifications, safety checks, recovery routing, and causes.
6. [01_observer_evidence.jaa](01_observer_evidence.jaa) — observes claim-evidence links, provenance, strength, and the evidence ledger.

## Analytical roles

- **SOPHIA** performs semantic analysis, classification, correlation, and claim linkage.
- **CHARLOTTE** performs integrity, policy, safety, sequence, and provenance validation.
- **LANDON** routes normalized records into the observer ledger.
- **Professor** produces human-readable explanations and rationale.
- **Podium** publishes the internal audit/evidence output after required approval gates.

## JA21 profile alignment

The scripts follow the attached JA Agent Language corpus profile:

- `ja source 0.3`
- `use Agent`
- explicit `policy no_network`
- explicit agent identity, role, confidence goal, memory, and budget
- typed tools with approved capability requirements
- authorization before execution
- policy gating
- MCRT recording
- capability-boundary assertion
- deterministic goal termination

## Repository paths

Each script expects its corresponding stream beneath:

`repository/01_observer/`

The runtime may remap these paths if the host repository uses another root.

## Delivery integrity audit

The original manifest, checksum list and README are preserved byte-for-byte in [historical metadata](../audit/history/corpus-metadata/Observer/README.md). Current `MANIFEST.json` and `SHA256SUMS.txt` use the actual delivered filenames and raw bytes; their validation scope is local integrity only, not compiler execution or certification. The manifest records 0 unavailable historical artifact(s) explicitly and does not invent replacements. Executable/specification source files were not changed by this metadata repair.
