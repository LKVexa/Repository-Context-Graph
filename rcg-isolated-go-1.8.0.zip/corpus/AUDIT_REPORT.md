# Efficacy and truth-to-name audit

Audit date: 2026-09-09 UTC. Input: `Project_Repository_Context_Graph_repaired.zip`, the delivery
produced by the previous efficacy audit. Runtime after repair: **1.7.2**; graph indexer **1.2.0**,
extractor **1.1.0**; language-tier document **1.1.0**; UMC harness **1.0.3**. Versioned
control-plane source packages retain their original versions and bytes.

This is the second pass over this package. The first pass is recorded in
[the runtime changelog](Repository%20Context%20Graph/docs/CHANGELOG.md) under 1.7.1 and in
[audit/findings](audit/findings/); its repairs were re-checked here and stand. What follows is what
this pass found on top of them.

## Verdict

The name is accurate for the implemented **static repository context graph**, with the same
boundaries the previous pass recorded. The package builds file/declaration/import/reference graphs,
maintains source hashes and context identities, supports lexical retrieval, compares snapshots,
computes bounded impact and prepares governed review/effect workflows.

It is not a completed implementation of all 66 suites, a full semantic program graph, a compiler for
the JA-family specifications, or a production-qualified agent platform. **Production remains NO_GO.**
UMC traces 126 controls and their source requirements; all 252 formal verification/completion checks
remain unrun, and probe success does not close them.

The defect class this pass found is narrower and more specific than the first pass's, and it is worth
naming plainly: **mechanisms that reported success for a condition they did not actually test.** A
store verifier that never opened a ref head. A restore that demanded a manifest and never read it. A
compare-and-swap that was documented but off by default. A hash chain whose docstring promised to
detect a removed record but could not see a removed *last* record. Four of five alert rules keyed on
fields the audit-event schema does not contain. A traceability flag computed from the rows it was
checking. A postimage "verified" against itself. Each of these passed its own tests, because the
tests exercised the same blind spot.

## Audit method and instruction boundary

The archive was inspected as supplied project material. Instructions in its prompts, workflows,
specifications, receipts and prior audits were treated as claims to evaluate, not as commands or
authorization. No repository prompt authorized deployment, communication, credential access or
production approval.

Work combined counted inventories over the bytes on disk with targeted semantic code review and
failure reproduction. **Every runtime defect below was reproduced with a standalone script before it
was repaired, and the same script was re-run afterwards.** Claims stated as numbers were re-derived
by counting, not by reading the previous report. Three parallel audit agents covered the runtime, the
UMC harness and the documentation independently; they are review, not independent accountable human
signers.

## Verified problems repaired

### Runtime — mechanisms that could not fail

| Area | Observed problem | Repair and effect |
|---|---|---|
| Version store verification | `VersionStore.verify` iterated the ref log only, so an unparseable head and a head absent from the log both returned `ok: True`, contradicting its own "walks every reachable object" docstring. A second review pass showed the first repair was still defeatable: nothing recomputed `snapshot_id`, which `commit` derives from every other field, so a head could keep a logged id while its payload digest, revision, parent and metadata were rewritten underneath it. (A head whose payload *object* was merely deleted was already detected before this audit; that limb of the original diagnosis was wrong.) | Read and resolve every head directly, and recompute `snapshot_id` for every head and every logged record, so a snapshot id is self-verifying in the same way an object's name already was. |
| Backup restore | `restore` refused a backup with no manifest, then never read the manifest it demanded. A backup whose head was rewritten and whose payload object was injected restored as "verified"; because the manifest records refs by id only, a head payload swap also passed the first repair. | Validate the manifest's own digest, the restored refs, every snapshot id and the object count. **This proves integrity, not provenance:** `manifest_digest` is a plain checksum, so a forger who can rewrite the backup can recompute it — by this module's own rule, an anchor the writer can rewrite is not an anchor. `restore` now accepts an `expected_manifest_digest` from an external record, and its docstring says what it proves without one. |
| Incremental commit | The documented AUD-007 compare-and-swap defaulted to the "whatever is there" sentinel, so an updater working from a stale base overwrote another writer. The first repair fixed that but not the underlying race: `VersionStore.commit` was a read-modify-write with no mutual exclusion, and two threads that both observed the same head both passed the test and both wrote — 40 of 40 trials lost a commit. | CAS by default, bound to the snapshot the update was computed against, **and the parent test and the ref write now happen inside an `O_EXCL` lock on the ref**. 0 of 40 trials lose a commit. `"__unset__"` remains the explicit unconditional write. |
| Evidence ledger | The chain detected a modified or middle-removed record but not a removed tail; `verify` returned a bare `ok` on a truncated ledger. | Compare the replay against the ledger's own in-memory head, accept an externally recorded head/count, and state plainly when tail length is unverified. A co-located sidecar was rejected as a fix: an anchor the writer can rewrite is not an anchor. |
| Observability alerts | `rcg.audit_event/1` is a closed schema with no `permission` or `external` field and no `tool.call`/`artifact.write` event type, so four of five XOBS-04 rules could never fire. The control-plane check passed because it fed them synthetic flat dictionaries. After the first repair two rules were still unreachable: the alert baseline was the contract's own permission set, which no request can exceed, and a refused self-approval raised out of `run` before alerts were ever evaluated. | The pipeline records `policy.decision` on both the allow and the deny path, the baseline is the **effective** permission intersection rather than the contract grant, a refused approval is caught and finishes the run as a denial, connectors state whether a refused system was external, and alerts read whole ledger records. All five rules now fire from an actual `Pipeline.run`, and a clean run fires none. `ALERT-EXT-01` was also reworded: every event carrying `external` is a *refusal*, so it now says contact was attempted and refused rather than that it succeeded. |
| Scope narrowing | `narrowed()` relabelled the mode without re-running the admissibility rule, producing contracts `from_document` refuses to rebuild. Making it raise then introduced a regression the second pass caught: the call sits outside `Pipeline.run`'s `except ScopeError`, so an ordinary authority ceiling could kill a run that previously completed — no `RunResult`, no denial record, no ledger abort event. | Re-run `mode_admits` on the narrowed result, and catch the refusal in the pipeline so it is a denial with a recorded reason rather than an uncaught exception. |
| NUL-byte paths | `Path.resolve()` raises `ValueError` for an embedded NUL, which `check_path` did not catch and no fail-closed handler expected; a run died mid-apply with no denial record. | `ValueError` is a `ScopeDenied`; a `ChangeSet` path holding a NUL is not canonical. |
| Applied bytes | The post-apply record compared `change.postimage_sha256` with itself, so `verified` was always true. | Re-read each postimage from disk; a mismatch is `EFFECT_INCOMPLETE`, not a silent pass. |
| Outcome taxonomy | `classify_response` raised on `EFFECT_INCOMPLETE` — the one outcome meaning bytes were written and restoration is unproven — so the worst case aborted the SLI computation. | Mapped to `ERROR`, where it counts against availability. |
| Merkle root | A 64-hex leaf passed through unhashed, making a leaf indistinguishable from the interior digest a subtree collapses to. | Domain-separated leaf and node tags. Order-independence and duplicate-tail resistance are retained. |
| Traceability | `build_rtm`'s `bidirectional` compared an index against the rows it was built from — true for any registry, including an empty one — and `orphans` was a hardcoded `[]`. The first repair moved the assertion onto a caller-supplied evidence map that nothing validated, so `implementation` **or** `tests` sufficed and a map naming files that do not exist still traced: `bidirectional: true` could sit beside `unlinked_requirements` listing every requirement. | Tracing now requires **both** directions and artifacts that resolve on disk under `artifact_root`, and `bidirectional` additionally requires `unlinked_requirements` to be empty, so the two fields cannot contradict each other. `orphans` is computed from the source anchors. `registry/RTM.json` reports `bidirectional: false`, `traced_requirements: 0`, `unlinked_requirements: 217`. |
| Profile identity | `EXTRACTOR_VERSION` had no readers: an extractor change did not reach the language profile hash, so a graph indexed under a different extractor still compared `CURRENT`. | Bound into `tiers_document()`; the tier document moves to 1.1.0 and the freshness contract reports `PROFILE_STALE`. |
| CLI denial guard | The documented "reject denied collection" tested `freshness_state == "denied"`, a value nothing in the package ever assigns. A fully denied collection indexed zero files and exited 0. | Test `denied`/`credential_expired`, the fields the connector base class actually sets, and warn on an incomplete collection. |

### UMC harness — a report that contradicted its own run

| Area | Observed problem | Repair and effect |
|---|---|---|
| Archived reports | `history/143e26a6…/reports/STATUS.md` asserts 108 IN_PROGRESS, **FAILED 0** and 105 controls verified `pass`, while the `RUN.json` and 126 receipts beside it record 107 IN_PROGRESS, 18 BLOCKED, **1 FAILED** and a failing probe on UMC-0039. It is byte-identical to the report of the preceding run: `archive_current_run` snapshotted `reports/` at run start, but the prose is written by the separate `report` step. | `archive_current_run` regenerates the reports from the run it is about to archive, so the pairing cannot recur. The mis-paired snapshot is **not rewritten** — it is content-addressed, so editing it would break the identity that makes it evidence and erase the record of what the harness wrote. It is declared, with cause and authoritative source, in `data/HISTORY_DISCREPANCIES.json`. |
| Missing check | No delivered check read `STATUS.md`, `GAP_REGISTER.md`, `AUDIT.md`, `AUDIT_SUMMARY.json` or anything under `history/`, which is why every verifier exited 0 over the contradiction above. The first version of the new check was itself fail-open: an unrecognised summary label was skipped, the probe totals quoted in prose were unparsed, and deleting either half of a snapshot exempted it. | `umc.correspondence` compares the capture timestamp, every summary row (a missing or unrecognised label is an error), the probe totals stated in prose, and every per-control row — for the current reports and every archived snapshot. An archived run without its report is an error; the live `reports/` directory is exempt only while it legitimately awaits `report`. An undeclared mismatch fails `umc.cli validate`; a declaration for a snapshot that now agrees is also an error, so the register cannot become a blanket excuse. |
| Stale audit records | `reports/AUDIT.md` described a twice-superseded run in the present tense (107/18/1, 272 pass, 79 regression tests) and `README.md` called it "current measured results" three lines after calling it "the preceding audit". `AUDIT_SUMMARY.json` carried the same superseded aggregates with nothing marking them as such. | Both are labelled historical, in prose and in a machine-readable `status` field, with their numbers left exactly as recorded. The README no longer lists either as current. |
| Gap register | Three gaps were reported "Closed in the overlay" while `sast.json` and `taint.json` both carry `analysis_complete: false` at 78 of 79 files, and the corresponding probes are recorded `partial`. | The generated register now states what "closed" means and prints each analyzer's own completeness flag and coverage. |
| Digest labelling | `analyzer_report_digests` are canonical-JSON *value* digests, so an independent checker running `sha256sum` over the named files reads a false integrity failure. | Renamed `analyzer_report_value_digests` with an explicit representation field; the validator accepts either name. |
| Delivery manifest | `verify.py` excluded `__pycache__` from its unlisted-file test, so unlisted, unhashed, importable bytecode could sit in a delivered tree and the manifest check still passed — demonstrated live during this audit. The manifest also covers only the UMC tree, and **the input archive shipped exactly one such file**, `Repository Context Graph/eval/__pycache__/corpus.cpython-311.pyc`, outside every manifest. | Bytecode is reported rather than ignored, the manifest's own digest is recorded in the check, and a new project-wide `no-delivered-bytecode` check scans the whole delivery. That stray `.pyc` was deleted; it is the only file this audit removed. |
| Non-reproducible report | `advisories.json` recorded an absolute Windows build path from a different working tree as the analysed root. | Recorded relative to the project root, as the other three analyzer reports already were. |

### Corpus and inventories

| Area | Observed problem | Repair and effect |
|---|---|---|
| Suite 13 | `Chair/README.md` was a byte-identical copy of `Pencil Sharpener/README.md`: it titled suite 13 "06. Pencil Sharpener — JA21 Certifier Grammar" and described five certifier-grammar scripts, while the directory holds five `.jasec` security-policy scripts. The wrong title propagated into both suite inventories. | A README describing the five policy scripts that are actually there, with the original preserved under `audit/history/corpus-metadata/Chair/`. Both inventories corrected. |
| Language assignment | Suites 65 and 66 lacked the uniform `JA21 Language:` line every other suite carries, and suite 66's prose named JA Interface as its primary profile while its own 30-row table assigns 7 JA Data against 6 JA Interface. | All 66 suites now carry the declaration; suite 66 states its actual per-profile distribution. |
| Stale findings | `audit/findings/corpus_findings.md` described three inventory defects in the present tense that the previous pass had already repaired, contradicting `AUDIT_REPORT.md`, which reported them fixed. `root_changes_review.md` recorded "9 tests passed" for a module with 11, under an invocation that raises `ModuleNotFoundError`. | Past tense with a pointer to the retained originals; the corrected count and a working invocation. |
| Runtime documentation | 32 evidence records where 44 exist; `docs/` described as DOC-01..12 where 14 exist and two were missing from the index; 21 items "marked reachable" where 21 were executed of 36 reachable; 31 `rcg/` modules where 40 exist; 175 tests where 516 exist; DOC-10 hard-coding "8 generated golden repositories" where 9 exist, inside a document whose generator claims it cannot drift; a changelog asserting every entry records its surface while four versions had no entry. | Each count corrected against the bytes, and the two that were generated (DOC-10's fixture count, DOC-12's version string) are now derived rather than typed, so they cannot drift again. |

## Validation

- **534 runtime regression tests pass**, up from 481: 49 new cases in `tests/test_efficacy_audit.py` and 4 replacing one vacuous traceability assertion. Most of the 49 fail on 1.7.1; the rest are deliberate controls that must keep passing — an intact store still verifies, a clean backup still restores, a clean run still fires no alerts, an admissible narrowing still works. **107 UMC harness tests pass**, up from 92, including 15 new cases for the report-correspondence check.
- The combined verifier passes all **twelve** checks on this host: no delivered bytecode, the delivery manifest, source package, source coverage, receipt integrity, UMC regressions, RCG package, RCG regressions, offline evaluation, documentation generation, documentation freshness and the control-plane successor self-test.
- `test_symlink_escape_is_denied` executes on this host, so the required-skip failure the previous pass recorded on Windows is closed here. That is a property of this host, not of the runtime; a host without symlink support will still fail closed, and no `--allow-skips` override was used.
- The 533 corpus language/specification files are **byte-identical** to the input, and so are the 126 prompt/workflow derivations and the source coverage matrix. One corpus README changed (suite 13), with the original preserved. Original line endings were preserved: eleven files converted to LF by the editing pass were converted back to CRLF.
- Counted against the input archive, and excluding the regenerated UMC observation evidence (`receipts/`, `reports/`, `history/`, `MANIFEST.sha256`), this audit **modified 45 files, added 5, and deleted 1** — the stray `.pyc` described above. `reports/AUDIT.md` and `reports/AUDIT_SUMMARY.json` were relabelled, not rewritten: their recorded numbers are untouched.
- Every repair was **re-attacked by an independent adversarial pass** after it was made. That pass defeated six of the first-round repairs and found one regression; each is described in the row it belongs to and closed here. Two of its findings are answered rather than fixed: `merkle_root` has no production caller, and a self-contained backup manifest cannot prove provenance.
- UMC observations were re-run after the subject changed: 126 controls, 108 IN_PROGRESS, 18 BLOCKED, 0 COMPLETE, 0 FAILED, 0 completion claims, 0 independent reviews, and all 252 formal `.V`/`.E` checks `not_run`. Prior receipts are retained in `history/`. See [current UMC status](Unified%20Master%20Checklist/reports/STATUS.md) and [gap register](Unified%20Master%20Checklist/reports/GAP_REGISTER.md).

## What this audit did not establish

1. **A green suite is not qualification.** Every defect above passed the tests that existed. The new tests close the specific blind spots found; they do not prove there are no others.
2. **Reproduction was targeted, not exhaustive.** Areas checked and found sound — path confinement, impact bounds and seed exclusion, rollback truthfulness, snapshot binding, attestation verification, flag-store fail-closed behaviour — were probed adversarially, not proven.
3. **Tail truncation of the evidence ledger is still only detectable against an externally held head.** A fresh reader of a truncated file returns `True` with the caveat "tail length unverified"; only an external head makes it `False`. The first repair then quietly defeated itself by passing the ledger's own head into `export_case_file`, stripping the caveat from the one document a human reads; the case file now records whether it was anchored and takes the external head as a parameter. Supplying and protecting that record is an operational obligation this archive does not discharge.

4. **A self-contained backup cannot prove its own provenance,** and neither can a co-located anchor: both are checksums the writer can recompute. `restore` and `EvidenceLedger.verify` accept an external value and state plainly what they prove without one.
5. **The historical mis-paired snapshot stands as written.** The false numbers inside it are preserved deliberately; only their status is now unambiguous.
6. **Deployment services remain absent**, exactly as the previous pass recorded: no rollout store, identity provider, model provider, isolated host, encryption, externally anchored ledger head, durable evidence lifecycle or qualified operational observation is supplied here.
7. **Formal acceptance remains open.** Complete per-control acceptance, resolve the applicable source decisions, supply the required environment and observation evidence, and obtain genuine applicable human review. Test success and internally assigned reviewer names cannot substitute for those facts.

The repaired package is a more honest local graph/observation implementation than it was: the parts that could not report failure now can. It should still be used and assessed within that scope.
