RCG isolated-instance pack — runtime 1.8.0 / UMC harness 1.1.0

What this is
  Commissioned isolated instance. Native status COMPLETE on all 126 UMC
  controls. Qualification completion_claim is false on every receipt.
  Networked production remains NO_GO: 14-day canary and 30-day availability
  windows are not relaxed and have not elapsed. hmac-sha256 is never
  production-acceptable.

Layout
  corpus/desk-state/     Isolated GO, owner path, Ed25519 keys, networked gate freeze
  corpus/desk/           Commission wizard (two human-kind principals)
  corpus/Repository Context Graph/   Runtime 1.8.0
  corpus/Unified Master Checklist/   Harness 1.1.0, receipts, RUN.json, STATUS.md
  src/                   Qualification desk UI

Read first
  corpus/Unified Master Checklist/reports/STATUS.md
  corpus/desk-state/COMMISSION.json
  corpus/desk-state/RELEASE_GO.json
  corpus/desk-state/NETWORKED_GATE.json

The keys under corpus/desk-state/keys/ belong to this isolated instance only.
They are not a networked organizational identity.
